package com.objectfrontier.training.java.jdbc.service;

public enum ErrorCode {


    FIRSTNAME_ERR("NAME_EMPTY", "FirstName cannot be empty"), 
    LASTNAME_ERR("NAME_EMPTY", "LastName cannot be empty"), 
    EMAIL_INVALID("MAIL_INVALID", "mail Id already exist"),
    EMAIL_ERR("EM_EMPTY", "mail Id cannot be empty"), 
    BIRTHDATE_ERR("DOB_ERR", "BirthDate connot be empty"), 
    NAME_INVALID("NAME_EXIST", "Another user with this FirstName and LastName already exist"), 
    STREET_ERR("ADDR_EMPTY", "street cannot be empty"), 
    CITY_ERR("ADDR_EMPTY", "city cannot be empty"), 
    POSTAL_CODE_ERR("ADDR_EMPTY", "postal_code cannot be empty"), 
    BIRTHDATE_INVALID("DOB_ERR", "Enter valid BirthDate"), 
    ID_ERR("id_empty", "id is not autoIncrementing"), 
    POSTAL_CODE_INVALID("ADDR_INVALID", "invalid postalCode, enter valid postalCode"), 
    DATE_ERR("EOR_ERR", "END OF RECORD"), 
    DATABASE_ERR("DB_ERROR", "SQL syntax or Connectivity ERROR");

    private final String message;
    private final String errCode;

    private ErrorCode(String errCode, String message) {
        this.errCode = errCode;
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public String geterrCode() {
        return errCode;
    }

    @Override
    public String toString() {
        return String.format("ErrorCode = %s, ErrorMessage = %s", errCode, message);
    }
}
