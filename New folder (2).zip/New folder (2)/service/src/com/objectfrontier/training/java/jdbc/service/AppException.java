package com.objectfrontier.training.java.jdbc.service;

import java.util.ArrayList;

public class AppException extends RuntimeException {

    private ArrayList<ErrorCode> errorList;
    Exception cause;

    public AppException(ArrayList<ErrorCode> errorList) {
        this.errorList = errorList;
    }

    public AppException(ErrorCode databaseErr, Throwable cause, String message) {
        super(message, cause);
        errorList = new ArrayList<>();
        errorList.add(databaseErr);
    }

    public ArrayList<ErrorCode> getExceptionList() {
        return errorList;
    }
}
