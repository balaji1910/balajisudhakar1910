package com.objectfrontier.training.java.jdbc.service;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Objects;

import com.objectfrontier.training.java.jdbc.service.connection.ConnectionManager;

public class PersonService {

    private AddressService addressService = new AddressService();

    public PersonService(AddressService addressService) {
        this.addressService = addressService;
    }

    public Person create(Connection connect, Person person) throws Exception {
        Address address = person.getAddress();
        ArrayList<ErrorCode> errorList = new ArrayList<>();

        try {
            address = addressService.create(connect, address);
        } catch (AppException exception) {
            if (exception.getCause() != null) {
                throw new AppException(ErrorCode.DATABASE_ERR, exception.getCause(), exception.getMessage());
            }
            errorList = exception.getExceptionList();
        }

        validate(connect, person, errorList);

        String createQuery = new StringBuilder()
                .append("Insert into trn_person(first_name ")
                .append("                     , last_name  ")
                .append("                     , email      ")
                .append("                     , address_id ")
                .append("                     , birth_date)")
                .append("    Values(?, ?, ?, ?, ?)         ")
                .toString();

        try {
            PreparedStatement statement = connect.prepareStatement(createQuery, 
                                                                   Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, person.getFirstName());
            statement.setString(2, person.getLastName());
            statement.setString(3, person.getMailId());
            statement.setLong(4, address.getId());
            statement.setDate(5, person.getBirthDate());
            statement.executeUpdate();
            ResultSet result = statement.getGeneratedKeys();
            result.next();
            person.setId(result.getLong(1));
        } catch (SQLException sqlException) {
            throw new AppException(ErrorCode.DATABASE_ERR, sqlException.getCause(), 
                                   sqlException.getMessage());
        }

        if (person.getId() == 0) {
            errorList.add(ErrorCode.ID_ERR);
            throw new AppException(errorList);
        }
        return person;
    }

    private boolean isEmpty(String personDetail) {
        return Objects.isNull(personDetail) || ("").equals(personDetail);
    }

    private void validate(Connection connect, Person person, ArrayList<ErrorCode> errorList) 
                          throws Exception {

        if (isEmpty(person.getFirstName())) {
            errorList.add(ErrorCode.FIRSTNAME_ERR);
        }

        if (isEmpty(person.getLastName())) {
            errorList.add(ErrorCode.LASTNAME_ERR);
        }

        boolean isDuplicatePerson = isDuplicatePerson(connect, person);
        if (isDuplicatePerson) {
            errorList.add(ErrorCode.NAME_INVALID);
        }

        boolean isDuplicateEmail = isDuplicateEmail(connect, person);
        if (isDuplicateEmail) {
            errorList.add(ErrorCode.EMAIL_INVALID);
        }

        if (Objects.isNull(person.getBirthDate())) {
            errorList.add(ErrorCode.BIRTHDATE_ERR);
        }

        if (person.getBirthDate() != null) {
            java.util.Date today = new java.util.Date();
            java.sql.Date now = new java.sql.Date(today.getTime());
            if (now.compareTo(person.getBirthDate()) == -1) {
                errorList.add(ErrorCode.BIRTHDATE_INVALID);
            }
        }
        if (errorList.isEmpty() != true) {
            throw new AppException(errorList);
        }
    }

    private boolean isDuplicateEmail(Connection connect, Person person) {
        int count = 0;
        try {
        String query = new StringBuilder()
                .append("SELECT COUNT(id) AS duplicate_email FROM trn_person WHERE ")
                .append("email =? AND id != ?                                      ")
                .toString();
        PreparedStatement statement = connect.prepareStatement(query);
        statement.setString(1, person.getMailId());
        statement.setLong(2, person.getId());
        ResultSet result = statement.executeQuery();
        while (result.next()) {
            count = result.getInt("duplicate_email");
        }
      } catch (SQLException sqlException) {
          throw new AppException(ErrorCode.DATABASE_ERR, sqlException, sqlException.getMessage());
      }
        return count > 0 ? true : false;
    }

    private boolean isDuplicatePerson(Connection connect, Person person) {
        int idCount = 0;
        try {
            String anotherQuery = new StringBuilder()
                    .append("SELECT COUNT(id) AS duplicate_name FROM trn_person WHERE      ")
                    .append("first_name =? AND last_name = ? AND id != ?                  ")
                    .toString();
            PreparedStatement statement = connect.prepareStatement(anotherQuery);
            statement.setString(1, person.getFirstName());
            statement.setString(2, person.getLastName());
            statement.setLong(3, person.getId());
            ResultSet anotherResult = statement.executeQuery();
            while (anotherResult.next()) {
                idCount = anotherResult.getInt("duplicate_name");
            }
        } catch (SQLException sqlException) {
            throw new AppException(ErrorCode.DATABASE_ERR, sqlException, sqlException.getMessage());
        }
        return idCount > 0 ? true : false;
    }

    public Person read(Connection connect, boolean includePerson, Person person) throws Exception {

        String query = new StringBuilder()
                .append("SELECT id                      ")
                .append("     , first_name              ")
                .append("     , last_name               ")
                .append("     , email                   ")
                .append("     , birth_date              ")
                .append("     , address_id              ")
                .append("    FROM trn_person WHERE id =?")
                .toString();

        try {
            PreparedStatement statement = connect.prepareStatement(query);
            statement.setLong(1, person.getId());
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                person = constructPerson(result, person);
            }
        } catch (SQLException sqlException) {
            throw new AppException(ErrorCode.DATABASE_ERR, sqlException, sqlException.getMessage());
        }

        if (includePerson) {
            Address address = person.getAddress();
            address = addressService.read(connect, address);
        }
        return person;
    }


    private Person constructPerson(ResultSet result, Person person) throws Exception {
        try {
            person.setId(result.getLong("id"));
            person.setFirstName(result.getString("first_name"));
            person.setLastName(result.getString("last_name"));
            person.setMailId(result.getString("email"));
            person.setBirthDate(result.getDate("birth_date"));
        } catch (SQLException sqlException) {
            throw new AppException(ErrorCode.DATABASE_ERR, sqlException, sqlException.getMessage());
        }
        return person;
    }

    public ArrayList<Person> readAll(Connection connect, boolean includeAddress) throws Exception {
        String query = new StringBuilder()
                .append("SELECT id                      ")
                .append("     , first_name              ")
                .append("     , last_name               ")
                .append("     , email                   ")
                .append("     , birth_date              ")
                .append("     , address_id              ")
                .append("    FROM trn_person            ")
                .toString();
        ArrayList<Person> personList = new ArrayList<>();
        try {
            PreparedStatement statement = connect.prepareStatement(query);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                Address address = new Address();
                Person person = new Person();
                person = constructPerson(result, person);
                address.setId(result.getLong("address_id"));
                if (includeAddress) {
                    address = addressService.read(connect, address);
                    person.setAddress(address);
                    personList.add(person);
                }
            }
        } catch (SQLException sqlException) {
            throw new AppException(ErrorCode.DATABASE_ERR, sqlException, sqlException.getMessage());
        }
        return personList;
    }


    public ArrayList<Person> readAll(Connection connect, int offset, boolean includeAddress) 
                                     throws Exception {
        ArrayList<Person> personList = new ArrayList<>();
        String query = new StringBuilder()
                .append("SELECT first_name                   ")
                .append("     , id                           ")
                .append("     , last_name                    ")
                .append("     , email                        ")
                .append("     , birth_date                   ")
                .append("     , address_id                   ")
                .append("    FROM trn_person LIMIT 2 OFFSET ?")
                .toString();
        try {
            PreparedStatement statement = connect.prepareStatement(query);
            statement.setInt(1, offset);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                Address address = new Address();
                Person person = new Person();
                person = constructPerson(result, person);
                address.setId(result.getLong("address_id"));
                if (includeAddress) {
                    Address addressDetail = addressService.read(connect, address);
                    person.setAddress(addressDetail);
                }
                personList.add(person);
            }
        } catch (SQLException sqlException) {
            throw new AppException(ErrorCode.DATABASE_ERR, sqlException, sqlException.getMessage());
        }
        return personList;
    }

    public void delete(Connection connect, Person person) throws Exception {
        String query = "DELETE FROM trn_person WHERE id  = ?";
        try {
            PreparedStatement statement = connect.prepareStatement(query);
            statement.setLong(1, person.getId());
            statement.executeUpdate();
        } catch (SQLException sqlException) {
            throw new AppException(ErrorCode.DATABASE_ERR, sqlException, sqlException.getMessage());
        }
        AddressService service = new AddressService();
        Address address = person.getAddress();
        service.delete(connect, address);
    }

    public Person update(Connection connect, Person person) throws Exception {
        String update = new StringBuilder()
                .append("UPDATE trn_person SET first_name = ?")
                .append("                    , last_name = ? ")
                .append("                    , email = ?     ")
                .append("                    , birth_date = ?")
                .append("    WHERE id = ?                    ")
                .toString();
        ArrayList<ErrorCode> exceptionList = new ArrayList<>();
        try {
            validate(connect, person, exceptionList);
        } catch (AppException err) {
            throw new AppException(exceptionList);
        }
        try {
            PreparedStatement statement = connect.prepareStatement(update);
            statement.setString(1, person.getFirstName());
            statement.setString(2, person.getLastName());
            statement.setString(3, person.getMailId());
            statement.setDate(4, person.getBirthDate());
            statement.setLong(5, person.getId());
            statement.executeUpdate();
        } catch (SQLException sqlException) {
            throw new AppException(ErrorCode.DATABASE_ERR, sqlException, sqlException.getMessage());
        }
        if (person.getAddress() != null) {
            Address address = person.getAddress();
            addressService.update(connect, address);
        }
        return person;
    }

    public static void main(String[] args) throws Exception {
        PersonService service = new PersonService(new AddressService());
        ConnectionManager connect = new ConnectionManager();
        Address address = new Address("HL colony", "chennai", 600075);
        Person person = new Person("amudhan", "d", "hasriharan@ofs", Date.valueOf("1996-06-19"), address);
        try {
            service.create(connect.initConnection(), person);
        } catch (AppException e) {
            System.out.println(e.getCause());
        }
    }
}
