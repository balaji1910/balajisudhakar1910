package com.objectfrontier.training.java.jdbc.service.connection;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class ConnectionManager {

    public Connection initConnection() throws Exception {
        Properties property = new Properties();
        InputStream inputStream = ConnectionManager.class.getResourceAsStream("connection.properties");
        property.load(inputStream);
        String user = property.getProperty("user");
        String password = property.getProperty("password");
        String url = property.getProperty("url");
        Connection connection = DriverManager.getConnection(url, user, password);
        connection.setAutoCommit(false);
        return connection;
    }
}
