package com.objectfrontier.training.java.jdbc.test;

import java.sql.Connection;
import java.sql.Date;
import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.java.jdbc.service.Address;
import com.objectfrontier.training.java.jdbc.service.AddressService;
import com.objectfrontier.training.java.jdbc.service.AppException;
import com.objectfrontier.training.java.jdbc.service.ErrorCode;
import com.objectfrontier.training.java.jdbc.service.Person;
import com.objectfrontier.training.java.jdbc.service.PersonService;
import com.objectfrontier.training.java.jdbc.service.connection.ConnectionManager;

public class PersonServiceTest {

    PersonService personService;
    ConnectionManager connection;
    AddressService addressService;

    @BeforeClass(/*alwaysRun = true*/)
    private void setup() throws Exception {
        addressService = new AddressService();
        personService = new PersonService(addressService);
        connection = new ConnectionManager();
    }

    @Test(priority = 1, dataProvider = "testCreate_positiveDP")
    private void testCreate_positive(Person person) throws Exception {
        Connection connect = connection.initConnection();
        try {
            Person actualPerson = personService.create(connect, person);
            Assert.assertEquals(actualPerson.toString(), person.toString());
            connect.commit();
        } catch (AppException e) {
            connect.rollback();
            Assert.fail();
        } finally {
            connect.close();
        }
    }

    @DataProvider
    private Object[][] testCreate_positiveDP() {

        return new Object[][] {
            {new Person("HariHaran", "sekar", "hari@ofs", Date.valueOf("1996-06-19"), 
             new Address("kk nagar", "chennai", 600028))},

            {new Person("Naveen", "raj", "naveen@ofs", Date.valueOf("1996-07-09"), 
             new Address("Tnagar", "chennai", 600075))}, 

            {new Person("almas", "mahamed", "almas@ofs", Date.valueOf("1996-07-09"), 
             new Address("nagar", "chennai", 600070))},

            {new Person("prasanna", "mahesh", "lpk@ofs", Date.valueOf("1996-07-09"), 
             new Address("nagar", "chennai", 600070))}, 

            {new Person("mani", "bharathi", "mani@ofs", Date.valueOf("1997-01-12"), 
             new Address("Tnagar", "chennai", 600075))}, 

            {new Person("aravind", "Krishna", "ak@ofs", Date.valueOf("1997-01-01"), 
             new Address("taramani", "chennai", 600010))}, 

            {new Person("karthi", "kk", "kk@ofs", Date.valueOf("1996-06-23"), 
             new Address("taramani", "chennai", 600010))}, 

            {new Person("karthi", "uk", "uk@ofs", Date.valueOf("1996-06-23"), 
             new Address("perambur", "chennai", 600070))},

            {new Person("Tamil", "arasan", "tamil@ofs", Date.valueOf("1996-06-19"), 
             new Address("food street", "chennai", 600075))}
        };
    }

    @Test(priority = 2, dataProvider = "testCreate_negativeDP")
    private void testCreate_negative(Person person,
                                     ArrayList<AppException> expectedExceptionList) throws Exception {
        Connection connect = connection.initConnection();
        try {
            personService.create(connect, person);
            Assert.fail("expected an Exception");
        } catch (AppException e) {
            connect.rollback();
            Assert.assertEquals(e.getExceptionList().toString(), expectedExceptionList.toString());
        } finally {
            connect.close();
        }
    }

    @DataProvider
    private Object[][] testCreate_negativeDP() {
        Address address = new Address();
        Person person = new Person();
        person.setAddress(address);
        ArrayList<ErrorCode> exceptionListOne = new ArrayList<>();
        exceptionListOne.add(ErrorCode.POSTAL_CODE_ERR);
        exceptionListOne.add(ErrorCode.STREET_ERR);
        exceptionListOne.add(ErrorCode.CITY_ERR);
        exceptionListOne.add(ErrorCode.POSTAL_CODE_INVALID);
        exceptionListOne.add(ErrorCode.FIRSTNAME_ERR);
        exceptionListOne.add(ErrorCode.LASTNAME_ERR);
        exceptionListOne.add(ErrorCode.BIRTHDATE_ERR);

        Person anotherPerson = new Person("HariHaran", "sekar", "hari@ofs", Date.valueOf("1996-06-19"), 
                               new Address("kk nagar", "chennai", 600028));
        ArrayList<ErrorCode> exceptionListTwo = new ArrayList<>();
        exceptionListTwo.add(ErrorCode.NAME_INVALID);
        exceptionListTwo.add(ErrorCode.EMAIL_INVALID);

        return new Object[][] {
            {person, exceptionListOne}, 
            {anotherPerson, exceptionListTwo}
        };
    }

    @Test(dataProvider = "testCreate_SQLnegativeDP")
    private void testCreate_SQLnegative(Person person) throws Exception {
        Connection connect = connection.initConnection();
        try {
            personService.create(connect, person);
            Assert.fail();
        } catch (AppException exception) {
            connect.rollback();
            ArrayList<ErrorCode> errors = new ArrayList<>();
            errors.add(ErrorCode.DATABASE_ERR);
            Assert.assertEquals(exception.getExceptionList().toString(), errors.toString());
        }
    }

    @DataProvider
    private Object[][] testCreate_SQLnegativeDP() {
        return new Object[][] {
            {new Person("Dhoni", "MS", "MS@ofs", Date.valueOf("1982-07-07"), 
             new Address("ms street", "ranchiranchiranchiranchi", 600007))}
        };
    }


    @Test(priority = 3, dataProvider = "testRead_positiveDP", groups = {"read"})
    private void testRead_positive(Person person, boolean includeAddress) throws Exception {
        Connection connect = connection.initConnection();
        try {
            Person personDetail = personService.read(connect, includeAddress, person);
            Assert.assertEquals(personDetail.toString(), person.toString());
        } catch (Exception e) {
            Assert.fail("read operation fails");
        } finally {
            connect.close();
        }
    }

    @DataProvider
    private Object[][] testRead_positiveDP() {
        Person person = new Person();
        person.setId(1);
        Address address = new Address();
        address.setId(1);
        person.setAddress(address);

        Person personDetail = new Person();
        personDetail.setId(1);
        
        return new Object[][] {
            {person, true}, 
            {personDetail, false}
        };
    }

    @Test(priority = 4, dataProvider = "testUpdate_positiveDP")
    private void testUpdate_positive(Person person) throws Exception {
        Connection connect = connection.initConnection();
        try {
            Person updatedPerson = personService.update(connect, person);
            Assert.assertEquals(updatedPerson.toString() , person.toString());
            connect.commit();
        } catch (AppException e) {
            connect.rollback();
            Assert.fail();
        } finally {
            connect.close();
        }
    }

    @DataProvider
    private Object[][] testUpdate_positiveDP() {

        Person person = new Person(1, "HariHaran", "sekar", "hariharan@ofs", Date.valueOf("1996-06-19"), 
                        new Address(1, "kk nagar", "chennai", 600028));

        Person personTwo = new Person(2, "NaveenRaj", "nagarajan", "naveen@ofs", Date.valueOf("1996-07-09"), 
                           new Address(2, "Tnagar", "chennai", 600075));

        Address addressThree = new Address(6, "fourRoads", "salem", 600010);
        Person personThree = new Person(6, "aravind", "Krishna", "ak@ofs", Date.valueOf("1997-01-01"), 
                                        addressThree);

        return new Object[][] {
            {person}, 
            {personTwo}, 
            {personThree}
        };
    }

    @Test(priority = 5, dataProvider = "testUpdate_negativeDP")
    private void testUpdate_negative(Person person, 
                                     ArrayList<AppException> expectedExceptionList) throws Exception {
        Connection connect = connection.initConnection();
        try {
            personService.update(connect, person);
            connect.commit();
        } catch (AppException e) {
            connect.rollback();
            Assert.assertEquals(e.getExceptionList().toString(), expectedExceptionList.toString());
        } finally {
            connect.close();
        }
    }

    @DataProvider
    private Object[][] testUpdate_negativeDP() {
        Person person = new Person(7, "karthi", "kk", "kk@ofs", Date.valueOf("1996-06-23"), 
                        new Address(7, "taramani", "chennai", 600010));
        ArrayList<ErrorCode> exceptionListOne = new ArrayList<>();
        exceptionListOne.add(ErrorCode.NAME_INVALID);

        Person personTwo = new Person(8, "karthi", "uk", "kk@ofs", Date.valueOf("1996-06-23"), 
                           new Address(8, "perambur", "chennai", 600070));
        ArrayList<ErrorCode> exceptionListTwo = new ArrayList<>();
        exceptionListTwo.add(ErrorCode.EMAIL_INVALID);
            return new Object[][] {
                {person, exceptionListOne}, 
                {personTwo, exceptionListTwo}
        };
    }

    @Test(priority = 6, dataProvider = "testDelete_positiveDP")
    private void testDelete_positive(Person person) throws Exception {
        Connection connect = connection.initConnection();
        try {
            personService.delete(connect, person);
            connect.commit();
        } catch (AppException e) {
            connect.rollback();
            Assert.fail();
        } finally {
            connect.close();
        }
    }

    @DataProvider
    private Object[][] testDelete_positiveDP() {
        Person person = new Person();
        person.setId(9);
        Address address = new Address();
        address.setId(9);
        person.setAddress(address);
        return new Object[][] {
            {person}
        };
    }

    @Test(priority = 7, dataProvider = "testReadAll_positiveDP", groups = {"read"})
    private void testReadAll_positive(ArrayList<Person> expectedList) throws Exception {
        Connection connect = connection.initConnection();
        try {
            ArrayList<Person> personList = personService.readAll(connect, true);
            Assert.assertEquals(personList.toString(), expectedList.toString());
        } catch (AppException exception) {
            Assert.fail();
        } finally {
            connect.close();
        }
    }

    @DataProvider
    private Object[][] testReadAll_positiveDP() {
        ArrayList<Person> personList = new ArrayList<>();
        personList.add(new Person(1, "HariHaran", "sekar", "hariharan@ofs", Date.valueOf("1996-06-19"), 
                       new Address(1, "kk nagar", "chennai", 600028)));
        personList.add(new Person(2,"NaveenRaj", "nagarajan", "naveen@ofs", Date.valueOf("1996-07-09"), 
                       new Address(2, "Tnagar", "chennai", 600075)));
        personList.add(new Person(3, "almas", "mahamed", "almas@ofs", Date.valueOf("1996-07-09"), 
                       new Address(3, "nagar", "chennai", 600070)));
        personList.add(new Person(4, "prasanna", "mahesh", "lpk@ofs", Date.valueOf("1996-07-09"), 
                       new Address(4, "nagar", "chennai", 600070)));
        personList.add(new Person(5, "mani", "bharathi", "mani@ofs", Date.valueOf("1997-01-12"), 
                       new Address(5, "Tnagar", "chennai", 600075)));
        personList.add(new Person(6, "aravind", "Krishna", "ak@ofs", Date.valueOf("1997-01-01"), 
                       new Address(6, "fourRoads", "salem", 600010)));
        personList.add(new Person(7, "karthi", "kk", "kk@ofs", Date.valueOf("1996-06-23"), 
                       new Address(7, "taramani", "chennai", 600010)));
        personList.add(new Person(8, "karthi", "uk", "uk@ofs", Date.valueOf("1996-06-23"), 
                       new Address(8, "perambur", "chennai", 600070)));
        return new Object[][] {
            {personList}
        };
    }

    @Test(priority = 8, dataProvider = "testReadAll", groups = "read")
    private void testReadAll(ArrayList<Person> expectedList, int offset) throws Exception {
        Connection connect = connection.initConnection();
        try {
            ArrayList<Person> personList = personService.readAll(connect, offset, true);
            Assert.assertEquals(personList.toString(), expectedList.toString());
        } catch (AppException exception) {
            Assert.fail();
        } finally {
            connect.close();
        }
    }

    @DataProvider
    private Object[][] testReadAll() {
        ArrayList<Person> personListOne = new ArrayList<>();
        ArrayList<Person> personListTwo = new ArrayList<>();
        ArrayList<Person> personListThree = new ArrayList<>();
        ArrayList<Person> personListFour = new ArrayList<>();
        personListOne.add(new Person(1, "HariHaran", "sekar", "hariharan@ofs", Date.valueOf("1996-06-19"), 
                          new Address(1, "kk nagar", "chennai", 600028))); 
        personListOne.add(new Person(2,"NaveenRaj", "nagarajan", "naveen@ofs", Date.valueOf("1996-07-09"), 
                          new Address(2, "Tnagar", "chennai", 600075)));

        personListTwo.add(new Person(3, "almas", "mahamed", "almas@ofs", Date.valueOf("1996-07-09"), 
                          new Address(3, "nagar", "chennai", 600070))); 
        personListTwo.add(new Person(4, "prasanna", "mahesh", "lpk@ofs", Date.valueOf("1996-07-09"), 
                          new Address(4, "nagar", "chennai", 600070)));

        personListThree.add(new Person(5, "mani", "bharathi", "mani@ofs", Date.valueOf("1997-01-12"), 
                            new Address(5, "Tnagar", "chennai", 600075))); 
        personListThree.add(new Person(6, "aravind", "Krishna", "ak@ofs", Date.valueOf("1997-01-01"), 
                            new Address(6, "fourRoads", "salem", 600010)));

        personListFour.add(new Person(7, "karthi", "kk", "kk@ofs", Date.valueOf("1996-06-23"), 
                new Address(7, "taramani", "chennai", 600010)));
        personListFour.add(new Person(8, "karthi", "uk", "uk@ofs", Date.valueOf("1996-06-23"), 
                           new Address(8, "perambur", "chennai", 600070)));

        return new Object[][] {
            {personListOne , 0}, 
            {personListTwo , 2}, 
            {personListThree, 4}, 
            {personListFour, 6}, 
        };
    }

    @AfterClass
    private void tearDown() throws Exception {
        addressService = null;
        personService = null;
        connection = null;
    }
}
