package com.objectfrontier.training.java.jdbc.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Objects;

public class AddressService {

    public Address create(Connection connect, Address address) throws Exception {
        ArrayList<ErrorCode> errorList = new ArrayList<>();
        validate(address, connect, errorList);
        try {
            String query = "INSERT INTO trn_address(street, city, postal_code) VALUES(?, ?, ?)";
            PreparedStatement statement = connect.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, address.getStreet());
            statement.setString(2, address.getCity());
            statement.setInt(3, address.getPostalCode());
            statement.executeUpdate();
            ResultSet result = statement.getGeneratedKeys();
            result.next();
            address.setId(result.getLong(1));
            if (address.getId() == 0) {
                errorList.add(ErrorCode.ID_ERR);
                throw new AppException(errorList);
            }
            return address;
        } catch (SQLException sqlException) {
            throw new AppException(ErrorCode.DATABASE_ERR, sqlException, sqlException.getMessage());
        }
    }

    private boolean isEmpty(String addressDetail) {
        return Objects.isNull(addressDetail) || ("").equals(addressDetail);
    }

    private void validate(Address address, Connection connect, 
                                             ArrayList<ErrorCode> errorList) {
        if (address.getPostalCode() == 0) {
            errorList.add(ErrorCode.POSTAL_CODE_ERR);
        }
        if (isEmpty(address.getStreet())) {
            errorList.add(ErrorCode.STREET_ERR);
        }
        if (isEmpty(address.getCity())) {
            errorList.add(ErrorCode.CITY_ERR);
        }
        String postalCode = String.valueOf(address.getPostalCode());
        if (postalCode.length() < 6) {
            errorList.add(ErrorCode.POSTAL_CODE_INVALID);
        }
        if (errorList.isEmpty() != true) {
            throw new AppException(errorList);
        }
    }

    public Address read(Connection connect, Address address) throws Exception {

        String query = new StringBuilder("SELECT street, city, postal_code, id")
                                 .append(" FROM trn_address Where id          ")
                                 .append(" = ?;                               ")
                                 .toString();
        try {
            PreparedStatement statement = connect.prepareStatement(query);
            statement.setLong(1, address.getId());
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                constructAddress(address, result);
            }
        } catch (SQLException sqlException) {
            throw new AppException(ErrorCode.DATABASE_ERR, sqlException, sqlException.getMessage());
        }
        return address;
    }

    private void constructAddress(Address address, ResultSet result) throws Exception {
        address.setId(result.getLong("id"));
        address.setStreet(result.getString("street"));
        address.setCity(result.getString("city"));
        address.setPostalCode(result.getInt("postal_code"));
    }

    public ArrayList<Address> search(Connection connect, Address address) throws Exception {
        String query = new StringBuilder()
                .append("SELECT street, city, postal_code, id")
                .append(" FROM trn_address WHERE city        ")
                .append(" = ?                                ")
                .append("OR street                           ")
                .append(" = ?                                ")
                .append("OR postal_code                      ")
                .append(" = ?;                               ")
                .toString();
        ArrayList<Address> addressList = new ArrayList<>();
        try {
            PreparedStatement statement = connect.prepareStatement(query);
            statement.setString(1, address.getCity());
            statement.setString(2, address.getStreet());
            statement.setInt(3, address.getPostalCode());
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                Address addressDetail = new Address();
                constructAddress(addressDetail, result);
                addressList.add(addressDetail);
            }
        } catch (SQLException sqlException) {
            throw new AppException(ErrorCode.DATABASE_ERR, sqlException, sqlException.getMessage());
        }
        return addressList;
    }

//    public ArrayList<Address> search(Connection connect, Object include) {
//        StringBuilder query = new StringBuilder();
//        if (include instanceof String) {
//        query.append("SELECT street, city, postal_code, id")
//             .append(" FROM trn_address WHERE city        ")
//             .append("LIKE '%")
//             .append(include)
//             .append("%'")
//             .append("OR street LIKE '%")
//             .append(include)
//             .append("%'")
//             .toString();
//        }
//        if (include instanceof Integer) {
//           query.append("SELECT street, city, postal_code, id       ")
//                .append(" FROM trn_address WHERE postal_code        ")
//                .append("LIKE '%")
//                .append(include)
//                .append("%'")
//                .toString();
//        }
//        ArrayList<Address> addressList = new ArrayList<>();
//        try {
//            PreparedStatement statement = connect.prepareStatement(query.toString());
//            ResultSet result = statement.executeQuery();
//            while (result.next()) {
//                Address addressDetail = new Address();
//                constructAddress(addressDetail, result);
//                addressList.add(addressDetail);
//            }
//        } catch (SQLException e) {
//            throw new AppException(ErrorCode.DATABASE_ERR, e.getCause());
//        }
//        return addressList;
//    }

    public ArrayList<Address> search(Connection connect, Object include) throws Exception {
        StringBuilder query = new StringBuilder();
            query.append("SELECT street, city, postal_code, id")
            .append(" FROM trn_address WHERE city        ")
            .append("LIKE '%")
            .append(include)
            .append("%'")
            .append("OR street LIKE '%")
            .append(include)
            .append("%'")
            .append("OR postal_code LIKE '%")
            .append(include)
            .append("%'")
            .toString();
        ArrayList<Address> addressList = new ArrayList<>();
        try {
            PreparedStatement statement = connect.prepareStatement(query.toString());
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                Address addressDetail = new Address();
                constructAddress(addressDetail, result);
                addressList.add(addressDetail);
            }
        } catch (SQLException exception) {
            throw new AppException(ErrorCode.DATABASE_ERR, exception, exception.getMessage());
        }
        return addressList;
    }

    public ArrayList<Address> search(Connection connect, String[] fields, String searchText) 
                                     throws Exception {
        StringBuilder query = new StringBuilder()
                .append("SELECT id, street, city, postal_code FROM trn_address WHERE ");

        ArrayList<String> postalCode = new ArrayList<>();
        postalCode.add("postalCode");
        postalCode.add("postal_code");
        postalCode.add("POSTALCODE");
        postalCode.add("postalcode");
        postalCode.add("PostalCode");

        ArrayList<String> street = new ArrayList<>();
        street.add("street");
        street.add("STREET");

        ArrayList<String> city = new ArrayList<>();
        city.add("city");
        city.add("CITY");
        for (String field : fields) {
            if (postalCode.contains(field)) { field = "postal_code"; }
            if (street.contains(field)) { field = "street"; }
            if (city.contains(field)) { field = "city"; }
                query.append(field).append(" like ").append("'%").append(searchText).append("%'")
                .append(" OR ");
        }
        String search = query.toString();
        search = search.substring(0, search.length() - 3);
        ArrayList<Address> addressList = new ArrayList<>();
        try {
            PreparedStatement statement = connect.prepareStatement(search);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                Address address = new Address();
                constructAddress(address, result);
                addressList.add(address);
            }
        } catch (SQLException exception) {
            throw new AppException(ErrorCode.DATABASE_ERR, exception, exception.getMessage());
        }
        return addressList;
    }

    public void delete(Connection connect, Address address) throws Exception {
        String query = "DELETE FROM trn_address WHERE id  = ?";
        try {
            PreparedStatement statement = connect.prepareStatement(query);
            statement.setLong(1, address.getId());
            statement.executeUpdate();
        } catch (SQLException sqlException) {
            throw new AppException(ErrorCode.DATABASE_ERR, sqlException, sqlException.getMessage());
        }
    }

    public Address update(Connection connect, Address address) throws Exception {
        String update = new StringBuilder()
                .append("UPDATE trn_address SET ")
                .append("city                   ")
                .append(" = ?                   ")
                .append(", street               ")
                .append(" = ?                   ")
                .append(", postal_code          ")
                .append(" = ?                   ")
                .append(" WHERE id = ?          ")
                .toString();
        ArrayList<ErrorCode> exceptionList = new ArrayList<>();
        validate(address, connect, exceptionList);
        if (!exceptionList.isEmpty()) {
            throw new AppException(exceptionList);
        }
        try {
            PreparedStatement statement = connect.prepareStatement(update);
            statement.setString(1, address.getCity());
            statement.setString(2, address.getStreet());
            statement.setInt(3, address.getPostalCode());
            statement.setLong(4, address.getId());
            statement.executeUpdate();
        } catch (SQLException sqlException) {
            throw new AppException(ErrorCode.DATABASE_ERR, sqlException, sqlException.getMessage());
        }
        return address;
    }
}
