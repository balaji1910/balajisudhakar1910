package com.objectfrontier.training.java.jdbc.test;

import java.sql.Connection;
import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.java.jdbc.service.Address;
import com.objectfrontier.training.java.jdbc.service.AddressService;
import com.objectfrontier.training.java.jdbc.service.AppException;
import com.objectfrontier.training.java.jdbc.service.connection.ConnectionManager;

public class AddressServiceTest {

    AddressService addressService;
    ConnectionManager connection;

    @BeforeClass
    private void setup() throws Exception {
        addressService = new AddressService();
        connection = new ConnectionManager();
    }

    @Test(dataProvider = "testRead_positiveDP")
    private void testRead_positive(Address address, Address expectedResult) throws Exception {
        Connection connect = connection.initConnection();
        try {
            Address addressDetail = addressService.read(connect, address);
            Assert.assertEquals(addressDetail.toString(), expectedResult.toString());
        } catch (Exception e) {
            Assert.fail("read operation fails");
        }
    }

    @Test(dataProvider = "testSearch_positiveDP")
    private void testSearch_positive(Address address, ArrayList<Address> addressList) throws Exception {
        Connection connect = connection.initConnection();
        try {
            ArrayList<Address> addressDetail = addressService.search(connect, address);
            Assert.assertEquals(addressDetail.toString(), addressList.toString());
        } catch (Exception e) {
            Assert.fail("read operation fails");
        }
    }

    @Test(dataProvider = "testSearch_DP")
    private void testSearch(Object value, ArrayList<Address> addressList) throws Exception {
        Connection connect = connection.initConnection();
        try {
            ArrayList<Address> searchList = addressService.search(connect, value);
            Assert.assertEquals(searchList.toString(), addressList.toString());
        } catch (AppException exception) {
            Assert.fail();
        }
    }

    @Test(dataProvider = "testSearch_positiveDataProvider")
    private void testSearch(String[] fields, String searchText, ArrayList<Address> addressList) 
                            throws Exception {
        Connection connect = connection.initConnection();
        try {
            ArrayList<Address> searchList = addressService.search(connect, fields, searchText);
            Assert.assertEquals(searchList.toString(), addressList.toString());
        } catch (AppException exception) {
            Assert.fail();
        }
    }

    @DataProvider
    private Object[][] testSearch_positiveDataProvider() {
        String[] fields = {"street", "city"};

        ArrayList<Address> addressList = new ArrayList<>();
        addressList.add(new Address(7, "taramani", "chennai", 600010));
        addressList.add(new Address(8, "perambur", "chennai", 600070));

        return new Object[][] {
            {fields, "ram", addressList}
        };
    }

    @DataProvider
    private Object[][] testSearch_DP() {
        ArrayList<Address> addressList = new ArrayList<>();
        addressList.add(new Address(1, "kk nagar", "chennai", 600028));
        addressList.add(new Address(2, "Tnagar", "chennai", 600075));
        addressList.add(new Address(3, "nagar", "chennai", 600070));
        addressList.add(new Address(4, "nagar", "chennai", 600070));
        addressList.add(new Address(5, "Tnagar", "chennai", 600075));
        return new Object[][] {
            {"nagar", addressList}
        };
    }

    @DataProvider
    private Object[][] testRead_positiveDP() {
        Address address = new Address();
        address.setId(1);
        Address expectedAddress = new Address(1, "kk nagar", "chennai", 600028);
        return new Object[][] {
            {address, expectedAddress}
        };
    }

    @DataProvider
    private Object[][] testSearch_positiveDP() {
        Address address = new Address();
        address.setPostalCode(600028);
        ArrayList<Address> addressList = new ArrayList<>();
        addressList.add(new Address(1, "kk nagar", "chennai", 600028));

        Address anotherAddress = new Address();
        anotherAddress.setPostalCode(600070);
        anotherAddress.setStreet("nagar");
        ArrayList<Address> addressListTwo = new ArrayList<>();
        addressListTwo.add(new Address(3, "nagar", "chennai", 600070));
        addressListTwo.add(new Address(4, "nagar", "chennai", 600070));
        addressListTwo.add(new Address(8, "perambur", "chennai", 600070));
        return new Object[][] {
            {address, addressList}, 
            {anotherAddress, addressListTwo}
        };
    }

    @AfterClass
    private void tearDown() throws Exception {
        addressService = null;
        connection = null;
    }
}
