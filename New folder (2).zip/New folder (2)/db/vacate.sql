
SELECT * FROM ( SELECT col_name,univ_name,dept_name,col.id,cdept_id 
					 FROM edu_college AS col
					 INNER JOIN edu_university AS univ
					 ON col.univ_code=univ.univ_code
					 INNER JOIN edu_college_department AS cdep
					 ON cdep.college_id=col.id
					 INNER JOIN edu_department AS dep
					 ON dep.dept_code=cdep.udep_code) AS cole
					 LEFT JOIN
					 ( SELECT emp_name,desg_name,college_id,col_dept_id
					   FROM edu_designation AS des
					   JOIN edu_employee AS em
					 	ON des.id=em.desgn_id
					   JOIN edu_college AS col
						ON col.id=em.college_id) AS empe ON empe.college_id=cole.id 
						AND empe.col_dept_id=cole.cdept_id ORDER BY col_name