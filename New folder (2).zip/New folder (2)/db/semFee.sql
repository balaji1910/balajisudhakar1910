
CREATE VIEW fee AS SELECT  roll_number
		, stu_name
		, academic_year
		, semester
		, amount
		, paid_year
		, paid_status
		, col_name
		,col_code
		FROM edu_college As col INNER JOIN edu_student AS stu
		ON col.id=stu.college_id
		INNER JOIN edu_semester_fee AS fee
		ON fee.stu_id=stu.id;
			
SELECT * FROM fee;

SELECT * FROM edu_semester_fee

UPDATE fee AS sfee SET paid_year=2018 , paid_status='paid' 
			  WHERE roll_number=201201 AND semester=7;

									
UPDATE fee SET paid_year=2018, paid_status='paid' 
			  WHERE roll_number BETWEEN 101101 AND 103401 AND semester IN (7,5,3);
									