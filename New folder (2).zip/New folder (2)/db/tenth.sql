SELECT * FROM vw WHERE (credits >8) AND semester=7;

SELECT * FROM vw WHERE (credits >5) AND semester=7; 
