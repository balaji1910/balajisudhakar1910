SELECT movie_name
		,director_name 
		FROM trn_movie INNER JOIN trn_creator  
		ON movie_name=director_name;  

SELECT * 
	FROM trn_movie 
	where creator_id=(SELECT id from trn_creator where director_name='hari');								 




SELECT * FROM trn_movie inner JOIN trn_creator as c ON trn_movie.creator_id=c.id;


SELECT production_name 
	FROM trn_movie GROUP BY creator_id;								

SELECT * FROM trn_movie CROSS JOIN trn_creator as c ON creator_id=c.id; 

SELECT production_name
		,released_year 
	FROM trn_movie WHERE production_name NOT like "__u%";

SELECT * 
	FROM trn_movie 
	RIGHT JOIN trn_creator ON trn_movie.creator_id=trn_creator.id; 

SELECT * 
	FROM trn_movie 
	LEFT JOIN trn_creator ON trn_movie.creator_id=trn_creator.id; 


SELECT production_name 
	FROM trn_movie 
	WHERE production_name like "%films%";

SELECT * 
	FROM trn_movie 
	WHERE creator_id=
	(SELECT id FROM trn_creator WHERE director_name='shankar') 
	AND male_lead_id=(SELECT id FROM trn_male_lead WHERE actor_name='vikram');



SELECT * 
	FROM trn_movie CROSS JOIN trn_creator ON trn_movie.creator_id=trn_creator.id					
	CROSS JOIN trn_composer ON trn_movie.composer_id=trn_composer.id
	CROSS JOIN trn_male_lead  ON trn_movie.male_lead_id=trn_male_lead.id;


SELECT * 
	FROM trn_movie 
	INNER JOIN trn_creator AS c  ON creator_id=c.id;

SELECT * 
	FROM trn_movie  
	GROUP BY released_year;

SELECT COUNT(*) 
	FROM trn_movie; 


SELECT movie_name
	FROM trn_movie
	WHERE NOT male_lead_id=(SELECT id from trn_male_lead where actor_name='surya');

SELECT movie_name 
	FROM trn_movie WHERE movie_name LIKE '%n%'; 

SELECT * FROM trn_creator WHERE director_name BETWEEN 'ameer' AND 'hari';

SELECT MIN(id) 
	FROM trn_movie;

SELECT * 
	FROM trn_movie CROSS JOIN trn_creator AS c ON creator_id=c.id; 


CREATE VIEW m AS SELECT 
								trn_movie.id
								,production_name
								,movie_name
								,trn_creator.director_name
								,trn_composer.composer_name
								,trn_male_lead.actor_name 
								FROM trn_movie CROSS JOIN trn_creator ON trn_movie.creator_id=trn_creator.id					 
								CROSS JOIN trn_composer ON trn_movie.composer_id=trn_composer.id		
								CROSS JOIN trn_male_lead  ON trn_movie.male_lead_id=trn_male_lead.id;

SELECT *  FROM m where id=11;
	
SELECT id,CONCAT (movie_name,production_name) 
	FROM trn_movie;
	
SELECT trn_movie.id,CONCAT(production_name,'  ',movie_name,'  ',trn_creator.director_name,'  ',trn_composer.composer_name,'  ',trn_male_lead.actor_name)
	FROM trn_movie CROSS JOIN trn_creator ON trn_movie.creator_id=trn_creator.id					 
	CROSS JOIN trn_composer ON trn_movie.composer_id=trn_composer.id		
	CROSS JOIN trn_male_lead  ON trn_movie.male_lead_id=trn_male_lead.id;
	
SELECT * FROM trn_creator UNION SELECT * FROM trn_composer;