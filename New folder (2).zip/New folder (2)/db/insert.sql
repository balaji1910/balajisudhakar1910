INSERT INTO edu_university ( univ_code,univ_name) 
VALUES
  ( 'tnau','anna university')
, ( 'apua','university of andhra')
, ('kluk','university of kerala');

INSERT INTO edu_department (dept_code,dept_name,unive_code)
VALUES
  ('auee','electrical and electronics','tnau')
, ('auec','electronics and communication','tnau')
, ('aucs','computer science','tnau')
, ('auit','information technology','tnau')
, ('auei','electronics and instumentation','tnau')
, ('aume','mechanical','tnau') 				
, ('auce','civil','tnau')
, ('auae','aeronautical','tnau')
, ('auam','automobile','tnau')
, ('aubm','biomedical','tnau')
, ('uaee','electrical and electronics','apua')
, ('uaec','electronics and communication','apua')
, ('uacs','computer science','apua')
, ('uait','information technology','apua')
, ('uaei','electronics and instumentation','apua')
, ('uamr','marine','apua')
, ('ukee','electrical and electronics','kluk')
, ('ukec','electronics and communication','kluk')
, ('ukcs','computer science','kluk')
, ('ukit','information technology','kluk')
, ('ukei','electronics and instumentation','kluk')
, ('ukme','mechanical','kluk'); 				
					  
					  
INSERT INTO edu_college (col_code,col_name,univ_code,city,state,year_opened)
VALUES
  ('jce','jerusalem college of engineering','tnau','chennai','tamilnadu','1995')
, ('ssn','Sri Sivasubramaniya Nadar College of Engineering','tnau','chennai','tamilnadu','1996')
, ('psg','psg college of technology','tnau','coimbatore','tamilnadu','1951')
, ('srkr','sagi ramakrishnam raju engineering college','apua','bhimavaram','andhrapradhesh','1980')
, ('vsmr','v.s.m college of engineering','apua','ramachandrapuram','andhrapradhesh','1996')
, ('kush','kaushik college of engineering','apua','vishakapatinam','andhrapradesh','1990')
, ('nss','nss college of enginering','kluk','palakkad','kerala','1960')
, ('rgi','rajiv gandhi institute of technology','kluk','kottayam','kerala','1991')
, ('gce','government college of engineering','kluk','kannur','kerala','1993');


INSERT INTO edu_college_department (cdept_id,udep_code,college_id)
VALUES

  (1,'auee',1)
, (2,'aucs',1)
, (3,'auit',1)

, (4,'auee',2)
, (5,'auec',2)
, (6,'aucs',2)
, (7,'auit',2)


, (8,'auee',3)
, (9,'aucs',3)
, (10,'auit',3)


, (11,'uaee',4)
, (12,'uait',4)
, (13,'uacs',4)


, (14,'uaee',5)
, (15,'uait',5)
, (16,'uacs',5)


, (17,'uait',6)
, (18,'uacs',6)

, (19,'ukee',7)
, (20,'ukec',7)

, (21,'ukee',8)
, (22,'ukcs',8)

, (23,'ukit',9)
, (24,'ukcs',9);


INSERT INTO edu_designation(id,desg_name,rank)
VALUES
  (1,'principal','A')
, (2,'Hod','B')
, (3,'professor','C');


INSERT INTO edu_employee(emp_name,dob,email,phone,college_id,col_dept_id,desgn_id)
VALUES
  ('shiva', '19620101', 'nagarajan@gmail.com', 9988774455, 1, 1, 3)
, ('salman', '19500210','salman@gmail.com', 8747887485,1,1,1)
, ('jacob', '19660404','jacob@gmail.com',9887788996,1,2,2)
, ('prem', '19860606','prem@gmail.com',7785965489,1,3,3)
, ('amir', '19501210','amir@gmail.com', 8747887485,2,4,1)
, ('vinoth', '19800222','vinoth@gmail.com',9236784529,2,4,2)
, ('praveen', '19880929','praveen@gmail.com',7512973978,2,5,3)
, ('venkatesh', '19750205','venkat@gmail.com',8845967896,2,6,3)
, ('karthi', '19810406','karthi@gmail.com',7896547896,2,7,2)
, ('rajni', '19501212','rk@gmail.com', 8747887485,3,8,1)
, ('kumar','19801204','kumar@gmail.com',8210306090,3,8,2)
, ('hameed', '19750706','hameed@gmail.com',7985649615,3,9,3)
, ('keerthana', '19880106','keerthana@gmail.com',7458963258,3,10,2)
, ('kamal', '19500210','kamal@gmail.com', 8747887485,4,11,1)
, ('shruthi', '19900515', 'shruthi@gmail.com',9010577951,4,11,2)
, ('harridha', '19800506','harridha@gmail.com',9865321458,4,12,3)
, ('naveen',' 19900901','naveen@gmail.com',8745123698,4,13,2)
, ('mgr', '19500210','mgr@gmail.com', 8747887485,5,14,1)
, ('shricharan', '19890815', 'shri@gmail.com',7512688954,5,14,2)
, ('prasanna', '19781212','prasana.lakshmi@gmail.com',9548963215,5,15,3)
, ('shahul', '19860305','shahul@gmail.com',8745698745,5,16,2)
, ('sivaji', '19500210','sivaji@gmail.com', 8747887485,6,17,1)
, ('balaji', '19701108','balaji@gmail.com',9632156987,6,17,3)
, ('mani', '19920712','mani@gmail.com',9312457896,6,18,2)
, ('gavaskar', '19500210','sg@gmail.com', 8747887485,7,19,1)
, ('amudhan', '19791101','amudhan@gmail.com',7896541236,7,19,2)
, ('ilayaraja', '19880906','ilaya@gmail.com',9129874563,7,20,2)
, ('kapil dev', '19500210','kd@gmail.com', 8747887485,8,21,1)
, ('surya', '19820804','surya@gmail.com',8525898741,8,21,2)
, ('priya', '19870410','priya@gmail.com',9621456321,8,22,3)
, ('raghuvaran', '19500210','ragu@gmail.com', 8747887485,9,23,1)
, ('mohan', '19720106','mohan@gmail.com',8526498741,9,23,2)
, ('mohammed', '19770812','priya@gmail.com',8161456249,9,24,3);

INSERT INTO edu_syllabus ( syllabus_code,syllabus_name,col_dept_id)
VALUES
  ('1001', 'power system analysis', 1)
, ('1002', 'programming data structure', 2)
, ('1003', 'database management system', 3)
, ('1004', 'power electronics', 4)
, ('1005', 'microcontroller', 5)
, ('1006', 'java', 6)
, ('1007', 'dbms', 7)
, ('1008', 'transmission and distribution', 8)
, ('1009', 'compiler design', 9)
, ('1010', 'oops', 10)
, ('1011', 'control system', 11)
, ('1012', 'java', 12)
, ('1013', 'phython', 13)
, ('1014', 'electrical machines', 14)
, ('1015', 'data structure', 15)
, ('1016', 'angular js', 16)
, ('1017', 'dbms', 17)
, ('1018', 'java', 18)
, ('1019', 'switchgear', 19)
, ('1020', 'embedded system', 20)
, ('1021', 'design of machines', 21)
, ('1022', 'data structure', 22)
, ('1023', 'computer graphics', 23)
, ('1024', 'programming structure', 24);



INSERT INTO edu_professor_syllabus (semester,emp_id,syllabus_id)
VALUES
  (2,1,1)
, (3,3,2)
, (2,4,3)
, (4,6,4)
, (5,7,5)
, (8,8,6)
, (1,9,7)
, (6,11,8)
, (7,12,9)
, (3,13,10)
, (4,15,11)
, (6,16,12)
, (5,17,13)
, (7,19,14)
, (2,20,15)
, (3,21,16)
, (1,23,17)
, (4,24,18)
, (8,26,19)
, (5,27,20)
, (3,29,21)
, (2,30,22)
, (4,32,23)
, (6,33,24);

INSERT INTO edu_professor_syllabus (semester,syllabus_id)
VALUES
  (2,25)
, (3,26)
, (4,27);


INSERT INTO edu_student 
(roll_number,stu_name,dob,gender,email,phone,
 address,academic_year,col_dept_id,college_id)
VALUES
  (101101,'Amudhan',19970115,'M','amu@gmail.com'
   ,'8098271077','kilpauk',2014,1,1)
, (101201,'prakash',19970111,'M','prakash@gmail.com'
   ,'9003201651','pallikaranai',2015,1,1)
, (101301,'hari prakash',19971227,'M','hp@gmail.com'
	,'9940262592','kodambakkam',2016,1,1)
, (101401,'prem',19950618,'M','prem@gmail.com'
	,'7410258963','pallavaram',2017,1,1)

, (102101,'Ashraf',19970810,'M','ashraf@gmail.com'
	,'7107780982','pallikaranai',2014,2,1)
, (102201,'bala',19951121,'M','bala@gmail.com'
	,'9658963214','pallavaram',2015,2,1)
, (102301,'jacob',19971112,'M','jacob@gmail.com'
	,'7010203040','pudhukottai',2016,2,1)
, (102401,'M bala',19970507,'M','balu@gmail.com'
	,'9856321478','thiruvannamalai',2017,2,1)

, (103101,'shricharan',19961024,'M','shri@gmail.com'
	,'9717271099','chromepet',2014,3,1)
, (103201,'mohan',19951115,'M','mohan@gmail.com'
	,'9651236214','guindy',2015,3,1)
, (103301,'surendhar',19970419,'M','surendhar@gmail.com'
	,'7010203040','porur',2016,3,1)
, (103401,'karthi',19970509,'M','karthi@gmail.com'
	,'7521021478','chennai',2017,3,1)


, (201101,'arjun',19960404,'M','arjun@gmail.com'
	,'8517271011','pammal',2014,4,2)
, (201201,'arofant',19970125,'M','aro@gmail.com'
	,'8515236252','velachery',2015,4,2)
, (201301,'ashwin',19950209,'M','ashwin@gmail.com'
	,'8110203074','velachery',2016,4,2)
, (201401,'bharath',19970905,'M','bharath@gmail.com'
	,'9621021463','perungulathur',2017,4,2)

, (202101,'aravindhan',19961102,'M','aravid@gmail.com'
	,'7517271063','chengalpattu',2014,5,2)
, (202201,'ignesh',19970125,'M','ignesh@gmail.com'
	,'8515236252','kalpakkam',2015,5,2)
, (202301,'jenito',19950209,'M','jenito@gmail.com'
	,'8110203074','perambur',2016,5,2)
, (202401,'kaushik',19970905,'M','kaushik@gmail.com'
	,'9621021463','ambattur',2017,5,2)

, (203101,'balaji',19960211,'M','balaji@gmail.com'
	,'8527271147','anna nagar',2014,6,2)
, (203201,'jayanth',19971205,'M','jayanth@gmail.com'
	,'9635236212','saidapet',2015,6,2)
, (203301,'kkarthi',19950902,'M','karthi@gmail.com'
	,'9510203026','salem',2016,6,2)
, (203401,'naveen',19970515,'M','naveen@gmail.com'
	,'7531021463','vellore',2017,6,2)

, (204101,'vignesh',19961002,'M','vignesh@gmail.com'
	,'7517271063','nungambakkam',2014,7,2)
, (204201,'venkatesh',19970515,'M','venkateshesh@gmail.com'
	,'8515236252','perambur',2015,7,2)
, (204301,'mani',19951209,'M','mani@gmail.com'
	,'8110203074','taramani',2016,7,2)
, (204401,'kamalesh',19970605,'M','kamal@gmail.com'
	,'9621021463','broadway',2017,7,2)


, (301101,'yuvan',19970119,'M','yuvan@gmail.com'
	,'8098271077','kilpauk',2014,8,3)
, (301201,'rahman',19970112,'M','rahman@gmail.com'
	,'9003201651','pallikaranai',2015,8,3)
, (301301,'samantha',19971210,'F','sam@gmail.com'
	,'9940262592','pallavaram',2016,8,3)
, (301401,'anu',19950612,'F','anu@gmail.com'
	,'7410258963','chittor',2017,8,3)

, (302101,'raja',19970222,'M','raja@gmail.com'
	,'8098271052','tnagar',2014,9,3)
, (302201,'prakash',19970121,'M','prakash@gmail.com'
	,'9113201651','tambaram',2015,9,3)
, (302301,'keerthi',19971211,'F','keerthi@gmail.com'
	,'9630262592','saidapet',2016,9,3)
, (302401,'nithya',19950619,'F','nithya@gmail.com'
	,'7419658963','vyasarpadi',2017,9,3)

, (303101,'selva',19960225,'M','selva@gmail.com'
	,'9157271147','pudhupettai',2014,10,3)
, (303201,'murugan',19971214,'M','murugan@gmail.com'
	,'8435236212','teynampet',2015,10,3)
, (303301,'Ukarthi',19950930,'M','ukarthi@gmail.com'
	,'9300203026','perambur',2016,10,3)
, (303401,'Akrishna',19970510,'M','ak@gmail.com'
	,'8501021463','salem',2017,10,3)

, (401101,'dhoni',19960420,'M','dhoni@gmail.com'
	,'9407271011','hydrabad',2014,11,4)
, (401201,'raina',19970130,'M','raina@gmail.com'
	,'7355236252','secundrabad',2015,11,4)
, (401301,'mithali raj',19950217,'F','raj@gmail.com'
	,'9970203074','chittor',2016,11,4)
, (401401,'pv sindhu',19971020,'F','pv@gmail.com'
	,'7781021463','thirupathi',2017,11,4)

, (402101,'sania',19970811,'F','sania@gmail.com'
	,'8546280982','vizag',2014,12,4)
, (402201,'nehwal',19950211,'F','nehwal@gmail.com'
	,'9658965412','vijayawada',2015,12,4)
, (402301,'virat',19970516,'M','virat@gmail.com'
	,'7010203214','guntur',2016,12,4)
, (402401,'anushka',19970707,'F','anushka@gmail.com'
	,'9856378965','kakinada',2017,12,4)

, (403101,'surya',19960226,'M','surya@gmail.com'
	,'8642671147','nellore',2014,13,4)
, (403201,'jyothika',19970205,'F','jyo@gmail.com'
	,'7643136212','kadapa',2015,13,4)
, (403301,'vijay',19950912,'M','vj@gmail.com'
	,'9371503026','thirupathi',2016,13,4)
, (403401,'ajith',19970525,'M','ak@gmail.com'
	,'7642321463','vizag',2017,13,4)


, (501101,'ravi',19970119,'M','ravi@gmail.com'
	,'7691271077','renigunta',2014,14,5)
, (501201,'dhanush',19961112,'M','dhanush@gmail.com'
	,'8877901651','amaravati',2015,14,5)
, (501301,'arjun',19971218,'M','arjun@gmail.com'
	,'9688562592','hydrabad',2016,14,5)
, (501401,'kalyan',19960612,'M','pk@gmail.com'
	,'7745458963','chittor',2017,14,5)

, (502101,'jadeja',19970520,'M','jaddu@gmail.com'
	,'8098546212','kurnool',2014,15,5)
, (502201,'ashwin',19970710,'M','ashwin@gmail.com'
	,'9174125651','eluru',2015,15,5)
, (502301,'jagadeesan',19970126,'M','jagi@gmail.com'
	,'9654162592','hydrabad',2016,15,5)
, (502401,'kaushik',19950815,'M','kg@gmail.com'
	,'7854628963','nellore',2017,15,5)

, (503101,'dhawan',19960424,'M','sd@gmail.com'
	,'8817271099','secundrabad',2014,16,5)
, (503201,'rohit',19950115,'M','rs@gmail.com'
	,'9746236214','thirupathi',2015,16,5)
, (503301,'nayan',19970819,'F','nayan@gmail.com'
	,'7854203040','guntur',2016,16,5)
, (503401,'shruthi',19970510,'F','sh@gmail.com'
	,'9321421478','kadapa',2017,16,5)

, (601101,'atharva',19960204,'M','atharva@gmail.com'
	,'9546321011','hydrabad',2014,17,6)
, (601201,'siva',19970310,'M','siva@gmail.com'
	,'7302153252','secundrabad',2015,17,6)
, (601301,'vijaysethupathi',19950712,'M','vjs@gmail.com'
	,'9784513074','chittor',2016,17,6)
, (601401,'simbu',19971220,'M','str@gmail.com'
	,'7032141463','thirupathi',2017,17,6)

, (602101,'ntr',19970222,'M','ntr@gmail.com'
	,'9987271052','renigunta',2014,18,6)
, (602201,'prabhas',19970115,'M','prabas@gmail.com'
	,'7788201651','hydrabad',2015,18,6)
, (602301,'tamanna',19970311,'F','tamanna@gmail.com'
	,'8789262592','srikakulam',2016,18,6)
, (602401,'yashika',19950529,'F','yash@gmail.com'
	,'7485658963','amaravati',2017,18,6)


, (701101,'dulquer',19960204,'M','dqs@gmail.com'
	,'7854171011','kochi',2014,19,7)
, (701201,'nivin',19970310,'M','np@gmail.com'
	,'9966236252','thirissur',2015,19,7)
, (701301,'malar',19950127,'F','malar@gmail.com'
	,'9001203074','alapuzha',2016,19,7)
, (701401,'madonna',19970602,'F','ms@gmail.com'
	,'9002121463','munnar',2017,19,7)

, (702101,'sai pallavi',19970616,'F','sp@gmail.com'
	,'8521446212','alapuzha',2014,20,7)
, (702201,'parvathi',19971010,'F','parvathy@gmail.com'
	,'7319525651','kollam',2015,20,7)
, (702301,'mammuti',19970612,'M','mm@gmail.com'
	,'7854162592','munnar',2016,20,7)
, (702401,'mohanlal',19950811,'M','ml@gmail.com'
	,'91024628963','kottayam',2017,20,7)

, (801101,'dravid',19960704,'M','dravid@gmail.com'
	,'9546327541','kollam',2014,21,8)
, (801201,'lakshman',19970810,'M','lk@gmail.com'
	,'7302151236','munnar',2015,21,8)
, (801301,'ganguly',19950912,'M','sg@gmail.com'
	,'9784511452','varkala',2016,21,8)
, (801401,'sachin',19971020,'M','srt@gmail.com'
	,'7032140120','kochi',2017,21,8)

, (802101,'kumar',19970221,'M','bk@gmail.com'
	,'7020271052','thirussur',2014,22,8)
, (802201,'bumrah',19970120,'M','jb@gmail.com'
	,'7002201651','kannur',2015,22,8)
, (802301,'yadhav',19971221,'M','uy@gmail.com'
	,'8899262592','kollam',2016,22,8)
, (802401,'sanju',19950610,'M','ss@gmail.com'
	,'8888658963','munnar',2017,22,8)

, (901101,'chahal',19960904,'M','yc@gmail.com'
	,'9046321011','varkala',2014,23,9)
, (901201,'sundar',19971110,'M','ws@gmail.com'
	,'7802153252','munnar',2015,23,9)
, (901301,'dinesh',19950512,'M','dk@gmail.com'
	,'7084513074','kollam',2016,23,9)
, (901401,'murali',19970120,'M','mv@gmail.com'
	,'8732141463','kochi',2017,23,9)

, (902101,'rishab',19970111,'M','rp@gmail.com'
	,'9987271000','guruvayur',2014,24,9)
, (902201,'shreyas',19970717,'M','si@gmail.com'
	,'7788201611','kochi',2015,24,9)
, (902301,'prithvi',19970310,'M','ps@gmail.com'
	,'8789262511','munnar',2016,24,9)
, (902401,'rahane',19950519,'M','ar@gmail.com'
	,'7485658944','kollam',2017,24,9);







INSERT INTO edu_semester_result
(stu_id,syllabus_id,semester,grade,credits,result_date)
VALUES
  (1,1,7,'A',8,20180604)
, (5,2,7,'B',7.7,20180604)
, (9,3,7,'S',4,20180604)
, (13,4,7,'C',5,20180604)
, (17,5,7,'D',8.2,20180604)
, (21,6,7,'E',7.4,20180604)
, (41,11,7,'S',4,20180503)
, (45,12,7,'A',7.3,20180503)
, (73,19,7,'B',8.3,20180701);



INSERT INTO edu_syllabus ( syllabus_code,syllabus_name,col_dept_id)
VALUES
  ('1025','circuit theory',1)
, ('1024','solid state drives',1)
, ('1025','high voltage engineering',1);


INSERT INTO edu_semester_fee
(semester,amount,paid_status,col_dept_id,stu_id)
VALUES

  (7,50000,'unpaid',1,2)
, (5,50000,'unpaid',1,3)
, (3,50000,'unpaid',1,4)


, (7,50000,'unpaid',2,6)
, (5,50000,'unpaid',2,7)
, (3,50000,'unpaid',2,8)


, (7,50000,'unpaid',3,10)
, (5,50000,'unpaid',3,11)
, (3,50000,'unpaid',3,12)


, (7,50000,'unpaid',4,14)
, (5,50000,'unpaid',4,15)
, (3,50000,'unpaid',4,16)


, (7,50000,'unpaid',5,18)
, (5,50000,'unpaid',5,19)
, (3,50000,'unpaid',5,20)


, (7,50000,'unpaid',6,22)
, (5,50000,'unpaid',6,23)
, (3,50000,'unpaid',6,24)

, (7,50000,'unpaid',7,26)
, (5,50000,'unpaid',7,27)
, (3,50000,'unpaid',7,28)

, (7,50000,'unpaid',8,30)
, (5,50000,'unpaid',8,31)
, (3,50000,'unpaid',8,32)

, (7,50000,'unpaid',9,34)
, (5,50000,'unpaid',9,35)
, (3,50000,'unpaid',9,36)

, (7,50000,'unpaid',10,38)
, (5,50000,'unpaid',10,39)
, (3,50000,'unpaid',10,40);




 