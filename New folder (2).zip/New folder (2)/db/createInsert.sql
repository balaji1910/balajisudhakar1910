CREATE TABLE trn_creator ( id INT AUTO_INCREMENT PRIMARY KEY  /* creating table for trn_creator */
   						        , creator_name VARCHAR(20));





CREATE TABLE trn_male_lead ( id INT AUTO_INCREMENT PRIMARY KEY    /* creating table for trn_male_lead */
   						 		, male_lead_name VARCHAR(20));



CREATE TABLE trn_composer ( id INT AUTO_INCREMENT PRIMARY KEY 	 /* creating table for trn_composer */
   						 	  , composer_name VARCHAR(20));


CREATE TABLE trn_movie ( id INT AUTO_INCREMENT PRIMARY KEY		 /* creating table for trn_movie */
   					  , production_name VARCHAR(20)
						  , released_year YEAR
						  , creator_id INT
						  , male_lead_id INT
						  , composer_id INT
						  , movie_name VARCHAR(30)
						  , KEY dir(creator_id)
						  , KEY act(male_lead_id)
						  , KEY mus(composer_id)
						  
						  , CONSTRAINT fk_movie_creator FOREIGN KEY (creator_id) REFERENCES trn_creator(id)
						  , CONSTRAINT fk_movie_male_lead FOREIGN KEY (male_lead_id) REFERENCES trn_male_lead(id)
						  , CONSTRAINT fk_movie_composer FOREIGN KEY (composer_id) REFERENCES trn_composer(id)
						   
						  );
						  


INSERT INTO trn_creator VALUES(DEFAULT,'ameer');
INSERT INTO trn_creator VALUES(DEFAULT,'shankar');
INSERT INTO trn_creator VALUES(DEFAULT,'k.v.anand');
INSERT INTO trn_creator VALUES(DEFAULT,'hari');
INSERT INTO trn_creator VALUES(DEFAULT,'maniratnam');
INSERT INTO trn_creator VALUES(DEFAULT,'selvaraghavan');	

INSERT INTO trn_male_lead VALUES(DEFAULT,'surya');
INSERT INTO trn_male_lead VALUES(DEFAULT,'rajni');
INSERT INTO trn_male_lead VALUES(DEFAULT,'vikram');
INSERT INTO trn_male_lead VALUES(DEFAULT,'karthi');
INSERT INTO trn_male_lead VALUES(DEFAULT,'kamal');
INSERT INTO trn_male_lead VALUES(DEFAULT,'dhanush');

INSERT INTO trn_composer VALUES(DEFAULT,'yuvan');
INSERT INTO trn_composer VALUES(DEFAULT,'a.r.rahman');
INSERT INTO trn_composer VALUES(DEFAULT,'harris jayaraj');
INSERT INTO trn_composer VALUES(DEFAULT,'ilayaraja');

INSERT INTO trn_movie VALUES(DEFAULT,'aprajith films',2002,1,1,1,'mounam pesiyadhe');
INSERT INTO trn_movie VALUES(DEFAULT,'sun pictures',2010,5,3,2,'ethiran');
INSERT INTO trn_movie VALUES(DEFAULT,'avm productions',2009,3,1,3,'ayan');
INSERT INTO trn_movie VALUES(DEFAULT,'studio green',2009,4,3,3,'singam1');
INSERT INTO trn_movie VALUES(DEFAULT,'studio green',2013,4,3,3,'singam2');
INSERT INTO trn_movie VALUES(DEFAULT,'studio green',2017,4,3,3,'singam3');
INSERT INTO trn_movie VALUES(DEFAULT,'studio green',2007,1,4,1,'paruthiveeran');
INSERT INTO trn_movie VALUES(DEFAULT,'aascar films',2005,2,3,3,'anniyan');
INSERT INTO trn_movie VALUES(DEFAULT,'muktha films',1987,6,5,4,'nayagan');
INSERT INTO trn_movie VALUES(DEFAULT,'madraas talkies',2010,5,3,4,'ravanan');
INSERT INTO trn_movie VALUES(DEFAULT,'lakshmi movies',2006,6,6,1,'pudhupettai');

INSERT INTO trn_movie (movie_name) VALUES('2.0');

INSERT INTO trn_creator (director_name) VALUES('karthik subburaj');