CREATE TABLE edu_university ( univ_code CHAR(4) PRIMARY KEY
									 , univ_name VARCHAR(100) NOT NULL);

CREATE TABLE edu_designation (id INT PRIMARY KEY
									 , desg_name VARCHAR(30) NOT NULL
									 , rank CHAR(1)
									  );

CREATE TABLE edu_department (dept_code CHAR(4) PRIMARY KEY
									, dept_name VARCHAR(50) NOT NULL
									, unive_code CHAR(4)
									, KEY univ(unive_code)
									, CONSTRAINT fk_university_department FOREIGN KEY (unive_code) 
									  REFERENCES edu_university(univ_code)
									 );
									
CREATE TABLE edu_college ( id INT PRIMARY KEY AUTO_INCREMENT
								 , col_code CHAR(4) NOT NULL
								 , col_name VARCHAR(100) NOT NULL
								 , univ_code CHAR(4)
  								 , KEY univ(univ_code)
								 , CONSTRAINT fk_university_college FOREIGN KEY (univ_code) 
								   REFERENCES edu_university(univ_code)																			 						
								 , city VARCHAR(50) NOT NULL 
								 , state VARCHAR(50) NOT NULL
							    , year_opened YEAR(4) NOT NULL
								);
								 
CREATE TABLE edu_college_department ( cdept_id INT PRIMARY KEY 
											   , udep_code CHAR(4)
												, college_id INT
												, KEY dep_code (udep_code)
												, KEY col_id (college_id)	
												, CONSTRAINT fk_udepartment_cdepartment FOREIGN KEY (udep_code) 
												  REFERENCES edu_department(dept_code)
												, CONSTRAINT fk_college_cdepartment FOREIGN KEY (college_id)
												  REFERENCES edu_college(id)
												);
												
CREATE TABLE edu_employee ( empid INT  PRIMARY KEY AUTO_INCREMENT
								  , emp_name VARCHAR(100) NOT NULL
								  , dob DATE NOT NULL
								  , email VARCHAR(100) NOT NULL
								  , phone BIGINT NOT NULL
								  , college_id INT
								  , col_dept_id INT
								  , desgn_id INT
								  , KEY col_id (college_id)	
								  , KEY col_dept (col_dept_id)
								  , KEY desgn (desgn_id)
								  , CONSTRAINT fk_college_emp FOREIGN KEY (college_id)
								    REFERENCES edu_college(id)
								  , CONSTRAINT fk_cdept_emp FOREIGN KEY (col_dept_id) 
								    REFERENCES edu_college_department(cdept_id)
								  , CONSTRAINT fk_designation_emp FOREIGN KEY (desgn_id) 
								    REFERENCES edu_designation(id)
								  );
								  
CREATE TABLE edu_syllabus (id INT PRIMARY KEY AUTO_INCREMENT
                         , syllabus_code CHAR(4) NOT NULL
								 , syllabus_name VARCHAR(100) NOT NULL
								 , col_dept_id INT
								 , KEY col_dept (col_dept_id)
								 , CONSTRAINT fk_cdept_syllabus FOREIGN KEY (col_dept_id) 
								   REFERENCES edu_college_department(cdept_id)	
								 );
								 
CREATE TABLE edu_professor_syllabus ( prof_syllabus_id INT AUTO_INCREMENT PRIMARY KEY
										  		, semester INT NOT NULL
 										  		, emp_id INT
										  		, syllabus_id INT
										  		, KEY emp (emp_id)
										  		, KEY syll_id (syllabus_id)
										  		, CONSTRAINT fk_employee_psyllabus FOREIGN KEY (emp_id) 
												  REFERENCES edu_employee(empid)
										  		, CONSTRAINT fk_syllabus_psyllabus FOREIGN KEY (syllabus_id) 
												  REFERENCES edu_syllabus(id)
										  		)
										  
CREATE TABLE edu_student ( id INT PRIMARY KEY AUTO_INCREMENT
								 , roll_number INT NOT NULL
								 ,	stu_name VARCHAR(100) NOT NULL
								 , dob DATE NOT NULL
								 , gender CHAR(1) NOT NULL
								 , email VARCHAR(50) NOT NULL
								 , phone BIGINT NOT NULL
								 , address VARCHAR(100) NOT NULL
								 , academic_year YEAR(4) NOT NULL
								 , col_dept_id INT
								 , college_id INT
								 , KEY col_dept (col_dept_id)
								 , KEY col_id (college_id)
								 , CONSTRAINT fk_cdept_stu FOREIGN KEY (col_dept_id) 
								   REFERENCES edu_college_department(cdept_id)
								 , CONSTRAINT fk_college_stu FOREIGN KEY (college_id) 
								   REFERENCES edu_college(id)
								 );
								 
CREATE TABLE edu_semester_fee (semester  TINYINT NOT NULL
									  , amount DOUBLE(18,2) NULL
									  , paid_year YEAR(4) NULL
									  , paid_status VARCHAR(10) NOT NULL
									  , col_dept_id INT
									  , stu_id INT
									  , KEY college_dept (col_dept_id)
									  , KEY student_id (stu_id)
									  , CONSTRAINT fk_cdept_sfee FOREIGN KEY (col_dept_id) 
									    REFERENCES edu_college_department(cdept_id)	
									  , CONSTRAINT fk_stud_sfee FOREIGN KEY (stu_id) 
									    REFERENCES edu_student(id)
									  );
									  
CREATE TABLE edu_semester_result ( stu_id INT 
											, syllabus_id INT
											, semester TINYINT NOT NULL	
											, grade VARCHAR(2) NOT NULL
											, credits FLOAT NOT NULL
											, result_date DATE NOT NULL
											, KEY student_id (stu_id)
											, KEY syll_id (syllabus_id)
											, CONSTRAINT fk_cdept_sresult FOREIGN KEY (stu_id) 
											  REFERENCES edu_student(id)
											, CONSTRAINT fk_syllabus_sresult FOREIGN KEY (syllabus_id) 
											  REFERENCES edu_syllabus(id) 
											);								  							 									  								 							  												