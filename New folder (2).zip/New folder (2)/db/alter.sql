ALTER TABLE trn_creator CHANGE COLUMN  creator_name  director_name VARCHAR(20);

ALTER TABLE trn_male_lead CHANGE COLUMN male_lead_name actor_name VARCHAR(20);
  