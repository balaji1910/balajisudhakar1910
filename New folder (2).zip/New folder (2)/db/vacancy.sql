
SELECT syllabus_name
     , emp_name
	  , col_name
	  , dept_name
	  , univ_name 
	  FROM edu_syllabus AS syl LEFT JOIN edu_professor_syllabus AS psyl
	  ON syl.id=psyl.syllabus_id
	  LEFT JOIN edu_employee AS emp
	  ON emp.empid=psyl.emp_id
	  LEFT JOIN edu_college_department AS cdep
	  ON cdep.cdept_id=syl.col_dept_id
	  LEFT JOIN edu_college AS col
	  ON col.id=cdep.college_id
	  LEFT JOIN edu_department As dep
	  ON dep.dept_code=cdep.udep_code
	  LEFT JOIN edu_university AS univ
	  ON univ.univ_code=dep.unive_code;