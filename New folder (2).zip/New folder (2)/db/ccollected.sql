SELECT SUM(amount) AS collected_amount
						  , col_code
						  , amount
						  , paid_year
						  , paid_status
						  , univ_name 
			FROM edu_college AS col 
			INNER JOIN edu_university AS univ
			ON col.univ_code=univ.univ_code
			INNER JOIN edu_student AS stu
			ON stu.college_id=col.id
			INNER JOIN edu_semester_fee AS sfee
			ON sfee.stu_id=stu.id
			WHERE semester=2 AND paid_status='paid' 
			AND univ_name='anna university' 	AND col_code='psg'
			UNION
			
SELECT SUM(amount) AS uncollected_amount
						  , col_code
						  , amount
						  , paid_year
						  , paid_status
						  , univ_name 
			FROM edu_college AS col 
			INNER JOIN edu_university AS univ
			ON col.univ_code=univ.univ_code
			INNER JOIN edu_student AS stu
			ON stu.college_id=col.id
			INNER JOIN edu_semester_fee AS sfee
			ON sfee.stu_id=stu.id
			WHERE semester=7 AND paid_status='unpaid' 
			AND univ_name='anna university' AND col_code='psg';
			
	