
														   

SELECT  roll_number
		, stu_name
		, gender
		, dob
		, email
		, phone
		, address
		, col_name
		, dept_name
		, edu.univ_name
		, city 
		FROM edu_college AS edc 
		INNER JOIN edu_university AS edu ON edc.univ_code=edu.univ_code
		INNER JOIN edu_college_department AS ecd ON edc.id=ecd.college_id
		INNER JOIN edu_department AS dep ON ecd.udep_code=dep.dept_code
		INNER JOIN edu_student AS stu ON ecd.cdept_id=stu.col_dept_id	
		WHERE academic_year=2014 
		AND univ_name='anna university' 
		AND city='chennai';
																								   