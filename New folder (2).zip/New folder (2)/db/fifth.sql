


 SELECT  roll_number
 	    , stu_name
		 , col_name
		 , univ_name
		 , dept_name
		 , semester
		 , grade
		 , credits
		 , result_date 
	 	FROM edu_college AS edc 
	INNER JOIN edu_university AS edu ON edc.univ_code=edu.univ_code
	INNER JOIN edu_college_department AS ecd ON edc.id=ecd.college_id
	INNER JOIN edu_department AS dep ON ecd.udep_code=dep.dept_code
	INNER JOIN edu_student AS stu ON stu.col_dept_id=ecd.cdept_id
	INNER JOIN edu_semester_result AS res ON stu.id=res.stu_id ORDER by col_name;	
	

