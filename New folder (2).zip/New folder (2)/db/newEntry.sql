INSERT INTO edu_semester_fee
(semester,amount,paid_status,col_dept_id,stu_id)
VALUES

  (7,50000,'unpaid',1,2)
, (5,50000,'unpaid',1,3)
, (3,50000,'unpaid',1,4)


, (7,50000,'unpaid',2,6)
, (5,50000,'unpaid',2,7)
, (3,50000,'unpaid',2,8)


, (7,50000,'unpaid',3,10)
, (5,50000,'unpaid',3,11)
, (3,50000,'unpaid',3,12)


, (7,50000,'unpaid',4,14)
, (5,50000,'unpaid',4,15)
, (3,50000,'unpaid',4,16)


, (7,50000,'unpaid',5,18)
, (5,50000,'unpaid',5,19)
, (3,50000,'unpaid',5,20)


, (7,50000,'unpaid',6,22)
, (5,50000,'unpaid',6,23)
, (3,50000,'unpaid',6,24)

, (7,50000,'unpaid',7,26)
, (5,50000,'unpaid',7,27)
, (3,50000,'unpaid',7,28)

, (7,50000,'unpaid',8,30)
, (5,50000,'unpaid',8,31)
, (3,50000,'unpaid',8,32)

, (7,50000,'unpaid',9,34)
, (5,50000,'unpaid',9,35)
, (3,50000,'unpaid',9,36)

, (7,50000,'unpaid',10,38)
, (5,50000,'unpaid',10,39)
, (3,50000,'unpaid',10,40);



