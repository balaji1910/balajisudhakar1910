
SELECT  emp_name
      , phone
		, email
		, desg_name
		, rank
		, col_code
		, col_name
		, city
		, state
		, year_opened
		, edu.univ_code
		, edu.univ_name 
		FROM edu_college AS edc INNER JOIN edu_university AS edu 
		ON edc.univ_code=edu.univ_code
		INNER JOIN edu_college_department AS ecd ON edc.id=ecd.college_id
		INNER JOIN edu_department AS dep ON ecd.udep_code=dep.dept_code
		INNER JOIN edu_employee AS emp ON emp.col_dept_id=ecd.cdept_id
		INNER JOIN edu_designation AS des ON des.id=emp.desgn_id  
		WHERE univ_name='anna university' ORDER BY rank;