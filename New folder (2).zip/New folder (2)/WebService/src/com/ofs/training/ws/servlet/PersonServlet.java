package com.ofs.training.ws.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ofs.training.ws.client.JsonUtil;
import com.ofs.training.ws.exception.AppException;
import com.ofs.training.ws.exception.Error;
import com.ofs.training.ws.exception.ErrorCode;
import com.ofs.training.ws.pojo.Person;
import com.ofs.training.ws.resource.ConnectionManager;
import com.ofs.training.ws.service.AddressService;
import com.ofs.training.ws.service.PersonService;

public class PersonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private PersonService personService = new PersonService(new AddressService());
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

	    response.setContentType("application/json");
	    String id = request.getParameter("id");
	    String include = request.getParameter("include");
	    boolean includeAddress = false;
	    long personId = 0;
	    Error error = new Error();

	    Connection connect = ConnectionManager.initConnection();
	    try {
	        try {
	            includeAddress = Boolean.parseBoolean(include);
	            personId = Long.parseLong(id);
	        } catch (Exception e) {
	            throw new AppException(ErrorCode.ENTER_VALID_INPUT);
	        }

    	    if (Objects.isNull(id)) {
        	        ArrayList<Person> person = personService.readAll(connect, includeAddress);
        	        String personDetail = JsonUtil.toJson(person);
        	        getWriter(personDetail, response);
    	    } else {
    	            Person person = personService.read(connect, includeAddress, personId);
    	            String personDetail = JsonUtil.toJson(person);
    	            getWriter(personDetail, response);
	        }
	    } catch (AppException exception) {
	        String errors;
	        if (exception.getCause() != null) {
    	        errors = String.format("Error: %s Cause: %s ", 
    	                                      exception.getExceptionList().toString(), exception.getCause());
    	        getWriter(JsonUtil.toJson(errors), response);
	        } else {
	            error.setErrors(exception.getExceptionList());
	            getWriter(JsonUtil.toJson(error), response);
	        }
        }

	    ConnectionManager.releaseConnection(connect, true);
	}
	
	    @Override
	    protected void doDelete(HttpServletRequest request, HttpServletResponse response) 
	            throws IOException {

	        String id = request.getParameter("id");
	        Connection connect = null;
	        long personId = 0;
	        Error error = new Error();

	        try {
	            try {
	                personId = Long.parseLong(id);
	            } catch (Exception e) {
	                throw new AppException(ErrorCode.ENTER_VALID_INPUT);
	            }
	            connect = ConnectionManager.initConnection();
                personService.delete(connect, personId);
                getWriter(personId + "deleted Successfully", response);
                ConnectionManager.releaseConnection(connect, true);
	        } catch (AppException exception) {
	            ConnectionManager.releaseConnection(connect, false);
	            String errors;
	            if (exception.getCause() != null) {
	                errors = String.format("Error: %s Cause: %s ", 
	                                              exception.getExceptionList().toString(), exception.getCause());
	                getWriter(JsonUtil.toJson(errors), response);
	            } else {
	                error.setErrors(exception.getExceptionList());
	                getWriter(JsonUtil.toJson(error), response);
	            }
	        }
	   }

	    @Override
	    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws IOException {
	
	        BufferedReader reader = request.getReader();
	        List<String> jsonLines = reader.lines().collect(Collectors.toList());
	        String personJson = String.join("", jsonLines);
	        Person person = JsonUtil.toObject(personJson, Person.class);
	        Connection connect = null;
	        Error error = new Error();

	        try {
	            connect = ConnectionManager.initConnection();
                Person createdPerson = personService.create(connect, person);
                String json = JsonUtil.toJson(createdPerson);
                ConnectionManager.releaseConnection(connect, true);
                getWriter(json, response);
            } catch (AppException exception) {
                ConnectionManager.releaseConnection(connect, false);
                String errors;
                if (exception.getCause() != null) {
                    errors = String.format("Error: %s Cause: %s ", 
                                                  exception.getExceptionList().toString(), exception.getCause());
                    getWriter(JsonUtil.toJson(errors), response);
                } else {
                    error.setErrors(exception.getExceptionList());
                    getWriter(JsonUtil.toJson(error), response);
                }
            }
	    }

	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

            BufferedReader reader = request.getReader();
            List<String> jsonLines = reader.lines().collect(Collectors.toList());
            String personJson = String.join("", jsonLines);
            Person person = JsonUtil.toObject(personJson, Person.class);
            Connection connect = null;
            Error error = new Error();

            try {
                connect = ConnectionManager.initConnection();
                Person createdPerson = personService.update(connect, person);
                String json = JsonUtil.toJson(createdPerson);
                ConnectionManager.releaseConnection(connect, true);
                getWriter(json, response);
            } catch (AppException exception) {
                ConnectionManager.releaseConnection(connect, false);
                String errors;
                if (exception.getCause() != null) {
                    errors = String.format("Error: %s Cause: %s ", 
                                                  exception.getExceptionList().toString(), exception.getCause());
                    getWriter(JsonUtil.toJson(errors), response);
                } else {
                    error.setErrors(exception.getExceptionList());
                    getWriter(JsonUtil.toJson(error), response);
                }
            }
	    }

	    private void getWriter(String json, HttpServletResponse response) throws IOException {
	        PrintWriter writer = response.getWriter();
	        writer.println(json);
	        writer.close();
	    }
}
