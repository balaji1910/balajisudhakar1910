package com.ofs.training.ws.exception;

import java.util.ArrayList;
import java.util.List;

public class Error {

    List<ErrorCode> errors = new ArrayList<>();

    public List<ErrorCode> getErrors() {
        return errors;
    }

    public void setErrors(List<ErrorCode> errors) {
        this.errors = errors;
    }

    @Override
    public String toString() {
        return String.format("Error [errors=%s]", errors);
    }
}
