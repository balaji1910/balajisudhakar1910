package com.ofs.training.ws.exception;

import java.util.ArrayList;
import java.util.List;

public class AppException extends RuntimeException {

    private List<ErrorCode> errors;
    Exception cause;

    public AppException(List<ErrorCode> errorList) {
        this.errors = errorList;
    }

    public AppException(ErrorCode databaseErr, Exception cause, String message) {
        super(message, cause);
        errors = new ArrayList<>();
        errors.add(databaseErr);
    }

    public AppException(ErrorCode databaseErr) {
        errors = new ArrayList<>();
        errors.add(databaseErr);
    }

    public AppException(Exception cause) {
//        super(e);
        this(ErrorCode.UNKNOWN_ERROR, cause, cause.getMessage());
    }

    public List<ErrorCode> getExceptionList() {
        return errors;
    }

    @Override
    public String toString() {
        if (getCause() != null) {
            return String.format("errors=%s, cause=%s", errors, getCause());
        } else {
            return String.format("errors=%s", errors);
        }
    }
}
