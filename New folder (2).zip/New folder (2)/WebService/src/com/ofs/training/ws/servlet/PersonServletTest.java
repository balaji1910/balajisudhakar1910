package com.ofs.training.ws.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ofs.training.ws.client.HttpMethod;
import com.ofs.training.ws.client.JsonUtil;
import com.ofs.training.ws.client.RequestHelper;
import com.ofs.training.ws.exception.ErrorCode;
import com.ofs.training.ws.exception.Error;
import com.ofs.training.ws.pojo.Address;
import com.ofs.training.ws.pojo.Person;

public class PersonServletTest {

    RequestHelper requestHelper;

    @BeforeClass()
    private void setup() throws Exception {
        requestHelper = new RequestHelper();
    }

    @Test(dataProvider = "testRead", priority = 3)
    private void testRead(String uri, Person expectedPerson) throws Exception {
        RequestHelper.setBaseUrl("http://localhost:8080/ws/");
            Person person = requestHelper.setMethod(HttpMethod.GET).requestObject(uri, Person.class);
            Assert.assertEquals(JsonUtil.toJson(person), JsonUtil.toJson(expectedPerson));
    }

    @DataProvider
    private Object[][] testRead() {
        String uri = "person?id=1&include=true";
        Person person = new Person(1, "HariHaran", "sekar", "hari@ofs", Date.valueOf("1996-06-19"), 
                new Address(1, "kk nagar", "chennai", 600028));
        
        return new Object[][] {
            {uri, person}
        };
    }

    @Test(dataProvider = "testRead_negative", priority = 3)
    private void testRead_negative(String uri, Error error) throws Exception {
        RequestHelper.setBaseUrl("http://localhost:8080/ws/");
        Error errorCode = requestHelper.setMethod(HttpMethod.GET).requestObject(uri, Error.class);
        Assert.assertEquals(errorCode.toString(), error.toString());
    }

    @DataProvider
    private Object[][] testRead_negative() {
        String uri = "person?id=abc&include=true";
        Error error = new Error();
        List<ErrorCode> errors = new ArrayList<>();
        errors.add(ErrorCode.ENTER_VALID_INPUT);
        error.setErrors(errors);

        return new Object[][] {
            {uri, error}
        };
    }

    @Test(dataProvider = "testReadAll", priority = 4)
    private void testReadAll(String uri, List<Person> expectedList) throws Exception {
            RequestHelper.setBaseUrl("http://localhost:8080/ws/");
            String personDetail = requestHelper.setMethod(HttpMethod.GET).requestString(uri);
            List<Person> Person = JsonUtil.toList(personDetail, Person.class);
            Assert.assertEquals(JsonUtil.toJson(Person), JsonUtil.toJson(expectedList));
    }

    @DataProvider
    private Object[][] testReadAll() {
        String uri = "person?include=true";

        List<Person> personList = new ArrayList<>();
        personList.add(new Person(1, "HariHaran", "sekar", "hari@ofs", Date.valueOf("1996-06-19"), 
                       new Address(1, "kk nagar", "chennai", 600028)));
        personList.add(new Person(2,"Naveen", "raj", "naveen@ofs", Date.valueOf("1996-07-09"), 
                       new Address(2, "Tnagar", "chennai", 600075)));
        personList.add(new Person(3, "almas", "mahamed", "almas@ofs", Date.valueOf("1996-07-09"), 
                       new Address(3, "nagar", "chennai", 600070)));
        personList.add(new Person(4, "prasanna", "mahesh", "lpk@ofs", Date.valueOf("1996-07-09"), 
                       new Address(4, "nagar", "chennai", 600070)));
        personList.add(new Person(5, "mani", "bharathi", "mani@ofs", Date.valueOf("1997-01-12"), 
                       new Address(5, "Tnagar", "chennai", 600075)));
        personList.add(new Person(6, "aravind", "Krishna", "ak@ofs", Date.valueOf("1997-01-01"), 
                       new Address(6, "taramani", "chennai", 600010)));
        personList.add(new Person(7, "karthi", "kk", "kk@ofs", Date.valueOf("1996-06-23"), 
                       new Address(7, "taramani", "chennai", 600010)));
        personList.add(new Person(8, "karthi", "uk", "uk@ofs", Date.valueOf("1996-06-23"), 
                       new Address(8, "perambur", "chennai", 600070)));
        personList.add(new Person(9, "Tamil", "arasan", "tamil@ofs", Date.valueOf("1996-06-19"), 
                       new Address(9, "food street", "chennai", 600075)));
        return new Object[][] {
            {uri, personList}
        };
    }

    @Test
    private void testCreate() throws Exception {
        List<Person> persons = csvParser();
        RequestHelper.setBaseUrl("http://localhost:8080/ws/");
        String uri = "person";
        for (Person eachPerson : persons) {
            Person createdPerson = requestHelper.setInput(eachPerson)
                    .setMethod(HttpMethod.PUT)
                    .requestObject(uri, Person.class);
            eachPerson.setId(createdPerson.getId());
            eachPerson.setAddress(createdPerson.getAddress());
            Assert.assertEquals(JsonUtil.toJson(createdPerson), JsonUtil.toJson(eachPerson));
        }
    }


    @Test(dataProvider = "testUpdate", priority = 2)
    private void testUpdate(String uri, Person person) throws Exception {
        RequestHelper.setBaseUrl("http://localhost:8080/ws/");
            Person createdPerson = requestHelper.setInput(person)
                    .setMethod(HttpMethod.POST)
                    .requestObject(uri, Person.class);
            Assert.assertEquals(JsonUtil.toJson(createdPerson), JsonUtil.toJson(person));
    }

    @DataProvider
    private Object[][] testUpdate() {
        Person person = new Person(10, "vignesh", "manoharan", "vigneshManoharan@ofs", Date.valueOf("1996-06-19"), 
                new Address(10, "nungambakkam", "salem", 600022));
        String uri = "person";
        return new Object[][] {
            {uri, person}
        };
    }

    private List<Person> csvParser() throws IOException {
        InputStream inputStream = PersonServletTest.class.getClassLoader().getResourceAsStream("person.csv");
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
        BufferedReader reader = new BufferedReader(inputStreamReader);
        String input;
        List<Person> persons = new ArrayList<>();
        while ((input = reader.readLine()) != null) {
            String[] person = input.split(",");
            persons.add(new Person(person[0], person[1], person[2], 
                    Date.valueOf(person[3]),
                        new Address(person[4], person[5], Integer.parseInt(person[6]))));
        }
        return persons;
    }

    @Test(priority = 4)
    private void testDelete() throws Exception {
            RequestHelper.setBaseUrl("http://localhost:8080/ws/");
            String uri = "person?id=11";
            requestHelper.setMethod(HttpMethod.DELETE);
            String response = requestHelper.requestString(uri);
            System.out.println(response);
    }
}
