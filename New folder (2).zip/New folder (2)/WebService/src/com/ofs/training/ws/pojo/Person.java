package com.ofs.training.ws.pojo;

import java.sql.Date;
import java.sql.Timestamp;

public class Person {

    private long id;
    private String firstName;
    private String lastName;
    private String mailId;
    private Date birthDate;
    private Timestamp createdDate;
    private Address address;

    public Person(String firstName, String lastName, String mailId, Date birthDate, Address address) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.mailId = mailId;
        this.birthDate = birthDate;
        this.address = address;
    }
    public Person(long id, String firstName, String lastName, String mailId, Date birthDate, 
                  Address address) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.mailId = mailId;
        this.birthDate = birthDate;
        this.address = address;
    }

    public Person() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }


    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMailId() {
        return mailId;
    }

    public void setMailId(String mailId) {
        this.mailId = mailId;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public Timestamp getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = createdDate;
    }


    public Address getAddress() {
        return address;
    }

    public void setAddress(Address addressId) {
        this.address = addressId;
    }

    @Override
    public String toString() {
        String output = null;
        if (address.getStreet() != null) {
            String string = "Person [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", "
                    + "mailId=" + mailId + ", birthDate=" + birthDate 
                    + ", addressId="
                    + address + "]";
            output = string;
        } else {
            String string = "Person [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", "
                    + "mailId=" + mailId + ", birthDate=" + birthDate 
                    + "]";
            output = string;
        }
        return output;
    }
}
