package com.ofs.training.ws.service;

import static com.ofs.training.ws.constantInterface.SQLQuery.CREATE_PERSON_QUERY;
import static com.ofs.training.ws.constantInterface.SQLQuery.DELETE_PERSON_QUERY;
import static com.ofs.training.ws.constantInterface.SQLQuery.DUPLICATE_EMAIL_QUERY;
import static com.ofs.training.ws.constantInterface.SQLQuery.DUPLICATE_NAME_QUERY;
import static com.ofs.training.ws.constantInterface.SQLQuery.READALL_PERSON_PAGING_QUERY;
import static com.ofs.training.ws.constantInterface.SQLQuery.READALL_PERSON_QUERY;
import static com.ofs.training.ws.constantInterface.SQLQuery.READ_PERSON_QUERY;
import static com.ofs.training.ws.constantInterface.SQLQuery.UPDATE_PERSON_QUERY;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.ofs.training.ws.constantInterface.TableColumn;
import com.ofs.training.ws.exception.AppException;
import com.ofs.training.ws.exception.ErrorCode;
import com.ofs.training.ws.pojo.Address;
import com.ofs.training.ws.pojo.Person;
import com.ofs.training.ws.resource.ConnectionManager;

public class PersonService {

    private AddressService addressService = new AddressService();

    public PersonService(AddressService addressService) {
        this.addressService = addressService;
    }

    public Person create(Person person) {
        Connection connect = ConnectionManager.getConnection();
        Address address = person.getAddress();
        List<ErrorCode> errors = new ArrayList<>();

        try {
            address = addressService.create(address);
        } catch (AppException exception) {
            if (exception.getCause() != null) {
                throw new AppException(ErrorCode.DATABASE_ERR, exception, exception.getMessage());
            }
            errors = exception.getExceptionList();
        }

        validate(person, errors);

        try {
            PreparedStatement statement = connect.prepareStatement(CREATE_PERSON_QUERY, 
                                                                   Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, person.getFirstName());
            statement.setString(2, person.getLastName());
            statement.setString(3, person.getMailId());
            statement.setLong(4, address.getId());
            statement.setDate(5, person.getBirthDate());
            statement.setString(6, person.getPassword());
            statement.setBoolean(7, person.getAdmin());
            statement.executeUpdate();
            ResultSet result = statement.getGeneratedKeys();
            result.next();
            person.setId(result.getLong(1));
        } catch (Exception exception) {
            throw new AppException(ErrorCode.DATABASE_ERR, exception, 
                                   exception.getMessage());
        }

        if (person.getId() == 0) {
            errors.add(ErrorCode.ID_ERR);
            throw new AppException(errors);
        }
        return person;
    }

    private boolean isEmpty(String personDetail) {
        return Objects.isNull(personDetail) || ("").equals(personDetail.trim());
    }

    private void validate(Person person, List<ErrorCode> errorList) {

//        Connection connect = ConnectionManager.getConnection();
        if (isEmpty(person.getFirstName())) {
            errorList.add(ErrorCode.FIRSTNAME_ERR);
        }

        if (isEmpty(person.getLastName())) {
            errorList.add(ErrorCode.LASTNAME_ERR);
        }

        boolean isDuplicatePerson = isDuplicatePerson(person);
        if (isDuplicatePerson) {
            errorList.add(ErrorCode.NAME_ALREADY_EXIST);
        }

        boolean isDuplicateEmail = isDuplicateEmail(person);
        if (isDuplicateEmail) {
            errorList.add(ErrorCode.EMAIL_ALREADY_EXIST);
        }

        if (Objects.isNull(person.getBirthDate())) {
            errorList.add(ErrorCode.BIRTHDATE_ERR);
        }

        if (person.getBirthDate() != null) {
            java.util.Date today = new java.util.Date();
            java.sql.Date now = new java.sql.Date(today.getTime());
            if (now.compareTo(person.getBirthDate()) == -1) {
                errorList.add(ErrorCode.BIRTHDATE_INVALID);
            }
        }
        if (errorList.isEmpty() != true) {
            throw new AppException(errorList);
        }
    }

    private boolean isDuplicateEmail(Person person) {
        Connection connect = ConnectionManager.getConnection();
        int count = 0;
        try {
            PreparedStatement statement = connect.prepareStatement(DUPLICATE_EMAIL_QUERY);
            statement.setString(1, person.getMailId());
            statement.setLong(2, person.getId());
            ResultSet result = statement.executeQuery();
        while (result.next()) {
            count++; /*= result.getInt(TableColumn.DUPLICATE_EMAIL);*/
        }
      } catch (Exception exception) {
          throw new AppException(ErrorCode.ERROR_IN_VERIFICATION, exception, exception.getMessage());
      }
        return count > 0 ? true : false;
    }

    private boolean isDuplicatePerson(Person person) {
        Connection connect = ConnectionManager.getConnection();
        int idCount = 0;
        try {
            PreparedStatement statement = connect.prepareStatement(DUPLICATE_NAME_QUERY);
            statement.setString(1, person.getFirstName());
            statement.setString(2, person.getLastName());
            statement.setLong(3, person.getId());
            ResultSet anotherResult = statement.executeQuery();
            while (anotherResult.next()) {
                idCount++;/* = anotherResult.getInt(TableColumn.DUPLICATE_NAME);*/
            }
        } catch (Exception exception) {
            throw new AppException(ErrorCode.ERROR_IN_VERIFICATION, exception, exception.getMessage());
        }
        return idCount > 0 ? true : false;
    }

    public Person read(boolean includeAddress, long id) {

        Connection connect = ConnectionManager.getConnection();
        Person person = new Person();
        try {
            PreparedStatement statement = connect.prepareStatement(READ_PERSON_QUERY);
            statement.setLong(1, id);
            ResultSet result = statement.executeQuery();
            if (result.next()) {
                person = constructPerson(result, person);
            } else {
                throw new AppException(ErrorCode.NO_RECORD_FOUND);
            }
        } catch (Exception exception) {
            throw new AppException(ErrorCode.READ_OPERATION_FAILED, exception, exception.getMessage());
        }

        if (includeAddress) {
            Address address = person.getAddress();
            long addressId = address.getId();
            Address addressDetail = addressService.read(addressId);
            person.setAddress(addressDetail);
        }
        return person;
    }


    public Person constructPerson(ResultSet result, Person person) {
        try {
            person.setId(result.getLong(TableColumn.ID));
            person.setFirstName(result.getString(TableColumn.FIRST_NAME));
            person.setLastName(result.getString(TableColumn.LAST_NAME));
            person.setMailId(result.getString(TableColumn.EMAIL));
            person.setBirthDate(result.getDate(TableColumn.BIRTH_DATE));
            Address address = new Address();
            address.setId(result.getInt(TableColumn.ADDRESS_ID));
            person.setAddress(address);
        } catch (Exception exception) {
            throw new AppException(ErrorCode.DATABASE_ERR, exception, exception.getMessage());
        }
        return person;
    }

    public ArrayList<Person> readAll(boolean includeAddress) {
        Connection connect = ConnectionManager.getConnection();
        ArrayList<Person> persons = new ArrayList<>();
        try {
            PreparedStatement statement = connect.prepareStatement(READALL_PERSON_QUERY);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                Address address = new Address();
                Person person = new Person();
                person = constructPerson(result, person);
                address.setId(result.getLong(TableColumn.ADDRESS_ID));
                if (includeAddress) {
                    address = addressService.read(address.getId());
                    person.setAddress(address);
                }
                persons.add(person);
            }
        } catch (Exception exception) {
            throw new AppException(ErrorCode.READ_OPERATION_FAILED, exception, exception.getMessage());
        }
        return persons;
    }


    public ArrayList<Person> readAll(int offset, boolean includeAddress) {
        ArrayList<Person> persons = new ArrayList<>();
        Connection connect = ConnectionManager.getConnection();
        try {
            PreparedStatement statement = connect.prepareStatement(READALL_PERSON_PAGING_QUERY);
            statement.setInt(1, offset);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                Address address = new Address();
                Person person = new Person();
                person = constructPerson(result, person);
                address.setId(result.getLong(TableColumn.ADDRESS_ID));
                if (includeAddress) {
                    Address addressDetail = addressService.read(address.getId());
                    person.setAddress(addressDetail);
                }
                persons.add(person);
            }
        } catch (Exception exception) {
            throw new AppException(ErrorCode.DATABASE_ERR, exception, exception.getMessage());
        }
        return persons;
    }

    public void delete(long id) {
        Connection connect = ConnectionManager.getConnection();
        Person person = read(true, id);
        try {
            PreparedStatement statement = connect.prepareStatement(DELETE_PERSON_QUERY);
            statement.setLong(1, id);
            statement.executeUpdate();
        } catch (Exception exception) {
            throw new AppException(ErrorCode.DELETE_OPERATION_FAILED, exception, exception.getMessage());
        }
        Address address = person.getAddress();
        addressService.delete(address);
    }

    public Person update(Person person) {
        ArrayList<ErrorCode> errors = new ArrayList<>();
        Connection connect = ConnectionManager.getConnection();
        try {
            validate(person, errors);
        } catch (AppException err) {
            throw new AppException(errors);
        }
        try {
            PreparedStatement statement = connect.prepareStatement(UPDATE_PERSON_QUERY);
            statement.setString(1, person.getFirstName());
            statement.setString(2, person.getLastName());
            statement.setString(3, person.getMailId());
            statement.setDate(4, person.getBirthDate());
            statement.setLong(5, person.getId());
            statement.executeUpdate();
        } catch (Exception exception) {
            throw new AppException(ErrorCode.UPDATE_OPERATION_FAILED, exception, exception.getMessage());
        }
        if (person.getAddress() != null) {
            Address address = person.getAddress();
            addressService.update(address);
        }
        return person;
    }
}
