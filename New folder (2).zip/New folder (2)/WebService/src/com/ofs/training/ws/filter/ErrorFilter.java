package com.ofs.training.ws.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.ofs.training.ws.client.JsonUtil;
import com.ofs.training.ws.exception.AppException;
import com.ofs.training.ws.exception.Error;

public class ErrorFilter implements Filter{

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        PrintWriter writer = response.getWriter();
        try {
            chain.doFilter(request, response);
        } catch (Exception e) {
            if (e instanceof AppException) {
                Error error = new Error();
                error.setErrors(((AppException) e).getExceptionList());
                writer.write(error.toString());
            } else {
                writer.write("INTERNAL SERVER ERROR");
            }
        }
    }

    @Override
    public void destroy() {
        // TODO Auto-generated method stub
        
    }

    
}
