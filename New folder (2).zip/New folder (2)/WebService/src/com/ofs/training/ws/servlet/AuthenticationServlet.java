package com.ofs.training.ws.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ofs.training.ws.client.JsonUtil;
import com.ofs.training.ws.exception.AppException;
import com.ofs.training.ws.exception.Error;
import com.ofs.training.ws.pojo.Person;
import com.ofs.training.ws.service.AuthenticationService;

public class AuthenticationServlet extends HttpServlet{


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines().collect(Collectors.toList());
        String personJson = String.join("", jsonLines);
        Person person = JsonUtil.toObject(personJson, Person.class);
        PrintWriter writer = response.getWriter();
        AuthenticationService service = new AuthenticationService();
        String userName = person.getMailId();
        String password = person.getPassword();
        Error error = new Error();

        try {
            HttpSession session = request.getSession();
            Person authenticatedPerson = service.login(userName, password);
            session.setAttribute("person", authenticatedPerson);
            session.setAttribute("user", authenticatedPerson);
            response.setHeader("sessionId", session.getId());
            writer.write(JsonUtil.toJson(session.getId()));
        } catch (AppException e) {
            error.setErrors(e.getExceptionList());
            writer.write(JsonUtil.toJson(error));
        }
    }

    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        session.invalidate();
    }
}
