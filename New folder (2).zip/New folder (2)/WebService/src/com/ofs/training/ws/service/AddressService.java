package com.ofs.training.ws.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.ofs.training.ws.exception.AppException;
import com.ofs.training.ws.exception.ErrorCode;
import com.ofs.training.ws.pojo.Address;

import static com.ofs.training.ws.service.SQLQuery.CREATE_ADDRESS_QUERY;
import static com.ofs.training.ws.service.SQLQuery.DELETE_ADDRESS_QUERY;
import static com.ofs.training.ws.service.SQLQuery.READALL_ADDRESS_QUERY;
import static com.ofs.training.ws.service.SQLQuery.READ_ADDRESS_QUERY;
import static com.ofs.training.ws.service.SQLQuery.UPDATE_ADDRESS_QUERY;
import static com.ofs.training.ws.service.SQLQuery.SEARCH_ADDRESS_QUERY;

public class AddressService {

    public Address create(Connection connect, Address address) {
        List<ErrorCode> errors = new ArrayList<>();
        validate(address, connect, errors);
        try {
            PreparedStatement statement = connect.prepareStatement(CREATE_ADDRESS_QUERY, 
                                                                   Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, address.getStreet());
            statement.setString(2, address.getCity());
            statement.setInt(3, address.getPostalCode());
            statement.executeUpdate();
            ResultSet result = statement.getGeneratedKeys();
            result.next();
            address.setId(result.getLong(1));
            if (address.getId() == 0) {
                errors.add(ErrorCode.ID_ERR);
                throw new AppException(errors);
            }
            return address;
        } catch (Exception exception) {
            throw new AppException(ErrorCode.CREATE_OPERATION_FAILED, exception, exception.getMessage());
        }
    }

    private boolean isEmpty(String addressDetail) {
        return Objects.isNull(addressDetail) || ("").equals(addressDetail);
    }

    private void validate(Address address, Connection connect, 
                                             List<ErrorCode> errorList) {
        if (address.getPostalCode() == 0) {
            errorList.add(ErrorCode.POSTAL_CODE_ERR);
        }
        if (isEmpty(address.getStreet())) {
            errorList.add(ErrorCode.STREET_ERR);
        }
        if (isEmpty(address.getCity())) {
            errorList.add(ErrorCode.CITY_ERR);
        }
        String postalCode = String.valueOf(address.getPostalCode());
        if (postalCode.length() < 6) {
            errorList.add(ErrorCode.POSTAL_CODE_INVALID);
        }
        if (errorList.isEmpty() != true) {
            throw new AppException(errorList);
        }
    }

    public Address read(Connection connect, long addressId) {

        Address address = new Address();
        try {
            PreparedStatement statement = connect.prepareStatement(READ_ADDRESS_QUERY);
            statement.setLong(1, addressId);
            ResultSet result = statement.executeQuery();
            if (result.next()) {
                address = constructAddress(address, result);
            } else {
                throw new AppException(ErrorCode.NO_RECORD_FOUND);
            }
        } catch (Exception exception) {
            throw new AppException(ErrorCode.READ_OPERATION_FAILED, exception, exception.getMessage());
        }
        return address;
    }

    private Address constructAddress(Address address, ResultSet result) {
        try {
            address.setId(result.getLong(TableColumn.ID));
            address.setStreet(result.getString(TableColumn.STREET));
            address.setCity(result.getString(TableColumn.CITY));
            address.setPostalCode(result.getInt(TableColumn.POSTAL_CODE));
        } catch (Exception exception) {
            throw new AppException(ErrorCode.DATABASE_ERR, exception, exception.getMessage());
        }
        return address;
    }

//    public ArrayList<Address> search(Connection connect, Address address) {
//        String query = new StringBuilder()
//                .append("SELECT street, city, postal_code, id")
//                .append(" FROM trn_address WHERE city        ")
//                .append(" = ?                                ")
//                .append("OR street                           ")
//                .append(" = ?                                ")
//                .append("OR postal_code                      ")
//                .append(" = ?;                               ")
//                .toString();
//        ArrayList<Address> addresses = new ArrayList<>();
//        try {
//            PreparedStatement statement = connect.prepareStatement();
//            statement.setString(1, address.getCity());
//            statement.setString(2, address.getStreet());
//            statement.setInt(3, address.getPostalCode());
//            ResultSet result = statement.executeQuery();
//            while (result.next()) {
//                Address addressDetail = new Address();
//                constructAddress(addressDetail, result);
//                addresses.add(addressDetail);
//            }
//        } catch (Exception exception) {
//            throw new AppException(ErrorCode.SEARCH_OPERATION_FAILED, exception, exception.getMessage());
//        }
//        return addresses;
//    }

//    public ArrayList<Address> search(Connection connect, Object include) {
//        StringBuilder query = new StringBuilder();
//        if (include instanceof String) {
//        query.append("SELECT street, city, postal_code, id")
//             .append(" FROM trn_address WHERE city        ")
//             .append("LIKE '%")
//             .append(include)
//             .append("%'")
//             .append("OR street LIKE '%")
//             .append(include)
//             .append("%'")
//             .toString();
//        }
//        if (include instanceof Integer) {
//           query.append("SELECT street, city, postal_code, id       ")
//                .append(" FROM trn_address WHERE postal_code        ")
//                .append("LIKE '%")
//                .append(include)
//                .append("%'")
//                .toString();
//        }
//        ArrayList<Address> addressList = new ArrayList<>();
//        try {
//            PreparedStatement statement = connect.prepareStatement(query.toString());
//            ResultSet result = statement.executeQuery();
//            while (result.next()) {
//                Address addressDetail = new Address();
//                constructAddress(addressDetail, result);
//                addressList.add(addressDetail);
//            }
//        } catch (SQLException e) {
//            throw new AppException(ErrorCode.DATABASE_ERR, e.getCause());
//        }
//        return addressList;
//    }

//    public ArrayList<Address> search(Connection connect, Object include) {
//        StringBuilder query = new StringBuilder();
//            query.append("SELECT street, city, postal_code, id")
//            .append(" FROM trn_address WHERE city        ")
//            .append("LIKE '%")
//            .append(include)
//            .append("%'")
//            .append("OR street LIKE '%")
//            .append(include)
//            .append("%'")
//            .append("OR postal_code LIKE '%")
//            .append(include)
//            .append("%'")
//            .toString();
//        ArrayList<Address> addressList = new ArrayList<>();
//        try {
//            PreparedStatement statement = connect.prepareStatement(query.toString());
//            ResultSet result = statement.executeQuery();
//            while (result.next()) {
//                Address addressDetail = new Address();
//                constructAddress(addressDetail, result);
//                addressList.add(addressDetail);
//            }
//        } catch (Exception exception) {
//            throw new AppException(ErrorCode.SEARCH_OPERATION_FAILED, exception, exception.getMessage());
//        }
//        return addressList;
//    }

    public ArrayList<Address> search(Connection connect, String[] fields, String searchText) {

        ArrayList<String> postalCode = new ArrayList<>();
        postalCode.add("postalCode");
        postalCode.add("postal_code");
        postalCode.add("POSTALCODE");
        postalCode.add("postalcode");
        postalCode.add("PostalCode");
        postalCode.add("pincode");
        postalCode.add("PINCODE");
        postalCode.add("PinCode");
        postalCode.add("pinCode");

        ArrayList<String> street = new ArrayList<>();
        street.add("street");
        street.add("STREET");

        ArrayList<String> city = new ArrayList<>();
        city.add("city");
        city.add("CITY");

        ArrayList<Address> addresses = new ArrayList<>();
        try {
            for (String field : fields) {
                if (postalCode.contains(field)) { field = TableColumn.POSTAL_CODE; }
                if (street.contains(field)) { field = TableColumn.STREET; }
                if (city.contains(field)) { field = TableColumn.CITY; }
                    SEARCH_ADDRESS_QUERY.append(field).append(" like ").append("'%").append(searchText)
                    .append("%'")
                    .append(" OR ");
            }
            String search = SEARCH_ADDRESS_QUERY.toString();
            search = search.substring(0, search.length() - 3);
            PreparedStatement statement = connect.prepareStatement(search);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                Address address = new Address();
                constructAddress(address, result);
                addresses.add(address);
            }
        } catch (Exception exception) {
            throw new AppException(ErrorCode.SEARCH_OPERATION_FAILED, exception, exception.getMessage());
        }
        return addresses;
    }

    public void delete(Connection connect, Address address) {
        try {
            PreparedStatement statement = connect.prepareStatement(DELETE_ADDRESS_QUERY);
            statement.setLong(1, address.getId());
            statement.executeUpdate();
        } catch (SQLException sqlException) {
            throw new AppException(ErrorCode.DATABASE_ERR, sqlException, sqlException.getMessage());
        }
    }

    public Address update(Connection connect, Address address) {
        List<ErrorCode> errors = new ArrayList<>();
        validate(address, connect, errors);
        if (!errors.isEmpty()) {
            throw new AppException(errors);
        }
        try {
            PreparedStatement statement = connect.prepareStatement(UPDATE_ADDRESS_QUERY);
            statement.setString(1, address.getCity());
            statement.setString(2, address.getStreet());
            statement.setInt(3, address.getPostalCode());
            statement.setLong(4, address.getId());
            statement.executeUpdate();
        } catch (SQLException sqlException) {
            throw new AppException(ErrorCode.DATABASE_ERR, sqlException, sqlException.getMessage());
        }
        return address;
    }

    public ArrayList<Address> readAll(Connection connect) {
        ArrayList<Address> addresses = new ArrayList<>();
        try {
            PreparedStatement statement = connect.prepareStatement(READALL_ADDRESS_QUERY);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                Address address = new Address();
                constructAddress(address, result);
                addresses.add(address);
            }
        } catch (SQLException sqlException) {
            throw new AppException(ErrorCode.DATABASE_ERR, sqlException, sqlException.getMessage());
        }
        return addresses;
    }
}
