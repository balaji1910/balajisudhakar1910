package com.ofs.training.ws.servlet;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ofs.training.ws.client.HttpMethod;
import com.ofs.training.ws.client.JsonUtil;
import com.ofs.training.ws.client.RequestHelper;
import com.ofs.training.ws.exception.Error;
import com.ofs.training.ws.exception.ErrorCode;
import com.ofs.training.ws.pojo.Address;

public class AddressServletTest {

    RequestHelper requestHelper;

    @BeforeClass()
    private void setup() throws Exception {
        requestHelper = new RequestHelper();
    }

    @Test(dataProvider = "testRead")
    private void testRead(String uri, Address expectedAddress) throws Exception {
            RequestHelper.setBaseUrl("http://localhost:8080/ws/");
            Address address = requestHelper.setMethod(HttpMethod.GET).requestObject(uri, Address.class);
            Assert.assertEquals(JsonUtil.toJson(address), JsonUtil.toJson(expectedAddress));
    }

    @DataProvider
    private Object[][] testRead() {
        String uri = "address?id=1";
        Address expectedAddress = new Address(1, "kk nagar", "chennai", 600028);

        String anotherUri = "address?id=2";
        Address expectedAddressTwo = new Address(2, "Tnagar", "chennai", 600075);
        return new Object[][] {
            {uri, expectedAddress}, 
            {anotherUri, expectedAddressTwo}
        };
    }

    @Test(dataProvider = "testRead_negative", priority = 3)
    private void testRead_negative(String uri, Error error) throws Exception {
        RequestHelper.setBaseUrl("http://localhost:8080/ws/");
        Error errorCode = requestHelper.setMethod(HttpMethod.GET).requestObject(uri, Error.class);
        Assert.assertEquals(errorCode.toString(), error.toString());
    }

    @DataProvider
    private Object[][] testRead_negative() {
        String uri = "address?id=abc";
        Error error = new Error();
        List<ErrorCode> errors = new ArrayList<>();
        errors.add(ErrorCode.ENTER_VALID_INPUT);
        error.setErrors(errors);

        return new Object[][] {
            {uri, error}
        };
    }

    @Test(dataProvider = "testSearch")
    private void testSearch(String uri, List<Address> expectedList) throws Exception {
        RequestHelper.setBaseUrl("http://localhost:8080/ws/");
        String address = requestHelper.setMethod(HttpMethod.GET).requestString(uri);
        List<Address> addressList = JsonUtil.toList(address, Address.class);
        Assert.assertEquals(JsonUtil.toJson(addressList), JsonUtil.toJson(expectedList));
    }

    @DataProvider
    private Object[][] testSearch() {
        String uri = "address?searchField=street,city,pincode&searchText=ram";
        List<Address> addressList = new ArrayList<>();
        addressList.add(new Address(6, "taramani", "chennai", 600010));
        addressList.add(new Address(7, "taramani", "chennai", 600010));
        addressList.add(new Address(8, "perambur", "chennai", 600070));

        String anotherUri = "address?searchField=street,city,pincode&searchText=b";
        List<Address> addressListTwo = new ArrayList<>();
        addressListTwo.add(new Address(8, "perambur", "chennai", 600070));
        addressListTwo.add(new Address(10, "nungambakkam", "salem", 600022));

        String readAllUri = "address";
        List<Address> fullAddressList = new ArrayList<>();
        fullAddressList.add(new Address(1, "kk nagar", "chennai", 600028));
        fullAddressList.add(new Address(2, "Tnagar", "chennai", 600075));
        fullAddressList.add(new Address(3, "nagar", "chennai", 600070));
        fullAddressList.add(new Address(4, "nagar", "chennai", 600070));
        fullAddressList.add(new Address(5, "Tnagar", "chennai", 600075));
        fullAddressList.add(new Address(6, "taramani", "chennai", 600010));
        fullAddressList.add(new Address(7, "taramani", "chennai", 600010));
        fullAddressList.add(new Address(8, "perambur", "chennai", 600070));
        fullAddressList.add(new Address(9, "food street", "chennai", 600075));
        fullAddressList.add(new Address(10, "nungambakkam", "salem", 600022));
        return new Object[][] {
            {uri, addressList}, 
            {anotherUri, addressListTwo}, 
            {readAllUri, fullAddressList}
        };
    }
}
