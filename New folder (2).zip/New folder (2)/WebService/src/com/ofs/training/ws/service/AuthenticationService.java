package com.ofs.training.ws.service;

import static com.ofs.training.ws.constantInterface.SQLQuery.AUTHENTICATION_QUERY;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.ofs.training.ws.constantInterface.TableColumn;
import com.ofs.training.ws.exception.AppException;
import com.ofs.training.ws.exception.ErrorCode;
import com.ofs.training.ws.pojo.Person;
import com.ofs.training.ws.resource.ConnectionManager;;

public class AuthenticationService {

    public Person login(String userName, String password) {
        Connection connect = ConnectionManager.getConnection();
        Person person = new Person();
        try {
            PreparedStatement statement = connect.prepareStatement(AUTHENTICATION_QUERY);
            statement.setString(1, userName);
            statement.setString(2, password);
            ResultSet result = statement.executeQuery();
            if (result.next()) {
                constructPerson(result, person);
            } else {
                throw new AppException(ErrorCode.INVALID_USERNAME_PASSWORD);
            }
        } catch (Exception exception) {
            if (exception instanceof AppException) {
                throw new AppException(((AppException) exception).getExceptionList());
            }
            throw new AppException(ErrorCode.AUTHENTICATION_ERROR, exception, exception.getMessage());
        }
        return person;
    }

    private Person constructPerson(ResultSet result, Person person) {
        try {
            person.setId(result.getLong(TableColumn.ID));
            person.setFirstName(result.getString(TableColumn.FIRST_NAME));
            person.setLastName(result.getString(TableColumn.LAST_NAME));
            person.setMailId(result.getString(TableColumn.EMAIL));
            person.setAdmin(result.getBoolean(TableColumn.IS_ADMIN));
        } catch (Exception exception) {
            throw new AppException(ErrorCode.DATABASE_ERR, exception, exception.getMessage());
        }
        return person;
    }
}
