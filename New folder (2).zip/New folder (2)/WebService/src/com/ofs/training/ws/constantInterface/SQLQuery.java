package com.ofs.training.ws.constantInterface;

public interface SQLQuery {

    public static final String CREATE_PERSON_QUERY = new StringBuilder()
            .append("Insert into trn_person(first_name ")
            .append("                     , last_name  ")
            .append("                     , email      ")
            .append("                     , address_id ")
            .append("                     , birth_date")
            .append("                     , password  ")
            .append("                     , isAdmin)  ")
            .append("    Values(?, ?, ?, ?, ?, ?, ?)      ")
            .toString();

    public static final String READ_PERSON_QUERY = new StringBuilder()
            .append("SELECT id                      ")
            .append("     , first_name              ")
            .append("     , last_name               ")
            .append("     , email                   ")
            .append("     , birth_date              ")
            .append("     , address_id              ")
            .append("    FROM trn_person WHERE id =?")
            .toString();

    public static final String READALL_PERSON_QUERY = new StringBuilder()
            .append("SELECT id                      ")
            .append("     , first_name              ")
            .append("     , last_name               ")
            .append("     , email                   ")
            .append("     , birth_date              ")
            .append("     , address_id              ")
            .append("    FROM trn_person            ")
            .toString();

    public static final String UPDATE_PERSON_QUERY = new StringBuilder()
            .append("UPDATE trn_person SET first_name = ?")
            .append("                    , last_name = ? ")
            .append("                    , email = ?     ")
            .append("                    , birth_date = ?")
            .append("    WHERE id = ?                    ")
            .toString();

    public static final String AUTHENTICATION_QUERY =  new StringBuilder()
            .append("SELECT id                        ")
            .append("     , first_name                ")
            .append("     , last_name                 ")
            .append("     , email                     ")
            .append("     , birth_date                ")
            .append("     , address_id                ")
            .append("     , isAdmin                   ")
            .append("    FROM trn_person              ")
            .append("WHERE email = ? AND password = ?;")
            .toString();


    public static final String DELETE_PERSON_QUERY = "DELETE FROM trn_person WHERE id  = ?";

    public static final String DUPLICATE_NAME_QUERY =  new StringBuilder()
            .append("SELECT COUNT(id) AS duplicate_name FROM trn_person WHERE      ")
            .append("first_name =? AND last_name = ? AND id != ?                  ")
            .toString();

    public static final String DUPLICATE_EMAIL_QUERY = new StringBuilder()
            .append("SELECT COUNT(id) AS duplicate_email FROM trn_person WHERE ")
            .append("email =? AND id != ?                                      ")
            .toString();

    public static final String READALL_PERSON_PAGING_QUERY = new StringBuilder()
            .append("SELECT first_name                   ")
            .append("     , id                           ")
            .append("     , last_name                    ")
            .append("     , email                        ")
            .append("     , birth_date                   ")
            .append("     , address_id                   ")
            .append("    FROM trn_person LIMIT 2 OFFSET ?")
            .toString();

    public static final String CREATE_ADDRESS_QUERY = new StringBuilder("INSERT INTO trn_address(street, ")
                                                    .append("city, postal_code) VALUES(?, ?, ?)").toString();

    public static final String READ_ADDRESS_QUERY = new StringBuilder("SELECT street, city, postal_code, id")
                                                            .append(" FROM trn_address Where id          ")
                                                            .append(" = ?;                               ")
                                                            .toString();

    public static final StringBuilder SEARCH_ADDRESS_QUERY = new StringBuilder()
            .append("SELECT id, street, city, postal_code FROM trn_address WHERE ");

    public static final String UPDATE_ADDRESS_QUERY = new StringBuilder()
            .append("UPDATE trn_address SET ")
            .append("city                   ")
            .append(" = ?                   ")
            .append(", street               ")
            .append(" = ?                   ")
            .append(", postal_code          ")
            .append(" = ?                   ")
            .append(" WHERE id = ?          ")
            .toString();

    public static final String DELETE_ADDRESS_QUERY = "DELETE FROM trn_address WHERE id  = ?";

    public static final String READALL_ADDRESS_QUERY = new StringBuilder()
            .append("SELECT id           ")
            .append("     , street       ")
            .append("     , city         ")
            .append("     , postal_code  ")
            .append("    FROM trn_address")
            .toString();
}
