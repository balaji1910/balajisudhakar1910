package com.ofs.training.ws.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ofs.training.ws.client.JsonUtil;
import com.ofs.training.ws.exception.AppException;
import com.ofs.training.ws.exception.Error;
import com.ofs.training.ws.exception.ErrorCode;
import com.ofs.training.ws.pojo.Person;

public class AuthorisationFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;
        HttpSession session = request.getSession(false);
        Person person = (Person) session.getAttribute("person");
        Error error = new Error();
        PrintWriter writer = response.getWriter();
        boolean admin = person.getAdmin();
        if (admin) {
            chain.doFilter(req, res);
        }
        try {
            if (!admin) {
                if ("PUT".equals(request.getMethod()) || "DELETE".equals(request.getMethod())) {
//                    response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                    throw new AppException(ErrorCode.ACCESS_DENIED);
                } else {
                    chain.doFilter(req, res);
                }
            }
        } catch (AppException e) {
            error.setErrors(e.getExceptionList());
            writer.write(JsonUtil.toJson(error));
        }
    }

    @Override
    public void destroy() {
        // TODO Auto-generated method stub
        
    }

}
