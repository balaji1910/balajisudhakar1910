package com.ofs.training.ws.servlet;

import org.apache.http.HttpResponse;

import com.ofs.training.ws.client.HttpMethod;
import com.ofs.training.ws.client.RequestHelper;
import com.ofs.training.ws.pojo.Person;

public class BaseServletTest {

    protected HttpResponse doLogin() throws Exception {
        RequestHelper requestHelper = new RequestHelper();
        RequestHelper.setBaseUrl("http://localhost:8080/ws/");
        Person person = new Person().setMailId("hari@ofs").setPassword("hariharansekar");
        HttpResponse response = requestHelper.setInput(person)
                        .setMethod(HttpMethod.POST).requestRaw("login");
        return response;
    }

    protected void doLogout() throws Exception {
        RequestHelper requestHelper = new RequestHelper();
        RequestHelper.setBaseUrl("http://localhost:8080/ws/");
        requestHelper.setMethod(HttpMethod.DELETE).requestString("logout");
    }
}
