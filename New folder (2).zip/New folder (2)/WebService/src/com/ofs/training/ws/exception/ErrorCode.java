package com.ofs.training.ws.exception;

public enum ErrorCode {


    FIRSTNAME_ERR("NAME_EMPTY", "FirstName cannot be empty"), 
    LASTNAME_ERR("NAME_EMPTY", "LastName cannot be empty"), 
    EMAIL_ALREADY_EXIST("MAIL_INVALID", "mail Id already exist"),
    EMAIL_ERR("EM_EMPTY", "mail Id cannot be empty"), 
    BIRTHDATE_ERR("DOB_ERR", "BirthDate connot be empty"), 
    NAME_ALREADY_EXIST("NAME_EXIST", "Another user with this FirstName and LastName already exist"), 
    STREET_ERR("ADDR_EMPTY", "street cannot be empty"), 
    CITY_ERR("ADDR_EMPTY", "city cannot be empty"), 
    POSTAL_CODE_ERR("ADDR_EMPTY", "postal_code cannot be empty"), 
    BIRTHDATE_INVALID("DOB_ERR", "Enter valid BirthDate"), 
    ID_ERR("id_empty", "id is not autoIncrementing"), 
    POSTAL_CODE_INVALID("ADDR_INVALID", "invalid postalCode, enter valid postalCode"), 
    DATE_ERR("EOR_ERR", "END OF RECORD"), 
    DATABASE_ERR("DB_ERROR", "SQL syntax or Connectivity ERROR"), 
    CONNECTION_ERR("CONN_ERROR", "database connection error"), 
    DATASOURCE_ERR("DS_ERROR", "Datasource error"), 
    LOAD_JSON_ERR("JSON_ERROR", "error in loading json"), 
    STORE_JSON_ERR("JSON_ERROR", "error in storing json"), 
    UNKNOWN_ERROR("UNKNOWN", "UnKnown error"), 
    NO_RECORD_FOUND("NO_RECORD", "no record found"), 
    CREATE_OPERATION_FAILED("CREATION_FAILED", "Error in creating person"), 
    READ_OPERATION_FAILED("READ_OPERATION_FAILED", "Error in reading person details"), 
    UPDATE_OPERATION_FAILED("UPDATE_FAILED", "Error in Updating person"), 
    DELETE_OPERATION_FAILED("DELETE_FAILED", "Error in deleting person"),
    SEARCH_OPERATION_FAILED("SEARCH_FAILED", "Error in searching address details"), 
    ENTER_VALID_INPUT("PARSING_FAILED", "Error occured while parsing input"), 
    PROPERTY_FILE_ERROR("PROPERTY_ERROR", "Error in reading property file"), 
    ERROR_IN_VERIFICATION("VERIFICATION FAILED", "error in checking duplication"), 
    INCORRECT_CREDENTIALS("ERROR IN USERNAME OR PASSWORD", "invalid userName and password"), 
    AUTHENTICATION_ERROR("ERROR IN AUTHENTICATION", "cannot authenticate the person"), 
    INVALID_USERNAME_PASSWORD("ERROR IN AUTHENTICATION", "cannot authenticate person"), 
    ACCESS_DENIED("NOT_AN_ADMIN", "cannot access");

    private final String message;
    private final String errCode;

    private ErrorCode(String errCode, String message) {
        this.errCode = errCode;
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public String geterrCode() {
        return errCode;
    }
//
//    @Override
//    public String toString() {
//        return String.format("ErrorCode = %s, ErrorMessage = %s", errCode, message);
//    }
}
