package com.ofs.training.ws.resource;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;

import com.ofs.training.ws.exception.AppException;
import com.ofs.training.ws.exception.ErrorCode;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class ConnectionManager {

    private static HikariDataSource ds;
    private static ThreadLocal<Connection> connectionThread = new ThreadLocal<>();
    static {
        InputStream inputStream = ConnectionManager.class.getClassLoader().getResourceAsStream("connection.properties");
        Properties property = new Properties();
          try {
            property.load(inputStream);
        } catch (IOException e) {
            throw new AppException(ErrorCode.PROPERTY_FILE_ERROR, e, e.getMessage());
        }
          HikariConfig config = new HikariConfig(property);
          ds = new HikariDataSource(config);
    }

    public static void initConnection() {

        Connection connection;
        if (Objects.isNull(ds)) {
            throw new AppException(ErrorCode.DATASOURCE_ERR);
        }
        try {
           connection = ds.getConnection();
           connectionThread.set(connection);
       } catch (SQLException exception) {
           throw new AppException(ErrorCode.CONNECTION_ERR, exception, exception.getMessage());
       }
    }

    public static Connection getConnection() {
        Connection connection = connectionThread.get();
        Map<Thread, Connection> connectionMap = new HashMap<>();
        connectionMap.put(Thread.currentThread(), connection);
        Connection connect = connectionMap.get(Thread.currentThread());
        return connect;
    }

    public static void releaseConnection(boolean doCommit) {

        Connection connection = connectionThread.get();
        try {
            if (doCommit) {
                connection.commit();
            } else {
                connection.rollback();
            }
            connection.close();
            connectionThread.remove();
        } catch (SQLException e) {
            throw new AppException(ErrorCode.CONNECTION_ERR, e, e.getMessage());
        }
    }
}
