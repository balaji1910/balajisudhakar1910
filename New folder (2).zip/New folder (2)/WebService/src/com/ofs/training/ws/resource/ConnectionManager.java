package com.ofs.training.ws.resource;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Objects;
import java.util.Properties;

import com.ofs.training.ws.exception.AppException;
import com.ofs.training.ws.exception.ErrorCode;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class ConnectionManager {

    private static HikariDataSource ds;
    static {
        InputStream inputStream = ConnectionManager.class.getClassLoader().getResourceAsStream("connection.properties");
        Properties property = new Properties();
          try {
            property.load(inputStream);
        } catch (IOException e) {
            System.out.println("error in reading property file");
        }
          HikariConfig config = new HikariConfig(property);
          ds = new HikariDataSource(config);
    }

    public static Connection initConnection() {

        Connection connection;
        if (Objects.isNull(ds)) {
            throw new AppException(ErrorCode.DATASOURCE_ERR);
        }
        try {
           connection = ds.getConnection();
       } catch (SQLException exception) {
           throw new AppException(ErrorCode.CONNECTION_ERR, exception, exception.getMessage());
       }
        return connection;
    }

    public static void releaseConnection(Connection connection, boolean doCommit) {

        try {
            if (doCommit) {
                connection.commit();
            } else {
                connection.rollback();
            }
            connection.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            throw new AppException(ErrorCode.CONNECTION_ERR, e, e.getMessage());
        }
    }
}
