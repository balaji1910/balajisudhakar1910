package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class AddressServiceTest {

    String url = "jdbc:mysql://pc1620:3306/hariharan_sekar?&user=hariharan_sekar&password=demo&useSSL=false";
    AddressService service;
    ConnectionManager connection;

    @BeforeClass
    private void initClass() {
        service = new AddressService();
        connection = new ConnectionManager();
    }

    @Test(dataProvider = "testInsertValues_positiveDP")
    private void testInsertValues_positive(Address address, long expected) {
        try {
            Connection connect = connection.initConnection(url);
            long actual = service.insertValues(connect, address);
            Assert.assertEquals(actual, expected);
            connect.close();
        } catch (Exception e) {
            Assert.fail("unexpected exception for input");
        }
    }

    @Test(dataProvider = "testInsertValues_negativeDP")
    private void testInsertValues_negative(Address address) {
        try {
            Connection connect = connection.initConnection(url);
            service.insertValues(connect, address);
            connect.close();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "postal_code cannot be null");
        }
    }

    @Test(dataProvider = "testReadValues_positiveDP")
    private void testReadValues_positive(String expected) throws Exception {
        Connection connect = connection.initConnection(url);
        String actual = service.readAddressValues(connect);
        Assert.assertEquals(actual, expected);
        connect.close();
    }

    @Test
    private void testReadAllValues_positive() throws Exception {
        Connection connect = connection.initConnection(url);
        int actual = service.readAllValues(connect);
        int expected = 3;
        Assert.assertEquals(actual, expected);
        connect.close();
    }

    @Test
    private void testUpdateValues() throws Exception {
        Connection connect = connection.initConnection(url);
        int actual = service.updateValues(connect);
        Assert.assertEquals(actual, 1);
        connect.close();
    }

    @Test
    private void testDeleteValues() throws Exception {
        Connection connect = connection.initConnection(url);
        int actual = service.deleteValue(connect);
        Assert.assertEquals(actual, 1);
        connect.close();
    }

    @DataProvider
    private Object[][] testInsertValues_positiveDP() {
        return new Object[][] {
            {new Address("HL colony", "chennai", 600072), 1},
            {new Address("thiyagarajan street", "chennai", 600062), 2},
            {new Address("Anna nagar", "chennai", 600028), 3}
        };
    }

    @DataProvider
    private Object[][] testInsertValues_negativeDP() {
        return new Object[][] {
            {new Address("Anna nagar", "chennai", 0)}
        };
    }

    @DataProvider
    private Object[][] testReadValues_positiveDP() {
        return new Object[][] {
            {"HL colony"}
        };
    }

    @AfterClass
    private void garbageCollector() {
        service = null;
        connection = null;
    }
}
