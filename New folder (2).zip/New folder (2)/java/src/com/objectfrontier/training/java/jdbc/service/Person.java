package com.objectfrontier.training.java.jdbc;

import java.sql.Date;
import java.sql.Timestamp;

public class Person {
    Address add = new Address();

    public Person(long id, String name, String mailId, int address, Date birthDate, Timestamp createdDate) {
        this.id = id;
        this.name = name;
        this.mailId = mailId;
        this.address = address;
        this.birthDate = birthDate;
        this.createdDate = createdDate;
    }

    long addressid;
    String street;
    String city;
    int postalCode;

    public Person(long addressid, String street, String city, int postalCode, long id, String name, String mailId,
            int address, Date birthDate, Timestamp createdDate) {
        this.id = addressid;
        this.street = street;
        this.city = city;
        this.postalCode = postalCode;
        this.id = id;
        this.name = name;
        this.mailId = mailId;
        this.address = address;
        this.birthDate = birthDate;
        this.createdDate = createdDate;
    }

    public Person(String name, String mailId, Date birthDate) {
        this.name = name;
        this.mailId = mailId;
        this.birthDate = birthDate;
    }

    public Person(String name, String mailId, int address, Date birthDate) {
    this.name = name;
    this.mailId = mailId;
    this.address = address;
    this.birthDate = birthDate;
}

    public Person() {
    }

    private long id;
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    private String name;
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private String mailId;

    public String getMailId() {
        return mailId;
    }

    public void setMailId(String mailId) {
        this.mailId = mailId;
    }

    int address;
    public int getAddress() {
        return address;
    }

    public void setAddress(int address) {
        this.address = address;
    }

    Date birthDate;
    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    Timestamp createdDate;
    public Timestamp getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = createdDate;
    }

    @Override
    public String toString() {
        return "Person [id=" + id + ", name=" + name + ", mailId=" + mailId + ", address=" + address + ", birthDate="
                + birthDate + ", createdDate=" + createdDate + "]";
    }


}
