package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PersonService {

    public long create(Connection connect, Person employee, Address address) throws Exception {
        String selectQuery = "Select id from trn_person where email = ?";
        PreparedStatement statement = connect.prepareStatement(selectQuery);
        statement.setString(1, employee.getMailId());
        ResultSet result = statement.executeQuery();
        if (result.next()) {
            throw new RuntimeException("mail Id already exist");
        }
        String personQuery = "Insert into trn_person(name, email, address_id, birth_date) "
                           + "Values(?, ?, ?, ?)";
        AddressService service = new AddressService();
        long id = service.insertValues(connect, address);
        statement = connect.prepareStatement(personQuery);
        statement.setString(1, employee.getName());
        statement.setString(2, employee.getMailId());
        statement.setLong(3, id);
        statement.setDate(4, employee.getBirthDate());
        statement.executeUpdate();
        String selectPerson = "SELECT id FROM trn_person";
        statement = connect.prepareStatement(selectPerson);
        Person person = new Person();
        ResultSet resultId = statement.executeQuery();
        while (resultId.last()) {
            person.setId(resultId.getLong(1));
            break;
        }
        return person.getId();
    }

    public long create(Connection connect, Person employee) throws Exception {
        String selectQuery = "Select id from trn_person where email = ?";
        PreparedStatement statement = connect.prepareStatement(selectQuery);
        statement.setString(1, employee.getMailId());
        ResultSet result = statement.executeQuery();
        if (result.next()) {
            throw new RuntimeException("mail Id already exist");
        }
        String personQuery = new StringBuilder("Insert into trn_person(name, email, address_id, birth_date) ")
                                       .append("Values(?, ?, ?, ?)").toString();
        statement = connect.prepareStatement(personQuery);
        statement.setString(1, employee.getName());
        statement.setString(2, employee.getMailId());
        statement.setInt(3, employee.getAddress());
        statement.setDate(4, employee.getBirthDate());
        statement.executeUpdate();
        String selectPerson = "SELECT id FROM trn_person";
        statement = connect.prepareStatement(selectPerson);
        Person person = new Person();
        ResultSet resultId = statement.executeQuery();
        while (resultId.last()) {
            person.setId(resultId.getLong(1));
            break;
        }
        return person.getId();
    }

    public List<Person> read(Connection connect, boolean includeAddress) throws Exception {
        Address address = new Address();
        Person employee = new Person();
        PreparedStatement statement;
        ArrayList<Person> personList = new ArrayList<>();
        ArrayList<Person> personAddress = new ArrayList<>();
        ArrayList<Person> person = new ArrayList<>();
        if (includeAddress == true) {
            String query = new StringBuilder("Select * From trn_person as emp Left join trn_address as addr ")
                                     .append("on emp.address_id = addr.id WHERE emp.id = 1").toString();
            statement = connect.prepareStatement(query);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                employee.setId(result.getInt(1));
                employee.setName(result.getString(2));
                employee.setMailId(result.getString(3));
                employee.setAddress(result.getInt(4));
                employee.setBirthDate(result.getDate(5));
                employee.setCreatedDate(result.getTimestamp(6));
                address.setId(result.getLong(7));
                address.setStreet(result.getString(8));
                address.setCity(result.getString(9));
                address.setPostalCode(result.getInt(10));
                personAddress.add(new Person(address.getId(), address.getStreet(), address.getCity(),
                                          address.getPostalCode(), 
                                          employee.getId(), employee.getName(), employee.getMailId(), 
                                          employee.getAddress(), employee.getBirthDate(), 
                                          employee.getCreatedDate()));
                person = personAddress;
            }
        } else {
            String query = "Select * from trn_person";
            statement = connect.prepareStatement(query);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                employee.setId(result.getInt(1));
                employee.setName(result.getString(2));
                employee.setMailId(result.getString(3));
                employee.setAddress(result.getInt(4));
                employee.setBirthDate(result.getDate(5));
                employee.setCreatedDate(result.getTimestamp(6));
                personList.add(new Person(employee.getId(), employee.getName(), employee.getMailId(), 
                           employee.getAddress(), employee.getBirthDate(), employee.getCreatedDate()));
                person = personList;
            }
        }
        System.out.println("reading values done succesfully");
        return person;
    }

    public static void main(String[] args) throws Exception {
        PersonService service = new PersonService();
        String url = new StringBuilder("jdbc:mysql://pc1620:3306/hariharan_sekar?&")
                               .append("user=hariharan_sekar&password=demo&useSSL=false").toString();
        ConnectionManager connect = new ConnectionManager();
        long create = service.create(connect.initConnection(url), 
                new Person("prakash", "prakash@gmail.com", Date.valueOf("1996-12-27")),
                new Address("Tnagar", "chennai", 600075));
        System.out.println(create);
    }
}
