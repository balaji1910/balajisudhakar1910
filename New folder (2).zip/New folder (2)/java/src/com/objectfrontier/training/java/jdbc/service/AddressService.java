package com.objectfrontier.training.java.jdbc.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;

public class AddressService {


    public long create(Connection connect, Address address) throws Exception {
        if (address.getPostalCode() == 0) {
            throw new RuntimeException("postal_code cannot be null");
        }
        String query = "INSERT INTO trn_address(street, city, postal_code) VALUES(?, ?, ?)";
        PreparedStatement statement = connect.prepareStatement(query);
        statement.setString(1, address.getStreet());
        statement.setString(2, address.getCity());
        statement.setInt(3, address.getPostalCode());
        statement.executeUpdate();
        Address addressId = read(connect, "id");
        return addressId.getId();
    }

    public Address search(Connection connect, String condition, String...specify) throws Exception {

        Address address = new Address();
        String specifier = Arrays.toString(specify);
        String column = specifier.substring(1, specifier.length() - 1);
        String query = new StringBuilder("SELECT ").append(column)
                                 .append(" FROM trn_address Where ").append(condition).toString();
        PreparedStatement statement = connect.prepareStatement(query);
        ResultSet result = statement.executeQuery();
        result.next();
        for (String string : specify) {
            if (string == "street") {
                address.setStreet(result.getString(string));
            }
            if (string == "id") {
                address.setId(result.getLong(string));
            }
            if (string == "city") {
                address.setCity(result.getString(string));
            }
            if (string == "postal_code") {
                address.setPostalCode(result.getInt(string));
            }
        }
        return address;
    }

    public Address read(Connection connect, String...specify) throws Exception {

        Address address = new Address();
        String specifier = Arrays.toString(specify);
        String column = specifier.substring(1, specifier.length() - 1);
        String query = new StringBuilder("SELECT ").append(column)
                                 .append(" FROM trn_address").toString();
        PreparedStatement statement = connect.prepareStatement(query);
        ResultSet result = statement.executeQuery();
        result.next();
        for (String string : specify) {
            if (string == "street") {
                address.setStreet(result.getString(string));
            }
            if (string == "id") {
                address.setId(result.getLong(string));
            }
            if (string == "city") {
                address.setCity(result.getString(string));
            }
            if (string == "postal_code") {
                address.setPostalCode(result.getInt(string));
            }
        }
        return address;
    }

    public int updateValues(Connection connect) throws Exception {
        String query = "UPDATE trn_address SET street = 'kk nagar' WHERE id = 3";
        PreparedStatement statement = connect.prepareStatement(query);
        int rowCount = statement.executeUpdate();
        return rowCount;
    }

    public int deleteValue(Connection connect) throws Exception {
        String query = "DELETE FROM trn_address WHERE id = 3";
        PreparedStatement statement = connect.prepareStatement(query);
        int rowCount = statement.executeUpdate();
        return rowCount;
    }
}
