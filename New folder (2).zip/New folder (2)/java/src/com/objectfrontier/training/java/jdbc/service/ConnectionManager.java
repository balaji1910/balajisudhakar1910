package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionManager {

    public Connection initConnection(String url) throws Exception {
        return DriverManager.getConnection(url);
    }
}
