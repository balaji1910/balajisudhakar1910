package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.Date;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


public class PersonServiceTest {

    String url = "jdbc:mysql://pc1620:3306/hariharan_sekar?&user=hariharan_sekar&password=demo&useSSL=false";
    PersonService service;
    ConnectionManager connection;

    @BeforeClass
    private void initClass() {
        service = new PersonService();
        connection = new ConnectionManager();
    }

    private void testInsertValues_positive(Person employee) throws Exception {
        Connection connect = connection.initConnection(url);
        try {
            connect.setAutoCommit(false);
            service.create(connect, employee);
            connect.commit();
            connect.close();
            Assert.assertEquals("person value inserted", "person value inserted");
        } catch (Exception e) {
            connect.rollback();
            connect.close();
        }
    }

    private void testInsertValues_positive(Person employee, Address address) throws Exception {
        Connection connect = connection.initConnection(url);
        try {
            connect.setAutoCommit(false);
            service.create(connect, employee, address);
            connect.commit();
            connect.close();
            Assert.assertEquals("Person and address value inserted", "Person and address value inserted");
        } catch (Exception e) {
            connect.rollback();
            connect.close();
        }
    }

    @Test
    private void testInsertValues_positive() throws Exception {
        testInsertValues_positive(new Person("prakash", "prakash@gmail.com", Date.valueOf("1996-12-27")),
                                  new Address("Tnagar", "chennai", 600075));
        testInsertValues_positive(new Person("hariprakash", "hp@gmail.com", 1, Date.valueOf("1996-12-27")));
    }

    @Test
    private void testInsertValues_negative() throws Exception {
        testInsertValues_negative(new Person("hariprakash", "hp@gmail.com", 2, Date.valueOf("1996-12-27")), 
                                  new Address("Tnagar", "chennai", 600075));
    }

    private void testInsertValues_negative(Person employee, Address address) throws Exception {
        Connection connect = connection.initConnection(url);
        try {
            connect.setAutoCommit(false);
            service.create(connect, employee, address);
            connect.commit();
            connect.close();
            Assert.fail("expected to rollback");
        } catch (Exception e) {
            connect.rollback();
            connect.close();
        }
    }

    @AfterClass
    private void garbageCollector() {
        service = null;
        connection = null;
    }

    @Test(dataProvider = "testReadAllValues_positiveDP")
    private void testReadAllValues_positive(boolean includeAddress) throws Exception {
        Connection connect = connection.initConnection(url);
        try {
            connect.setAutoCommit(false);
            service.read(connect, includeAddress);
            connect.commit();
            connect.close();
            Assert.assertEquals("reading values done succesfully", "reading values done succesfully");
        } catch (Exception e) {
            connect.rollback();
            connect.close();
        }
    }

    @DataProvider
    private Object[][] testReadAllValues_positiveDP() {
        return new Object[][] {
            {true}, 
            {false}
        };
    }
}
