package com.ofs.training;

import java.util.Arrays;

public class SortingCity {

    String[] doSort(String[] city) {
        if (city == null) {
            throw new RuntimeException("city cannot be zero");
        }
        Arrays.sort(city,String.CASE_INSENSITIVE_ORDER);
        String[] array = new String[city.length];
        for (int index = 0; index < city.length; index++) {
            if ( index % 2 == 0 && index != 0) {
                array[index] = city[index].toUpperCase();
            } else {
                array[index] = city[index];
            }
        }
        return array;
    }
}
