package com.ofs.training;

public class Square extends Shape {

    private int side = 4;

    @Override
    public void calculateArea() {
        // TODO Auto-generated method stub
        log("area of square: %s%n", side * side);
    }

    @Override
    public void calculatePerimeter() {
        // TODO Auto-generated method stub
        log("perimeter of square", 4 * side);
    }

    public static void main(String[] args) {

        Square box = new Square();
        box.calculateArea();
        box.calculatePerimeter();
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
