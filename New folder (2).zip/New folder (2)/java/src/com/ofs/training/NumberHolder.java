package com.ofs.training;

public class NumberHolder {

    public static int anInt;
    public static float aFloat;

    NumberHolder(int anInt, float aFloat) {
        this.anInt = anInt;
        this.aFloat = aFloat;
    }

    public static void main(String[] args) {

        NumberHolder nh = new NumberHolder(1,2.0f);
        System.out.println(anInt);
        System.out.println(aFloat);
    }
}
