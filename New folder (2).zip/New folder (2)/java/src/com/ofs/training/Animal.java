package com.ofs.training;

public class Animal {

    protected int legs;
    protected int eyes;
    protected boolean isMammal;
    protected boolean isReptile;

    protected void run() {
        System.out.println("animal runs");
    }

    protected void talk(String sound) {
        System.out.println("animal makes sound");
    }

    public static void main(String[] args) {

        Animal domestic = new Animal();
        domestic.run();
    }
}
