package com.ofs.training;

class OwnException extends Exception {

    OwnException (String s) {
        super (s);
    }
}

class ExceptionHand {

    void display(int a, int b) {

        if (b != 0) {
            int quotient = a / b;
        } else {
            try {
                throw new OwnException ("divide by zero");
            } catch (Exception e) {
                System.out.println("number is divided by zero");
            }
        }
    }
    public static void main(String[] args) {

        ExceptionHand exc = new ExceptionHand();
        exc.display(1,0);
    }
}
