package com.ofs.training.io;

import java.io.File;

public class FileDemo {

    public static void main(String[] args) {
        String path = args[0];
        File textFile = new File(path);
        boolean isDirectory = textFile.isDirectory();
        log("given path is a Directory:%s%n ", isDirectory);
        boolean isFile = textFile.isFile();
        log("given path is a File:%s%n ", isFile);
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
