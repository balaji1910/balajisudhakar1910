package com.ofs.training.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;

public class FileRead {

    private void inputStreamFile(String path) throws Exception {
        File dir = new File(path);
        InputStream input = new FileInputStream(dir);
        int offset = 0;
        int bytesRead = 0;
        byte[] bit = new byte[4096];
        while ((bytesRead = input.read(bit, offset, 100)) != -1) {
            offset += bytesRead;
            if (offset >= bit.length) {
                break;
            }
        }
        input.close();
        String content = new String(bit);
        log(content);
    }

    private void fileReader(String path) throws Exception {
        File dir = new File(path);
        FileReader input = new FileReader(dir);
        int offset = 0;
        int charsRead = 0;
        char[] cbuf = new char[1024];
        while ((charsRead = input.read(cbuf, offset, cbuf.length - offset)) != -1) {
            offset += charsRead;
            if (offset >= cbuf.length) {
                break;
            }
        }
        input.close();
        String content = new String();
        log(content);
    }

    public static void main(String[] args) throws Exception {
        FileRead read = new FileRead();
        String path = args[0];
        read.inputStreamFile(path);
        read.fileReader(path);
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
