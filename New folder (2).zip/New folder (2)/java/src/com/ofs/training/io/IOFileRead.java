package com.ofs.training.io;

import java.io.FileInputStream;
import java.io.InputStream;

public class IOFileRead {

    private void inputStreamFile(String path) throws Exception {
        InputStream input = new FileInputStream(path);
        int offset = 0;
        int bytesRead = 0;
        byte[] bit = new byte[4096];
        while ((bytesRead = input.read(bit, offset, 100)) != -1) {
            offset += bytesRead;
            if (offset >= bit.length) {
                break;
            }
        }
        input.close();
        String content = new String(bit);
        log(content);
    }

    public static void main(String[] args) throws Exception {
        IOFileRead reader = new IOFileRead();
        String path = args[0];
        reader.inputStreamFile(path);
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
