//Write some String content using Writer

package com.ofs.training.io;

import java.io.FileWriter;

public class ContentWriter {

    private void writeContent(String path) throws Exception {
        FileWriter writer = new FileWriter(path, true);
        String content = "added new content";
        writer.write(content);
        writer.flush();
        writer.close();
    }

    public static void main(String[] args) throws Exception {
        ContentWriter writer = new ContentWriter();
        String path = args[0];
        writer.writeContent(path);
    }
}
