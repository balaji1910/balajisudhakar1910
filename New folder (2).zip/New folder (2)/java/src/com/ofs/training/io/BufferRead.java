// Read a any text file using BufferedReader and print the content of the file

package com.ofs.training.io;

import java.io.BufferedReader;
import java.io.FileReader;

public class BufferRead {

    private String getContent(String path) throws Exception {
        BufferedReader input = new BufferedReader(new FileReader(path));
        int offset = 0;
        int charsRead = 0;
        char[] cbuf = new char[1024];
        while ((charsRead = input.read(cbuf, offset, cbuf.length - offset)) != -1) {
            offset += charsRead;
            if (offset >= cbuf.length) {
                break;
            }
        }
        String content = new String(cbuf);
        return content;
    }

    public static void main(String[] args) throws Exception {
        BufferRead reader = new BufferRead();
        String path = args[0];
        String content = reader.getContent(path);
        log(content);
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
