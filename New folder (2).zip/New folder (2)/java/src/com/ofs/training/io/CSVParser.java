package com.ofs.training.io;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class CSVParser {

    interface createList {
        List<Movie> createlist(String value);
    }

    public static void main(String[] args) throws Exception {
        FileInputStream stream = new FileInputStream(args[0]);
        String content = CSVParser.readBytes(stream);
        CSVParser.readBytes(stream);
//        System.out.println(content);
        CSVParser parser = new CSVParser();
        parser.parseCSV(content);
    }

    public static String readBytes(InputStream in) throws Exception {
        int offset = 0;
        int bytesRead = 0;
        byte[] data = new byte[1024];
        while ((bytesRead = in.read(data, offset, data.length - offset)) != -1) {
          offset += bytesRead;
          if (offset >= data.length) {
            break;
          }
        }
        String str = new String(data);
        return str;
      }

    private void parseCSV(String content) {
        StringTokenizer tokenizer = new StringTokenizer(content, ",");
        ArrayList<Movie> movies = new ArrayList<>();
        while (tokenizer.hasMoreTokens()) {
            String nextToken = tokenizer.nextToken();
        }
    }
}
