//Write some String content using OutputStream

package com.ofs.training.io;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;

public class OutputStreamContentWriter {

    public static void main(String[] args) throws Exception {
        String path = args[0];
        BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(path));
        String content = "Object Frontier Software";
        byte[] bytes = content.getBytes();
        output.write(bytes);
        output.flush();
        output.close();
    }
}
