package com.ofs.training.io;

import java.io.File;

public class FileList {

    public static void main(String[] args) {
        String path = args[0];
        File file = new File(path);
        File[] files = file.listFiles();
        int fileCount = 0;
        int dirCount = 0;
        for (File textFile : files) {
            if (textFile.isDirectory() == true) {
                dirCount ++;
            }
            if (textFile.isFile() == true) {
                fileCount ++;
            }
        }
        log("Number of Files:%s%n ", fileCount);
        log("Number of Directories:%s%n ", dirCount);
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
