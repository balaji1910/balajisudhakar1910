package com.ofs.training.io;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class ReadCSVFile {

    public static void main(String[] args) throws IOException {
        String filePath = args[0];
        Path path = Paths.get(filePath);
        List<String> fileContent = Files.readAllLines(path);
        for (String content : fileContent) {
            log(content);
        }
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
