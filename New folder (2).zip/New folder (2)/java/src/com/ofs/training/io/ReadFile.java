package com.ofs.training.io;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ReadFile {

    public static void main(String[] args) throws Exception {
        String filePath = args[0];
        Path path = Paths.get(filePath);
        byte[] bit = Files.readAllBytes(path);
        String content = new String(bit);
        log(content);
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
