package com.ofs.training.io;

import java.io.File;

public class CheckPermission {

    public static void main(String[] args) {
        String path = args[0];
        File textFile = new File(path);
        boolean canRead = textFile.canRead();
        log("whether the file is readable: %s%n", canRead);
        boolean canWrite = textFile.canWrite();
        log("whether the file is writable: %s%n", canWrite);
        boolean canExecute = textFile.canExecute();
        log("whether the file is Executable: %s%n", canExecute);
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
