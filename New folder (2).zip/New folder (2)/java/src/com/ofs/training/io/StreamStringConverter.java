//InputStream to String and vice versa

package com.ofs.training.io;

import java.io.FileInputStream;
import java.io.InputStream;

public class StreamStringConverter {

    private void convertToString(InputStream stream) throws Exception {
        int offset = 0;
        int bytesRead = 0;
        byte[] bit = new byte[4096];
        while ((bytesRead = stream.read(bit, offset, 100)) != -1) {
            offset += bytesRead;
            if (offset >= bit.length) {
                break;
            }
        }
        String content = new String(bit);
        log(content);
        stream.close();
    }

    private void convertToStream(String path) throws Exception {
        InputStream input = new FileInputStream(path);
        StreamStringConverter converter = new StreamStringConverter();
        converter.convertToString(input);
    }

    public static void main(String[] args) throws Exception {
        StreamStringConverter converter= new StreamStringConverter();
        String path = args[0];
        converter.convertToStream(path);
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
