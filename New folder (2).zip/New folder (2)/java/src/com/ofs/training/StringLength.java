package com.ofs.training;

public class StringLength {
	
	String getSubString(String content) {
		if (content == null) {
		    throw new RuntimeException("content cannot be null");
		}
		String sub = content.substring(9, 12);
		return sub;
	}
	
	int getLength(String content) {
	    String sub = content.substring(9, 12);
	    return sub.length();
	}
}
