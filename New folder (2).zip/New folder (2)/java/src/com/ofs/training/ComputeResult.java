package com.ofs.training;


public class ComputeResult {

    public static void main(String[] args) {

        String original = "software";
        StringBuilder result = new StringBuilder("hi");
        int index = original.indexOf('a');

        result.setCharAt(0, original.charAt(0)); //si
        result.setCharAt(1, original.charAt(original.length()-1)); //se
        result.insert(1, original.charAt(4)); //swe 
        result.append(original.substring(1,4)); //sweoft
        result.insert(3, (original.substring(index, index+2) + " ")); //swear oft

        System.out.println(result);
    }
}
