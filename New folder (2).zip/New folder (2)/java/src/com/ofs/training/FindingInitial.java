package com.ofs.training;

public class FindingInitial {

    String getInitial(String fullName) {
        if (fullName == null) {
            throw new RuntimeException("name cannot be null");
        }
        String[] name = new String[20];
        name = fullName.split(" ");
        String initial = " ";
        for (String str : name) {
            String result = str.substring(0,1);
            initial = initial.concat(result).trim();
        }
        return initial;
    }
}
