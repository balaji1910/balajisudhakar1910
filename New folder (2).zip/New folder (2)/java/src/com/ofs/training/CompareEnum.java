package com.ofs.training;

public class CompareEnum {

    boolean equalsCompare(Object obj, Object obj1) {
        if (obj == null && obj1 == null) {
            throw new RuntimeException("enum value cannot be null");
        }
        return obj.equals(obj1);
    }

    boolean operatorCompare(Object obj, Object obj1) {
        if (obj == null && obj1 == null) {
            throw new RuntimeException("enum value cannot be null");
        }
        return obj == obj1;
    }
}
