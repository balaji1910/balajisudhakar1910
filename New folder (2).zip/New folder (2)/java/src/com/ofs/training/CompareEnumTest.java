package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class CompareEnumTest {

    CompareEnum compare;

    @BeforeClass
    private void initClass() {

        compare = new CompareEnum();
    }

    @Test(dataProvider = "testCompareEnum_positiveDP")
    private void testCompareEnum_positive(Object obj1, Object obj2, boolean b1, boolean b2) {
        try {
            boolean actualResult1 = compare.equalsCompare(obj1, obj2);
            boolean actualResult2 = compare.operatorCompare(obj1, obj2);
            Assert.assertEquals(actualResult1, b1);
            Assert.assertEquals(actualResult2, b2);
        } catch (Exception e) {
            Assert.fail("Unexpected exception for input ");
        }
    }

    @DataProvider
    private Object[][] testCompareEnum_positiveDP() {
        return new Object[][] {
                                { Rainbow.RED, TrafficSignal.RED, false, false },
                                { Rainbow.GREEN, TrafficSignal.GREEN, false, false },
        };
    }

    @Test
    private void testCompareEnum_negative() {
        try {
            boolean actualResult = compare.equalsCompare(null, null);
            Assert.fail("Expected an exception.");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "enum value cannot be null");
        }
    }
}
