package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

@Test
public class StringLengthTest {

    StringLength length;

    @BeforeClass
    private void initClass() {

        length = new StringLength();
    }

    @Test
    private void testCalculateLength_positive() {
        try {
            String actualSubString = length.getSubString("Was it a car or a cat I saw?");
            int actualLength = length.getLength("Was it a car or a cat I saw?");
            Assert.assertEquals(actualSubString, "car");
            Assert.assertEquals(actualLength, 3);
        } catch (Exception e) {
            Assert.fail("Unexpected exception for input ");
        }
    }

    @Test
    private void testCalculateLength_negative() {
        try {
            String actualSubString = length.getSubString(null);
            int actualLength = length.getLength(null);
            Assert.fail("Expected an exception.");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "content cannot be null");
        }
    }
}
