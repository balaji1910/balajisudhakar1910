package com.ofs.training;

public class Cat extends Animal {

    protected void talk(String meow) {

        System.out.println("cat meows");
    }

    protected void talk(String meow, String bark) {

        System.out.println("cat growls");
    }

    public static void main(String[] args) {

        Animal kit = new Cat();
        Cat lucy   = new Cat();
        kit.isMammal = true;
        System.out.println(kit.isMammal);
        lucy.talk("meow");
        lucy.talk("meow", "bark");
    }
}
