package com.ofs.training;

enum TrafficSignal {

    RED,
    GREEN,
    YELLOW;
}
