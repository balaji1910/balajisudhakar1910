package com.ofs.training;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Scanner;

public class RoundOff {

    private BigDecimal getRounded(BigDecimal number) {
        BigDecimal rounded = number.round(MathContext.DECIMAL32);
        return rounded;
    }

    private BigDecimal getAbsoluteValue(BigDecimal number) {
        return number.abs();
    }

    public static void main(String[] args) {
        RoundOff rounded = new RoundOff();
        Scanner input = new Scanner(System.in);
        System.out.println("enter a number");
        double number = input.nextDouble();

        BigDecimal decimal = new BigDecimal(number);
        log("the big decimal numbers is :%s%n ", decimal);

        BigDecimal roundedDecimal = rounded.getRounded(decimal);
        log("the rounded big decimal number is : %s%n", roundedDecimal);

        BigDecimal absoluteValue = rounded.getAbsoluteValue(roundedDecimal);
        log("the absolute value is : %s%n ", absoluteValue);

        log("the round ceiled number: %s%n", rounded.getCeilingNumber(decimal));
        log("the floor number: %s%n", rounded.getfloorNumber(decimal));
        log("the max number: %s%n", rounded.getMax(decimal));
        log("the min number: %s%n", rounded.getMin(decimal));
        input.close();
    }

    private BigDecimal getCeilingNumber(BigDecimal number) {
        return number.plus(new MathContext(2, RoundingMode.CEILING));
    }

    private BigDecimal getfloorNumber(BigDecimal number) {
        return number.plus(new MathContext(2, RoundingMode.FLOOR));
    }

    private BigDecimal getMax(BigDecimal number) {
        Scanner input = new Scanner(System.in);
        System.out.println("enter another number");
        double decimal = input.nextDouble();
        BigDecimal bigDecimal = new BigDecimal(decimal);
        getMin(bigDecimal);
        input.close();
        return bigDecimal.max(number);
    }

    private BigDecimal getMin(BigDecimal bigDecimal) {
        return bigDecimal.min(bigDecimal);
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
