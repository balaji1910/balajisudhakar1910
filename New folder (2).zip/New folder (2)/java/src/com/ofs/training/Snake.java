package com.ofs.training;

public class Snake extends Animal {

    private boolean isPoisonous;

    protected void run() {
        System.out.println("snake slithers");
    }

    protected void talk() {
        System.out.println("snake hisses");
    }

    public static void main(String[] args) {

        Animal reptile = new Snake();
        Snake viper    = new Snake();

        reptile.isMammal = false;
        reptile.isReptile = true;
        reptile.run();
        viper.isPoisonous = true;

        System.out.println("is snake a mammal: " + reptile.isMammal);
        System.out.println("is sanke a reptile: " + reptile.isReptile);
        System.out.println("is snake is poisonous: " + viper.isPoisonous);
    }
}
