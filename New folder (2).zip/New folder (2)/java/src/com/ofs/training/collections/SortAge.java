package com.ofs.training.collections;

import java.util.Comparator;
import java.util.List;

public class SortAge {

    public static void main(String[] args) {
        Comparator<Person> age = (personOne, personTwo) -> {
            if (personOne.getAge() > personTwo.getAge()) {
                return -1;
            } else {
                return 1;
            }
        };
        List<Person> personList = Person.createRoster();
        personList.sort(age);
        for (Person person : personList) {
            System.out.println(person);
        }
    }
}
