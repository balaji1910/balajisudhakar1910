package com.ofs.training.collections;

import java.util.Arrays;
import java.util.List;

public class NumberList {

    private int getMin(List<Integer> numbers) {
        return numbers.stream().
                       mapToInt(Integer :: intValue).
                       min().
                       getAsInt();
    }

    private int getMax(List<Integer> numbers) {
        return numbers.stream().
                       mapToInt(Integer :: intValue).
                       max().
                       getAsInt();
    }

    private int getSum(List<Integer> numbers) {
        return numbers.stream().mapToInt(Integer :: intValue).sum();
    }

    public static void main(String[] args) {
        NumberList number = new NumberList();
        List<Integer> randomNumbers = Arrays.asList(1, 6, 10, 25, 78);

        int maxValue = number.getMin(randomNumbers);
        log("The maximum value in the list is: %s%n ", maxValue);

        int minValue = number.getMax(randomNumbers);
        log("\nThe maximum value in the list is ", minValue);

        int sum = number.getSum(randomNumbers);
        log("\nThe sum of randomNumbers is ", sum);
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
