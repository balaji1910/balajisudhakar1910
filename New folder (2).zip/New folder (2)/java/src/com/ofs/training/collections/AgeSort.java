package com.ofs.training.collections;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class AgeSort {

    private List<Person> sortAge(List<Person> people) {
        return people.stream()
                     .sorted(Comparator.comparing(Person::getAge)
                                       .reversed())
                     .collect(Collectors.toList());
    }

    public static void main(String[] args) {
        AgeSort sort = new AgeSort();
        List<Person> people = Person.createRoster();
        List<Person> sortedList = sort.sortAge(people);
        System.out.println(sortedList);
    }
}
