package com.ofs.training.collections;

import java.util.List;

public class PersonDetail {

    private void forEach(List<Person> people) {
        System.out.println("Printing using for each:");
        people.stream().forEach(p -> System.out.println("\t" + p));
    }

    private void iterate(List<Person> people) {
        System.out.println("Printing using iterator :");
        people.iterator().forEachRemaining(person -> System.out.println("\t" + person));
    }

    public static void main(String[] args) {
        List<Person> people = Person.createRoster();
        PersonDetail detail = new PersonDetail();

        detail.forEach(people);
        detail.iterate(people);
    }
}
