package com.ofs.training.collections;

import java.util.List;

public class AverageAge {

    private double getAverageAge(List<Person> ageList) {
        return ageList.stream()
                      .mapToInt(p -> p.getAge())
                      .average()
                      .getAsDouble();
    }

    public static void main(String[] args) {
        List<Person> people = Person.createRoster();
        AverageAge age = new AverageAge();
        double averageAge = age.getAverageAge(people);
        log("the average age of List of person is :%f", averageAge);
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }

}
