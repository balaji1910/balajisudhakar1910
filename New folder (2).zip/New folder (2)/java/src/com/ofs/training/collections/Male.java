package com.ofs.training.collections;

import java.util.List;
import java.util.stream.Collectors;

public class Male {

    private List<Person> getAdult(List<Person> people) {
        System.out.println("List of men above age 21");
        return people.stream()
                     .filter(person -> { return person.getGender() == Sex.MALE; })
                     .filter(person -> { return person.getAge() > 21; })
                     .collect(Collectors.toList());
    }

    private List<Person> getMen(List<Person> people) {
        System.out.println("List of men");
        return people.stream()
                     .filter(person -> { return person.getGender() == Sex.MALE; })
                     .collect(Collectors.toList());
    }

    private Person getFirstMen(List<Person> men) {
        System.out.println("First person from the list of men");
        return men.stream().findFirst().get();
    }

    private Person getRandomMen(List<Person> men) {
        System.out.println("Random person from the list of men");
        return men.stream().findAny().get();
    }

    private Person getLastMen(List<Person> adultMale) {
        System.out.println("Last person from the list of men");
        return adultMale.get(adultMale.size() - 1);
    }


    public static void main(String[] args) {
        Male he = new Male();

        List<Person> people = Person.createRoster();
        List<Person> adultMen = he.getAdult(people);
        System.out.println(adultMen);

        List<Person> men = he.getMen(people);
        System.out.println(men);

        Person firstMen = he.getFirstMen(men);
        System.out.println(firstMen);

        Person randomMen = he.getRandomMen(men);
        System.out.println(randomMen);

        Person lastMen = he.getLastMen(men);
        System.out.println(lastMen);
    }
}
