package com.ofs.training.collections;

import java.util.List;
import java.util.stream.Collectors;

public class PersonDto {

    private String emailAddress;
    private String name;

    private static PersonDto toMinimalDTO(Person one) {
        PersonDto dto = new PersonDto();
        dto.setName(one.getName());
        dto.setEmailAddress(one.getEmailAddress());
        return dto;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return String.format("name=%s, emailAddress=%s%n ",name, emailAddress);
    }

    public static void main(String[] args) {
        List<Person> people = Person.createRoster();
        List<PersonDto> minimalPerson = people.stream()
                                              .map(PersonDto::toMinimalDTO)
                                              .collect(Collectors.toList());
        System.out.println(minimalPerson);
    }
}

