package com.ofs.training.collections;

import java.util.List;
import java.util.stream.Collectors;

public class MinimalPerson {

    private List<String> getAdult(List<Person> people) {
        return people.stream()
                     .map(person -> person.getName() + " " + person.getEmailAddress() + "\n")
                     .collect(Collectors.toList());
    }

    public static void main(String[] args) {
        MinimalPerson person = new MinimalPerson();
        List<Person> people = Person.createRoster();
        List<String> minimalData = person.getAdult(people);
        System.out.println(minimalData);
    }
}
