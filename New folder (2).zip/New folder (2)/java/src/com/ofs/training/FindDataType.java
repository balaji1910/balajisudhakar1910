package com.ofs.training;

public class FindDataType {

    String getDataType(Object ob) {
        String dataType = null;
        if (ob == null ) {
            throw new RuntimeException("cannot be null");
        }
        if (ob instanceof String) {
            throw new RuntimeException("only primitive dataTypes");
        }
        if (ob instanceof Integer) { 
            dataType = "the dataType is int";
        }
        if (ob instanceof Float) {
            dataType = "the dataType is float";
        }
        if (ob instanceof Long) {
            dataType = "the dataType is long";
        }
        if (ob instanceof Double) {
            dataType = "the dataType is double";
        }
        return dataType;
    }
}
