package com.ofs.training;

public class Math {

    int doDivide(int a, int b) {
        if (b == 0) {
            throw new RuntimeException("dividend cannot be zero");
        }
        return a/b;
    }
}
