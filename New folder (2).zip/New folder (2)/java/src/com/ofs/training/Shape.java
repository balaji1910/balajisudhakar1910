package com.ofs.training;

public abstract class Shape {

    public static final double PI = 3.14;

    public abstract void calculateArea();

    public abstract void calculatePerimeter();
}
