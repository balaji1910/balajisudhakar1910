package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class SortingCityTest {

    SortingCity sorting;

    @BeforeClass
    private void initClass() {
        sorting = new SortingCity();
    }

    @Test(dataProvider = "testSortCity_positiveDP")
    private void testSortCity_positive(String[] cityTn, String[] sortedCity) {
        try {
            String[] actualSort = sorting.doSort(cityTn);
            Assert.assertEquals(actualSort, sortedCity);
        } catch (Exception e) {
            Assert.fail("Unexpected exception for input ");
        }
    }

    @Test
    private void testSortCity_negative() {
        try{
            String[] actualSort = sorting.doSort(null);
            Assert.fail("Expected an exception.");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "city cannot be zero");
        }
    }


    @DataProvider
    private Object[][] testSortCity_positiveDP() {

        String[] cityTn = { "Madurai",
                           "Thanjavur",
                           "TRICHY",
                           "Karur",
                           "Erode",
                           "trichy",
                           "Salem" };

        String[] SortedCityTn = { "Erode",
                                  "Karur",
                                  "MADURAI",
                                  "Salem",
                                  "THANJAVUR",
                                  "TRICHY",
                                  "TRICHY" };

        String[] cityIndia =  { "hydrabad",
                                "mumbai",
                                "chennai",
                                "KOLKATA",
                                "delhi",
                                "GOA",
                                "KOVAI"};

        String[] SortedCityIndia = { "chennai",
                                   "delhi",
                                   "GOA",
                                   "hydrabad",
                                   "KOLKATA",
                                   "KOVAI",
                                   "MUMBAI" };
        return new Object[][] {
                                { cityTn, SortedCityTn},
                                {cityIndia, SortedCityIndia}
        };
    }
}
