
public class NumAdder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num;
		if (args.length > 0) {
			for (int i : num) {
				System.out.println(num);
			} 
		} else {
			System.out.println("no arguments");
		}
	}
}

