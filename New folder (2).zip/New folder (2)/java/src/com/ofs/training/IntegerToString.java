package com.ofs.training;

public class IntegerToString {

    public static void main(String[] args) {

        int a = 65;
        String b = "230";
        double c = 0.0/0.0;
        System.out.println(Integer.toHexString(a));
        System.out.println(Integer.valueOf(b,5));
        System.out.println(Double.isNaN(c));
    }
}
