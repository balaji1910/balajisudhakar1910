package com.ofs.training;

public class Colour {

    public static void main(String[] args) {

        Rainbow red = Rainbow.RED;
        TrafficSignal gr = TrafficSignal.RED;
        System.out.println(red.equals(gr));
       // System.out.println(red == gr);
    }
}
