package com.ofs.training;

public class Adder {

    int getSum(int... value) {
        if (value.length < 2 ) {
            throw new RuntimeException("enter more than one number"); 
        }
        int sum = 0;
        for (int number : value) {
                sum = sum + number;
        }
        return sum;
    }
}
