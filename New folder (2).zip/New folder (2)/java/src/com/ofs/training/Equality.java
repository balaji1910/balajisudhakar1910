package com.ofs.training;

class Equality {

    String name;

    Equality(String name) {

        this.name = name;
    }

    public String toString() {

        return "emp name " + name;
    }

    public static void main(String[] args) {

        String name = "Hari";
        String anotherName = new String("Hari");
        String name2 ="Hari";
        Equality name3 = new Equality("hari");

        System.out.println(name == anotherName);
        System.out.println(name == name2);
        System.out.println(name.equals(anotherName));
        System.out.println(name3);
    }
}
