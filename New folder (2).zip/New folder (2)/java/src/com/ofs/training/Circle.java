package com.ofs.training;

public class Circle extends Shape {

    private int radius = 3;

    @Override
    public void calculateArea() {
        log("area of circle: %f%n", radius * radius * PI);
    }

    @Override
    public void calculatePerimeter() {
        log("Perimeter of circle: %f%n", 2 * PI * radius);
    }

    public static void main(String[] args) {
        Circle disc = new Circle();
        disc.calculateArea();
        disc.calculatePerimeter();
    }

    public static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
