package com.ofs.training.util;

import java.util.Base64;

public class EncoderDecoder {

    public static void main(String[] args) {
        String password = "password@ofs";
        byte[] bit = password.getBytes();
        EncoderDecoder encoder = new EncoderDecoder();
        encoder.encodePassword(bit);
    }

    private void encodePassword(byte[] bit) {
        byte[] encoded = Base64.getEncoder().encode(bit);
        String password = new String(encoded);
        log("encoded password:%s%n ", password);
        decodePassword(encoded);
    }

    private void decodePassword(byte[] encoded) {
        byte[] decoded = Base64.getDecoder().decode(encoded);
        String password = new String(decoded);
        log("decoded password:%s%n ", password);
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
