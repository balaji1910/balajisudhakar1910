package com.ofs.training.util;

import java.util.Random;

public class GenerateRandomNumber {

    public static void main(String[] args) {
        Random randomNumber = new Random();
        System.out.println(randomNumber.nextInt());
    }
}
