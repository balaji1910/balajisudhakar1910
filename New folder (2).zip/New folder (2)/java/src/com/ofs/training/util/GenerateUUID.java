package com.ofs.training.util;

import java.util.UUID;

public class GenerateUUID {

    public static void main(String[] args) {
        UUID id = UUID.randomUUID();
        System.out.println(id);
    }
}
