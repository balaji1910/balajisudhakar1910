package com.ofs.training.util;

import java.util.Scanner;

public class ScannerDemo {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("enter your name");
        String name = scan.nextLine();
        log(name);
        scan.close();
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
