package com.ofs.training.util;

import java.util.Arrays;
import java.util.List;

public class ArrayListConverter {

    public static void main(String[] args) {
        String[] city = { "Madurai",
                          "Thanjavur",
                          "TRICHY",
                          "Karur",
                          "Erode",
                          "trichy",
                          "Salem" };
        List<String> cities = Arrays.asList(city);
        Object[] town = cities.toArray();
    }
}
