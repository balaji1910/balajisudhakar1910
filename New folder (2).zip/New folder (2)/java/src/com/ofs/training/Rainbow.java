package com.ofs.training;

enum Rainbow {

    VOILET,
    YELLOW,
    BLUE,
    INDIGO,
    GREEN,
    ORANGE,
    RED;
}