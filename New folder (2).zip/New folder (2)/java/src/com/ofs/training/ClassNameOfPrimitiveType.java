package com.ofs.training;

// class ClassNameOfPrimitiveType {
public class ClassNameOfPrimitiveType {

    // staic void execute() {
    public static void main(String[] args) {

        // Console console = new Console()
        // console.print(className)
        log("class name of int is ", int.class.getName());
        log("class name of float is ", float.class.getName());
        log("class name of long is ", long.class.getName());
        log("class name of short is ", short.class.getName());
        log("class name of boolean is ", boolean.class.getName());
        log("class name of byte is ", byte.class.getName());
        log("class name of double is ", double.class.getName());
        log("class name of char is ", char.class.getName());
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
