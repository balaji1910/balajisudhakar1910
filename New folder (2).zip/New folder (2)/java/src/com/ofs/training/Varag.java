package com.ofs.training;

public class Varag {

    void vargs(String name) {
        log(name);
    }

    void vargs(String... name) {

        for (String index : name)
        log(index);
    }

    public static void main(String[] args) {

        Varag var = new Varag();
        var.vargs("hari");
        var.vargs("ak","uk");
        var.vargs("hari","haran");
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
