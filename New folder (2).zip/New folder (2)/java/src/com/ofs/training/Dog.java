package com.ofs.training;

public class Dog extends Animal {

    String breed;

    void talk() {

        System.out.println("dog barks");
    }

    public static void main(String[] args) {

        Animal pup = new Dog();
        Dog ted    = new Dog();
        pup.isMammal = true;
        ted.breed = "pug";
        System.out.println(pup.isMammal);
        System.out.println("dog breed: " + ted.breed);
    }
}
