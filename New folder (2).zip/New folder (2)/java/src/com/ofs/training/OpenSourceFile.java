package com.ofs.training;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

//class OpenSourceFile {
public class OpenSourceFile {

    // static void execute() {
    public static void main(String[] args) {

        // OpenSourceFile sf = getCurrentProgram()
        OpenSourceFile sf = new OpenSourceFile();

        // Class currentClass = sf.getClass()
        Class currentClass = sf.getClass();

        // File currentClassSourceFile = currentClass.getFile()
        // String absPath = currentClassSourceFile.getAbsolutePath()
        String absPath = currentClass.getProtectionDomain()
                                     .getCodeSource()
                                     .getLocation()
                                     .getFile();

        String className = currentClass.getName();
        String directory = absPath.concat(className);
        String path = directory.concat(".java");

        // Notepad np = getNotepad()
        // np.open(absPath)
        try {
            Desktop desktop = Desktop.getDesktop();
            File file = new File(path);
            desktop.open(file);
        } catch (IOException e) {
            System.out.println("null");
        }
    }
}
