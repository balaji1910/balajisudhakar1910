package com.ofs.training.DateAndTime;

import java.time.LocalTime;

public class PrintDate {

    public static void main(String[] args) {
        LocalTime today = LocalTime.now();
        log("%s",today);
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }

}
