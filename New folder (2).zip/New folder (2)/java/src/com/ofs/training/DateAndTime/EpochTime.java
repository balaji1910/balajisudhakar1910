package com.ofs.training.DateAndTime;

import java.time.Instant;

public class EpochTime {

    public static void main(String[] args) {
        Instant epochTime = Instant.EPOCH;
        System.out.println(epochTime);

//        Instant now = Instant.now();
//        System.out.println(now.getNano());
//        System.out.println(now.getEpochSecond());
//        System.out.println(now.toEpochMilli());
    }

}
