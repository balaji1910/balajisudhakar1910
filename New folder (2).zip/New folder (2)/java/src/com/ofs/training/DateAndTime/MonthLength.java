package com.ofs.training.DateAndTime;

import java.time.Month;
import java.time.Year;
import java.time.YearMonth;

public class MonthLength {

    public static void main(String[] args) {
        int year = Integer.parseInt(args[0]);
        Year givenYear = Year.of(year);
        log("The given year is %s %n",givenYear);
        int i = 1;
        while (i <= 12) {
            YearMonth atMonth = givenYear.atMonth(i);
            Month month = atMonth.getMonth();
            int lengthOfMonth = atMonth.lengthOfMonth();
            log("%s %d %n",month,lengthOfMonth);
            i++;
        }
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
