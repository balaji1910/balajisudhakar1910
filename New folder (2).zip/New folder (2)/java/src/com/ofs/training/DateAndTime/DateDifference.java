package com.ofs.training.DateAndTime;

import java.time.LocalDate;
import java.time.Period;

public class DateDifference {

    public static void main(String[] args) {
        LocalDate joinedDate = LocalDate.of(2018, 06, 20);
        LocalDate today = LocalDate.of(2018, 9, 25);
        DateDifference difference = new DateDifference();
        difference.findDifference(joinedDate, today);
    }

    private void findDifference(LocalDate joined, LocalDate current) {
        System.out.println(Period.between(joined, current));
    }
}
