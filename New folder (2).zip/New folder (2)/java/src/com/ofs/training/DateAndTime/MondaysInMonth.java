package com.ofs.training.DateAndTime;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;

public class MondaysInMonth {

    public static void main(String[] args) {
        LocalDate date = LocalDate.now();
        int year = date.getYear();
        Month month = Month.valueOf(args[0]);
        MondaysInMonth mondays = new MondaysInMonth();
        mondays.monthLength(year, month);
    }

    private void monthLength(int year, Month month) {
        YearMonth yearMonth = YearMonth.of(year, month);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-YYYY");
        DayOfWeek monday = DayOfWeek.MONDAY;
        for (int day = 1; day < month.maxLength(); day ++) {
            if (yearMonth.atDay(day).getDayOfWeek() == monday) {
                String Dateformat = yearMonth.atDay(day).format(formatter);
                log("%s%n", Dateformat);
            }
        }
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
