package com.ofs.training.DateAndTime;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DateInISO {

    public static void main(String[] args) {
        DateTimeFormatter isoDate = DateTimeFormatter.ISO_DATE;
        LocalDateTime today = LocalDateTime.now();
        log("%s %n", today);
        String IsoDate = today.format(isoDate);
        log("ISO formatted date is %s", IsoDate);
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }

}
