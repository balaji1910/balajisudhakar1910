package com.ofs.training.DateAndTime;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class DateFormatter {

    public static void main(String[] args) {

        ZoneId id = ZoneId.of("US/Pacific");
        ZonedDateTime dateTime = ZonedDateTime.now(id);
        String date = DateTimeFormatter.ofPattern("yyyy.MM.dd 'at' HH:mm:ss z").format(dateTime);
        String anotherDate = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ").format(dateTime);
        log(date);
        log(anotherDate);
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
