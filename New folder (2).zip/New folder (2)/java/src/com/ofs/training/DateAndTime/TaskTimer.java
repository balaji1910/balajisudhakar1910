package com.ofs.training.DateAndTime;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class TaskTimer {

    static int id = 1;

    public static void main(String[] args) {

        Timer time = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                id++;
                Date today = new Date();
                SimpleDateFormat dateFormat = new SimpleDateFormat(" HH:MM a E d MMMM Y");
                System.out.println(dateFormat.format(today) + ": Hi I am auto runner");
                while (id > 5) {
                    cancel();
                }
            }
        };
        time.schedule(task, 1000l, 10000l);
    }
}
