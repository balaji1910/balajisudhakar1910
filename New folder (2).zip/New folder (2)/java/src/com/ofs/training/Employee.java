package com.ofs.training;

import java.util.ArrayList;

class Employee {

    private static int count = 0;
    private int id = 0;
    private String name;

    Employee(String name) {

        this.name = name;
        this.id = ++count;
    }

    @Override
    public String toString() {
        return String.format("Employee id=%s name=%s \n", id, name);
    }

    public static void main(String[] args) {

        ArrayList<Employee> staff = new ArrayList<>(10);
        staff.add(new Employee("Hari"));
        staff.add(new Employee("Naveen"));
        staff.add(new Employee("prasanna"));
        staff.add(new Employee("mani"));
        staff.add(new Employee("karthi"));
        staff.add(new Employee("amudhan"));
        staff.add(new Employee("jacob"));
        staff.add(new Employee("prem"));
        staff.add(new Employee("bala"));
        staff.add(new Employee("surya"));
        staff.add(new Employee("yuvan"));
        System.out.println(staff);
    }
}
