package com.ofs.training;

public class Divide extends Math {

    public static void main(String[] args) {

    Math m = new Math();
    System.out.println(m.doDivide(5, 0));
    }
}
