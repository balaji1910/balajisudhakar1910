package com.ofs.training;

public class Rectangle {

    int width;
    int height;
    int area() {
        int area = width * height;
        return area;
    }

    public static void main(String[] args) {

        Rectangle myRect = new Rectangle();
        myRect.width = 40;
        myRect.height = 50;
        System.out.println("myRect's area is " + myRect.area());
    }
}


