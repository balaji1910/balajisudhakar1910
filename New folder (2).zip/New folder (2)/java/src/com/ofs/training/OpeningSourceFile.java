package com.ofs.training;

//class OpenSourceFile {
public class OpeningSourceFile {

    // static void execute() {
    public static void main(String[] args) throws Exception {

        // OpeningSourceFile sf = getCurrentProgram()
        OpeningSourceFile sf = new OpeningSourceFile();

        // Class currentClass = sf.getClass()
        Class currentClass = sf.getClass();

        // File currentClassSourceFile = currentClass.getFile()
        // String absPath = currentClassSourceFile.getAbsolutePath()
        String absPath = currentClass.getProtectionDomain()
                                     .getCodeSource()
                                     .getLocation()
                                     .getFile();

        Runtime rt = Runtime.getRuntime();
        // Notepad np = getNotepad()
        // np.open(absPath)
        String notepad = "D:\\tools\\notepad++\\notepad++.exe "+ (absPath.substring(3) + currentClass.getName());
        Process process = rt.exec(notepad);
    }
}
