package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class FindingInitialTest {

    FindingInitial init;
    
    @BeforeClass
    private void initClass() {
        init = new FindingInitial();
    }

    @Test(dataProvider = "testFindInitial_positiveDP")
    private void testFindInitial_positive(String name, String expectedInitial) {
        try {
            String actualInitial = init.getInitial(name);
            Assert.assertEquals(actualInitial, expectedInitial);
        } catch (Exception e) {
            Assert.fail("Unexpected exception for input "
                    + name
                    + ". Expected result is "
                    + expectedInitial
                    + ".",
                    e);
        }
    }

    @DataProvider
    private Object[][] testFindInitial_positiveDP() {
        return new Object[][] {
                                {"Hariharan Sekar", "HS"},
                                {"Lakshmi Prasanna Kumar", "LPK"},
                                {"Naveenraj", "N"}
        };
    }

    @Test
    private void testFindInitial_negative() {
        try {
            String actualInitial = init.getInitial(null);
            Assert.fail("Expected an exception.");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "name cannot be null");
        }
    }
}
