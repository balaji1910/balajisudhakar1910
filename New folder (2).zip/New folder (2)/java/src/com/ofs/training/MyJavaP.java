package com.ofs.training;

import java.lang.reflect.Modifier;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

public class MyJavaP {

    void classcommandArgs(String className) throws Exception {

        Class clazz = Class.forName(className);
        System.out.println("complied from " + "\"" + clazz.getSimpleName() + ".java\"");
    }

    void interfacecommandArgs(String className) throws Exception {

        Class clazz = Class.forName(className);
        Class[] inter = clazz.getInterfaces();
        if (inter.length > 0) {
            System.out.print(clazz + " implements ");
            for (int index = 0; index < inter.length; index++) {

                int mod = inter[index].getModifiers();
                printModifier(mod);
                System.out.print(inter[index].getName() + " ");
            }
            System.out.println(" { \n");
        }
    }

    void printModifier(int mod) {
        if (Modifier.isPublic(mod)) {
            System.out.print("public ");
        }
        if (Modifier.isPrivate(mod)) {
            System.out.print("private ");
        }
        if (Modifier.isStatic(mod)) {
            System.out.print("static ");
        }
        if (Modifier.isFinal(mod)) {
            System.out.print("final ");
        }
        if (Modifier.isNative(mod)) {
            System.out.print("native ");
        }
    }

    void methodcommandArgs(String className) throws Exception {

        Class clazz = Class.forName(className);
        Method[] method = clazz.getDeclaredMethods();
        System.out.println("\n");
        for (Method m : method) {
            int comma = 1;
            int mod = m.getModifiers();
            printModifier(mod);
            System.out.print(m.getReturnType().getSimpleName() + " " + m.getName());
            Class[] pt = m.getParameterTypes();
            System.out.print("(");
            for (Class d : pt) {
                System.out.print(d.getTypeName());
                if (comma < pt.length) {
                    System.out.print(", ");
                }
                comma++;
            }
            System.out.print(");");
            System.out.println();
        }
        System.out.println("}");
    }

    void fieldcommandArgs(String className) throws Exception {

        Class clazz = Class.forName(className);
        Field[] field = clazz.getFields();
        // String f = Modifier.toString(field);
        for (int i = 0; i < field.length; i++) {
            int mod = field[i].getModifiers();
            printModifier(mod);
            System.out.println(" " + field[i].getName());
        }
    }

    void constructorcommandArgs(String className) throws Exception {

        Class clazz = Class.forName(className);
        Constructor[] construct = clazz.getConstructors();
        System.out.println("\n");
        for (Constructor consts : construct) {
            int comma = 1;
            int mod = consts.getModifiers();
            printModifier(mod);
            System.out.print(" " + consts.getName() + "(");
            Class[] pt = consts.getParameterTypes();
            for (Class c : pt) {
                System.out.print(c.getTypeName());
                if (comma < pt.length) {
                    System.out.print(", ");
                }
                comma++;
            }
            System.out.print(")");
            System.out.println();
        }
    }

    public static void main(String[] args) throws Exception {

        String className = args[0];
        MyJavaP javap = new MyJavaP();
        javap.classcommandArgs(className);
        javap.interfacecommandArgs(className);
        javap.fieldcommandArgs(className);
        javap.constructorcommandArgs(className);
        javap.methodcommandArgs(className);
    }
}
