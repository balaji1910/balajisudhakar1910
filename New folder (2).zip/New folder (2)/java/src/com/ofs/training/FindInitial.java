package com.ofs.training;

public class FindInitial {

    public static void main(String[] args) {

        String fullName = "Hariharan Sekar";
        StringBuilder initial = new StringBuilder();
        int length = fullName.length();
        for (int i = 0; i < length; i++) {
            if (Character.isUpperCase(fullName.charAt(i))) {
                initial.append(fullName.charAt(i));
            }
        }
        log("the initial is: %s%n", initial);
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
