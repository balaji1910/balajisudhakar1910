package com.ofs.training;

import java.util.Arrays;

public class SortCity {

    public static void main(String[] args) {

        String[] city = { "Madurai",
                          "Thanjavur",
                          "TRICHY",
                          "Karur",
                          "Erode",
                          "trichy",
                          "Salem" };

        Arrays.sort(city, String.CASE_INSENSITIVE_ORDER);

        for (int index = 0; index < city.length; index++) {

            if ( index % 2 == 0 && index != 0) {

                System.out.println( city[index].toUpperCase());
            } else {

                System.out.println(city[index]);
            }
        }
    }
}
