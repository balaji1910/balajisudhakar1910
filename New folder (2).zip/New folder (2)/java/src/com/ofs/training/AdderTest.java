package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class AdderTest {

    Adder add;

    @BeforeClass
    private void initClass() {
        add = new Adder();
    }

    @Test(dataProvider = "testGetSum_positiveDP")
    private void testGetSum_positive(int[] input, int expectedSum) {
        try {
            int actualSum = add.getSum(input);
            Assert.assertEquals(actualSum, expectedSum);
        } catch (Exception e) {
            Assert.fail("Unexpected exception for input ");
        }
    }

    @DataProvider
    private Object[][] testGetSum_positiveDP() {
        return new Object[][] {
                                { new int[] { 1, 2, 3 }, 6 }, 
                                { new int[] { 5, 6, 7, 8 }, 26 } 
        };
    }

    @Test
    private void testGetSum_negative() {
        try {
            int actualSum = add.getSum(1);
            Assert.fail("Expected an exception.");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "enter more than one number");
        }
    }
}
