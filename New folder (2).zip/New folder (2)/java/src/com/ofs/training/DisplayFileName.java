package com.ofs.training;

import java.io.File;

public class DisplayFileName {

    public static void main(String[] args) {
        String path = args[0];
        String extension = args[1];
        File textFile = new File(path);
        String[] fileNames = textFile.list((dir, name) -> name.endsWith(extension));
        for (String fileName : fileNames) {
            log(fileName);
        }
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
