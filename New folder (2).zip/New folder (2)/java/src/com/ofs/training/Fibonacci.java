package com.ofs.training;

public class Fibonacci {

    static int numberOne = 0;
    static int numberTwo = 1;

    void forLoop(int upto) {
        System.out.println("fibonacci using for loop");
        int firstNumber = 0;
        int secondNumber = 1;
        int thirdNumber;
        System.out.print(firstNumber + " " + secondNumber);
        for (int loop = 0; loop < 5; loop++) {
        thirdNumber = firstNumber + secondNumber;
        System.out.print(" " + thirdNumber);
        firstNumber  = secondNumber;
        secondNumber = thirdNumber;
        }
        System.out.println("\n");
    }

    void whileLoop(int upto) {
        System.out.println("fibonacci using while loop");
        int firstNo = 0;
        int secondNo = 1;
        System.out.print(firstNo + " " + secondNo);
        int thirdNo;
        while ( upto < 5) {
            thirdNo = firstNo + secondNo;
            upto ++;
            System.out.print(" " + thirdNo);
            firstNo = secondNo;
            secondNo = thirdNo;
        }
        System.out.println("\n");
    }

    void recursion(int upto) {
        if (upto != 0) {
            int numberThree = numberOne + numberTwo;
            System.out.print(" " + numberThree);
            numberOne = numberTwo;
            numberTwo = numberThree;
            recursion(upto - 1);
        }
    }

    public static void main(String[] args) {

        Fibonacci series = new Fibonacci();
        series.forLoop(5);
        series.whileLoop(0);
        System.out.println("fibonacci using recursion");
        System.out.print(numberOne + " " + numberTwo);
        series.recursion(5);
    }
}
