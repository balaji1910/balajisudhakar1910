package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class FindDataTypeTest {

    FindDataType type;

    @BeforeClass
    private void initClass() {
        type = new FindDataType();
    }

    @Test(dataProvider = "testFindDataType_positiveDP")
    private void testGetDataType_positive(Object ob, String expectedDataType) {
        try {
            String actualDataType = type.getDataType(ob);
            Assert.assertEquals(actualDataType, expectedDataType);
        } catch (Exception e) {
            Assert.fail("Unexpected exception for input ");
        }
    }

    @DataProvider
    private Object[][] testFindDataType_positiveDP() {
        return new Object[][] {
                                { 100 / 24, "the dataType is int" },
                                { 100.10 / 10, "the dataType is double" },
                                { 10.5 / 0.5, "the dataType is double" },
                                { 12.4 % 5.5, "the dataType is double" },
                                { 100 % 56, "the dataType is int" }, };
    }

    @Test
    private void testGetDataType_negative() {
        try {
            String actualDataType = type.getDataType("Hariharan");
            Assert.fail("Expected an exception");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "only primitive dataTypes");
        }
    }

    @Test
    private void testGetDataType_negativeTwo() {
        try {
            String actualDataType = type.getDataType(null);
            Assert.fail("Expected an exception");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "cannot be null");
        }
    }
}
