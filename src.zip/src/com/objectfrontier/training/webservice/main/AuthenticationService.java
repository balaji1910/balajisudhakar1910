package com.objectfrontier.training.webservice.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Objects;

import com.objectfrontier.training.webservice.constantInterface.Query;
import com.objectfrontier.training.webservice.pojo.Address;
import com.objectfrontier.training.webservice.pojo.Person;

public class AuthenticationService {
	
	public Person login (String email, String password) {
		Connection connection = ConnectionManager.initConnection(); 
		Person person = new Person();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(Query.AUTHENTICATION);
			preparedStatement.setString(1, email);
			preparedStatement.setString(2, password);
			
			ResultSet resultSet = preparedStatement.executeQuery();
			
//			PersonService personService = new PersonService(new AddressService());
			while (resultSet.next()) {
				person.setId(resultSet.getLong("id"));
				person.setEmail(resultSet.getString("email"));
			}
			validate(person);
		} catch (Exception exception) {
			throw new AppException(ErrorCode.AUTHENTICAION_FAILED, exception);
		}
		return person;
	}
	
	private void validate(Person person) {

	       ArrayList<ErrorCode> exceptions = new ArrayList<>();
	       if (Objects.isNull(person.getEmail())) {
	           exceptions.add(ErrorCode.INVALID_EMAIL);
	       }

	       if(Objects.isNull(person.getPassword())) {
	    	   exceptions.add(ErrorCode.INVALID_PASSWORD);
	       }
   }
}
