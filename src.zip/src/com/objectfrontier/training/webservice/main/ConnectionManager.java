package com.objectfrontier.training.webservice.main;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Objects;
import java.util.Properties;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class ConnectionManager {
	
    public static Connection initConnection() {

    	Properties properties = new Properties();
    	InputStream inputStream = ConnectionManager.class.getClassLoader().getResourceAsStream("connection.properties");
    	Connection connection = null;
    	try {
        	properties.load(inputStream);
        	connection = DriverManager.getConnection(properties.getProperty("url"), properties.getProperty("user"), properties.getProperty("password"));

        	connection.setAutoCommit(false);
        } catch (Exception e) {
        	e.printStackTrace();
        }
    	return connection;
    }

//    private static HikariDataSource dataSource;
//    private static ThreadLocal<Connection> connectionThread = new ThreadLocal<>();
//    
//    static {
//	try {
//        InputStream inputStream = ConnectionManager.class.getClassLoader().getResourceAsStream("connection.properties");
//        Properties properties = new Properties();
//        properties.load(inputStream);
//        HikariConfig config = new HikariConfig(properties);
//        dataSource = new HikariDataSource(config);
//        } catch (Exception exception) {
//        	throw new AppException(ErrorCode.PROPERTY_FILE_ERROR, exception);
//        }
//    }
//
//    public static Connection initConnection() {
//
//        Connection connection;
//        if (Objects.isNull(dataSource)) {
//            throw new AppException(ErrorCode.SQL_EXCEPTION);
//        }
//        try {
//           connection = dataSource.getConnection();
//           connectionThread.set(connection);
//       } catch (Exception exception) {
//           throw new AppException(ErrorCode.CONNECTION_ERROR, exception);
//       }
//        return connection;
//    }
//
//    public static Connection getConnection() {
//        Connection connection = connectionThread.get();
//        return connection;
//    }
//    
    public static void releaseConnection(Connection connection, boolean doCommit) {

        try {
            if (doCommit) {
                connection.commit();
            } else {
                connection.rollback();
            }
            connection.close();
        } catch (Exception exception) {
        	throw new AppException(ErrorCode.CONNECTION_ERROR, exception);
        }
    }
}        
