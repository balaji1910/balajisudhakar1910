package com.objectfrontier.training.webservice.test;

import org.testng.Assert;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.webservice.main.AddressService;
import com.objectfrontier.training.webservice.main.AppException;
import com.objectfrontier.training.webservice.main.ConnectionManager;
import com.objectfrontier.training.webservice.pojo.Address;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AddressServiceTest {

    AddressService addressService;
//    ConnectionManager connectionManager; 
    Connection connection;
    
    @BeforeClass
    private void setUp() throws Exception {         
        addressService = new AddressService();
    }

    @Test(priority = 1, dataProvider = "testCreateAddress_positiveDP")
    private void testCreateAddress_positive(Address address) throws Exception {
         
    	connection = ConnectionManager.initConnection();
    	System.out.println(connection);
        try {
            Address actualResult = addressService.create(address, connection);
            Assert.assertEquals(actualResult.toString(), address.toString());
            connection.commit();
        } catch (AppException e) {
        	System.out.println(e.getCause());
            Assert.fail(e.toString());
        } finally {
        	connection.close();
        }
    }

    @DataProvider
    private Object[][] testCreateAddress_positiveDP() {
        
    	Address addressOne = new Address();
        addressOne.setStreet("Don");
        addressOne.setCity("Salem");
        addressOne.setPostalCode(605003);
        
        Address addressTwo = new Address();
        addressTwo.setStreet("Balaji");
        addressTwo.setCity("Chennai");
        addressTwo.setPostalCode(200976);
        
        Address addressThree = new Address();
        addressThree.setStreet("Nehru");
        addressThree.setCity("Madurai");
        addressThree.setPostalCode(110082);
        
        return new Object[][] {
                {addressOne},  
                {addressTwo},
                {addressThree}
        };
   }

    @Test(priority = 2, dataProvider = "testCreateAddress_negativeDP")
    private void testCreateAddress_negative(Address address) throws Exception {

        try {
            addressService.create(address, connection);
            Assert.fail("Expected an exception");
            connection.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "postal code cannot be null");
        } finally {
        	connection.close();
        }
    }
    
    @DataProvider
    private Object[][] testCreateAddress_negativeDP() {
    	
    	Address address = new Address();
    	address.setStreet("");
    	address.setCity("");
    	address.setPostalCode(0);
    	
    	return new Object[][] {
    		{address}
    	};
    }
    
// test case for Update
    @Test(priority = 3, dataProvider = "testUpdateAddress_positiveDP")
    private void testUpdateAddress_positive(Address address) throws Exception {

    	connection = ConnectionManager.initConnection();
        try {
            Address actualResult = addressService.update(address, connection);
            Assert.assertEquals(actualResult.toString(), address.toString());
            connection.commit();
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        } finally {
        	connection.close();
        }
    }

    @DataProvider
    private Object[][] testUpdateAddress_positiveDP() {
    	
    	Address address = new Address();
    	address.setCity("Salem");
        address.setStreet("old street");
        address.setPostalCode(605003);
        address.setId(4);
        
        return new Object[][] {
            {address}
        };
    }

    @Test(priority = 4, dataProvider = "testUpdateAdress_negativeDP")
    private void testUpdateAddress_negative(Address address) throws SQLException {

    	connection = ConnectionManager.initConnection();
        try {
            addressService.update(address, connection);
            Assert.fail("Expected an exception.");
            connection.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "id cannot be null");
        } finally {
        	connection.close();
        }
    }
    
    @DataProvider
    private Object[][] testUpdateAdress_negativeDP() {
    	
    	Address addressUpdate =  new Address();
    	addressUpdate.setStreet(null);
    	addressUpdate.setId(0);
    	
    	 return new Object[][] {
             {addressUpdate}
         };
    }
    
// test case to delete record    
    @Test(priority = 5, dataProvider = "testDeleteAddress_positiveDP")
    private void testDeleteAddress_positive(Address address) throws Exception {

    	connection = ConnectionManager.initConnection();
        try {
//        	Address address = new Address();
//        	address.setId(id);
            addressService.delete(address, connection);
            connection.commit();
        } catch (AppException e) {
            Assert.fail(e.getMessage());
//            e.getStackTrace();
        } finally {
        	connection.close();
        }
    }
  
    @DataProvider
    private Object[][] testDeleteAddress_positiveDP() {
    	
    	Address address = new Address();
    	address.setId(4);
    	return new Object[][] {
    		{address}
    	};
    }
    
    @Test(priority = 6, dataProvider = "testDeleteAddress_negativeDP")
    private void testDeleteAddress_negative(Address address) throws SQLException {

    	connection = ConnectionManager.initConnection();
        try {
            addressService.delete(address, connection);
            Assert.fail("Expected an exception.");
            connection.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "street cannot be null");
        } finally {
        	connection.close();
        }
    }
    
    @DataProvider
    private void testDeleteAddress_negativeDP() {
    	
    	Address address = new Address();
    	address.setId(0);
    }
    
// test case to read a record
    @Test(priority = 7, dataProvider = "testReadAddress_positiveDP")
    private void testReadAddress_positive(long id, Address expectedResult) throws SQLException {
    	connection = ConnectionManager.initConnection();
    	try {
    		Address actualResult = addressService.read(connection, id);
    		Assert.assertEquals(actualResult.toString(), expectedResult.toString());
    		
    	} catch (Exception e) {
    		Assert.fail(e.getMessage()); 
    	} finally {
        	connection.close();
        }
    }   
    
	@DataProvider
	private Object[][] testReadAddress_positiveDP() {

		Address expectedAddress = new Address();
		expectedAddress.setId(4);
		expectedAddress.setCity("Salem");
        expectedAddress.setStreet("old street");
        expectedAddress.setPostalCode(605003);
 	    return new Object[][] {
	        {1l, expectedAddress}
	    };
	}
	
//	@Test(priority = 8, dataProvider = "testReadAddress_negativeDP")
//	private void testReadAddress_negative(Address addressPojo) throws SQLException {
//	
//		connection = ConnectionManager.initConnection();
//	    try {
//	        addressService.read(addressPojo, connection);
//	        Assert.fail("Expected an exception.");
//	        connection.rollback();
//	    } catch (Exception e) {
//	        Assert.assertEquals(e.getMessage(), "id should not be empty");
//	    } finally {
//        	connection.close();
//        }
//	}   
	
	@DataProvider
	private Object[][] testReadAddress_negativeDP() {
		
		Address address = new Address();
		address.setId(0);
		return new Object[][] {
			{address}
		};
	}
	
	@Test(priority = 9, dataProvider = "testReadAllCheck_positiveDP")
	private void testReadAllCheck_positiveOne(List<Address> expectedList) throws SQLException {
	
		connection = ConnectionManager.initConnection();
	    try {
	    	List<Address> actualList = addressService.readAll(connection);
//	    	boolean actualResult = actualList.equals(expectedList);
//	    	boolean expectedResult = true;
	    	Assert.assertEquals(actualList, expectedList);
	    	connection.commit();
	
	    } catch (Exception e) {
	        Assert.fail(e.getMessage());
	    } finally {
        	connection.close();
        }
	}   
	
	@DataProvider
	private Object[][] testReadAllCheck_positiveDP() {
	
	    Address addressOne = new Address();
	    addressOne.setId(1);
	    addressOne.setStreet("Gandhi");
	    addressOne.setCity("Salem");
	    addressOne.setPostalCode(605003);
	
	
	    Address addressTwo = new Address();
	    addressTwo.setId(2);
	    addressTwo.setStreet("old street");
	    addressTwo.setCity("Chennai");
	    addressTwo.setPostalCode(200976);
	    
	    Address addressThree= new Address();
	    addressThree.setId(3);
	    addressThree.setStreet("Nehru");
	    addressThree.setCity("Madurai");
	    addressThree.setPostalCode(110082);
	    
	    List<Address> list = new ArrayList<>();
//	    list.add(addressOne);
	    list.add(addressTwo);
	    list.add(addressThree);

	    return new Object[][] {	
	        {list}
	    };
	} 

  @Test(priority = 10)
  private void testReadAllCheck_negative() {

      try {
          addressService.readAll(null);
          Assert.fail("Expected an exception.");
          connection.rollback();
      } catch (Exception e) {
          Assert.assertEquals(e.getMessage(), "connection not available");
      }
  }   

  @AfterClass
  private void afterClass() {

	  Connection connection = null;
	  Address address = null;
  }
}
