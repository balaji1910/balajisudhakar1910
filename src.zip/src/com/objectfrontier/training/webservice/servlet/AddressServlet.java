package com.objectfrontier.training.webservice.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.training.webservice.main.AddressService;
import com.objectfrontier.training.webservice.main.AppException;
import com.objectfrontier.training.webservice.main.ConnectionManager;
import com.objectfrontier.training.webservice.main.ErrorCode;
import com.objectfrontier.training.webservice.pojo.Address;
import com.objectfrontier.training.webservice.utils.JsonUtil;

//	class AddressServlet extends HttpServlet
//		getRequest()					  (define method to getRequest() from browser)
//			response.type()			      (check the response type, whether it is html or text)
//				perform operations
//					Address address 	  (create instance for Address)
//					Connection connection (create Connection)
//					addressService.read() (read AddressService)	
//			connection.close()	  		  (open connection)
//			write.response				  (write / send the response to browser)

public class AddressServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private AddressService addressService = new AddressService();

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("application/json");
		PrintWriter writer = response.getWriter();
		Connection connection = ConnectionManager.initConnection();
		long addressId = 0;
		
//		try {
		AddressService addressService = new AddressService();
		String id = request.getParameter("id");
			
//				if (Objects.nonNull(id)) {
//					try {
//						addressId = Long.parseLong(id);
//					} catch (Exception exception) {
//						throw new AppException(ErrorCode.EMPTY_INPUT);
//					}
//				}
		
		if (Objects.isNull(id)) {
			List<Address> addresses = new ArrayList<>();
			addresses = addressService.readAll(connection);
			writer.println(JsonUtil.toJson(addresses));
		} 
		
		if (Objects.nonNull(id)) {
			try {
				addressId = Long.parseLong(id);
				Address address = addressService.read(connection, addressId);
				writer.println(JsonUtil.toJson(address));
			} catch (Exception exception) {
				throw new AppException(ErrorCode.INVALID_URL_INPUT);
			}
		}
	} 
//	catch (AppException appException) {
//			ErrorPojo error = new ErrorPojo();
//			error.setErrors(appException.getExceptionList());
//			writer.write(JsonUtil.toJson(error));
//		}
//		ConnectionManager.releaseConnection(connection, false);
//	}

	@Override
	public void doDelete(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("application/json");
		Connection connection = ConnectionManager.initConnection();
		PrintWriter writer = response.getWriter();
//		try {
		String id = request.getParameter("id");
		Address address = new Address();
		address.setId(Long.parseLong(id));
		addressService.delete(address, connection);
		writer.println(JsonUtil.toJson(address));
//		ConnectionManager.releaseConnection(connection, true);
//		} catch (Exception exception) {
//			ConnectionManager.releaseConnection(connection, false);
//			writer.write(JsonUtil.toJson(exception));
//		}
	}

	@Override
	public void doPut(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("application/json");
		AddressService addressService = new AddressService();
		Connection connection = ConnectionManager.initConnection();
		PrintWriter writer = response.getWriter();
		
//		try {
		BufferedReader reader = request.getReader();
		List<String> jsonLines = reader.lines().collect(Collectors.toList()); 
																					
		String addressJson = String.join("", jsonLines);
		System.out.format("Input JSON >> %s", addressJson);
		Address address = JsonUtil.toObject(addressJson, Address.class);
		Address create = addressService.create(address, connection);
		writer.println(JsonUtil.toJson(create));
//		ConnectionManager.releaseConnection(connection, true);
//		} catch (Exception exception) {
//			ConnectionManager.releaseConnection(connection, false);
//			writer.write(JsonUtil.toJson(exception));
//		}
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("application/json");
		AddressService addressService = new AddressService();
		Connection connection = ConnectionManager.initConnection();
		PrintWriter writer = response.getWriter(); 
		
//		try {
		BufferedReader reader = request.getReader();
		List<String> jsonLines = reader.lines().collect(Collectors.toList());

		String addressJson = String.join("", jsonLines);
		Address address = JsonUtil.toObject(addressJson, Address.class);
		Address updateAddress = addressService.update(address, connection);
		writer.println(JsonUtil.toJson(updateAddress));
//		ConnectionManager.releaseConnection(connection, true);
//		} catch (Exception exception) {
//			ConnectionManager.releaseConnection(connection, false);
//			writer.write(JsonUtil.toJson(exception));
//		}
	}
}
