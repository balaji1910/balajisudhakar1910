package com.objectfrontier.training.webservice.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.objectfrontier.training.webservice.main.AppException;
import com.objectfrontier.training.webservice.main.AuthenticationService;
import com.objectfrontier.training.webservice.main.ConnectionManager;
import com.objectfrontier.training.webservice.pojo.Error;
import com.objectfrontier.training.webservice.pojo.Person;
import com.objectfrontier.training.webservice.utils.JsonUtil;

public class AuthenticationServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        AuthenticationService authenticationService = new AuthenticationService();
        Connection connection = null;
        PrintWriter writer = response.getWriter();
        Error error = new Error();
     
        try {
            connection = ConnectionManager.initConnection();
            HttpSession session = request.getSession();
            Person person = authenticationService.login(email, password);

            String sessionId = session.getId();
            response.setHeader("set cookies", sessionId);
            session.setAttribute("user", person);
            session.setAttribute("password", password);
            
            ConnectionManager.releaseConnection(connection, true);
        } catch (AppException appException) {
            ConnectionManager.releaseConnection(connection, false);
            error.setErrors(appException.getExceptionList());
            writer.println(JsonUtil.toJson(error));
        }
	}
	
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        session.invalidate();
    }
}
