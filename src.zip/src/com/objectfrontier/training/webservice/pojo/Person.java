// Person POJO

package com.objectfrontier.training.webservice.pojo;

import java.sql.Date;
import java.sql.Time;

public class Person {

	private long id;
	public void setId(long id) {
		this.id = id;
	}
	public long getId() {
		return id;
	}

	private String firstName;
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getFirstName() {
		return firstName;
	}
	
	private String lastName;
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getLastName() {
		return lastName;
	}

	private String email;
	public void setEmail(String email) {
		this.email = email;
	}
	public String getEmail() {
		return email;
	}

	private Address address;
	public void setAddress(Address address) {
		this.address = address;
	}
	public Address getAddress() {
		return address;
	}

	Date birthDate;
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}
	public Date getBirthDate() {
		return birthDate;
	}
	
	private Time createdDate;
	public void setCreatedDate(Time createdDate) {
		this.createdDate = createdDate;
	}
	public Time getCreatedDate() {
		return createdDate;
	}
	
	private String password;
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	private boolean isAdmin;
	public boolean isAdmin() {
		return isAdmin;
	}
	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}
	@Override
	public String toString() {
		return "Person [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
				+ ", address=" + address + ", birthDate=" + birthDate + ", createdDate=" + createdDate + ", password="
				+ password + ", isAdmin=" + isAdmin + "]";
	}
}
