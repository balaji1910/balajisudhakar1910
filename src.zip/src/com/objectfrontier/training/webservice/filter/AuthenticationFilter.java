package com.objectfrontier.training.webservice.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Objects;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.objectfrontier.training.webservice.main.AppException;
import com.objectfrontier.training.webservice.main.ErrorCode;
import com.objectfrontier.training.webservice.pojo.ErrorPojo;
import com.objectfrontier.training.webservice.utils.JsonUtil;

public class AuthenticationFilter implements Filter {

	@Override
    public void destroy() {}

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain) throws IOException, ServletException {
        
    	HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        
        HttpSession session = request.getSession(false);
        PrintWriter writer = response.getWriter();
        Object user = session.getAttribute("user");
        
        try {
            if (Objects.isNull(user)) {
                throw new AppException(ErrorCode.AUTHENTICAION_FAILED);
            }
            chain.doFilter(request, response);
        } catch (AppException appException) {
        	ErrorPojo error = new ErrorPojo();
        	error.setErrors(appException.getExceptionList());
            writer.println(JsonUtil.toJson(error));
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}
}

