package com.objectfrontier.training.webservice.utils;

import java.util.ArrayList;
import java.util.List;

/**
 * @author keerthanar
 * @since  Oct 03, 2016
 */
public class AppException extends RuntimeException {

    private static final long serialVersionUID = 8422080821407553434L;

    private List<AppErrCode> errorCodes;
    public AppException(List<AppErrCode> errorCodes) {
        this.errorCodes = errorCodes;
    }

    public AppException(List<AppErrCode> errorCodes, Throwable cause) {
        super(cause);
        this.errorCodes = errorCodes;
    }

    public AppException(AppErrCode errorCode, Throwable cause) {
        super(cause);
        this.errorCodes = new ArrayList<>(1);
        errorCodes.add(errorCode);
    }

    public AppException(Throwable cause) {
        this(AppErrCode.UNKNOWN_ERROR, cause);
    }

    @Override
    public String getMessage() {
        return toString();
    }

    @Override
    public String toString() {
        return errorCodes.toString();
    }
}
