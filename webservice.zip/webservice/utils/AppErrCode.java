package com.objectfrontier.training.webservice.utils;

/**
 * @author keerthanar
 * @since  Oct 03, 2016
 */
public enum AppErrCode {

	UNKNOWN_ERROR,
	LOAD_JSON_ERROR,
	STORE_JSON_ERROR;

	@Override
	public String toString() {
		return name();
	}
}
