package com.objectfrontier.training.webservice.servlet.test;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.webservice.pojo.Address;
import com.objectfrontier.training.webservice.utils.HttpMethod;
import com.objectfrontier.training.webservice.utils.JsonUtil;
import com.objectfrontier.training.webservice.utils.RequestHelper;

public class AddressServletTest {

	@Test(dataProvider = "testDoPutPositiveDP")
	public void testDoPutPositive(String url, Address address) throws Exception  {
		
			Address actual = new RequestHelper().setMethod(HttpMethod.PUT)
											    .setInput(address)
										   	    .requestObject(url, Address.class);

			Assert.assertTrue(actual.getId() > 0, "Auto generated ID should be greater than zero");
//			Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(address));
	}
	
	@DataProvider
	private Object[][] testDoPutPositiveDP() {
		
		Address firstAddress = new Address();
		firstAddress.setStreet		("7th Cross Street");
		firstAddress.setCity		("Chennai");
		firstAddress.setPostalCode	(600040);
		
		Address secondAddress= new Address();
		secondAddress.setStreet		("Gandhi Street");
		secondAddress.setCity		("Chennai");
		secondAddress.setPostalCode	(600050);
		
		Address thirdAddress= new Address();
		thirdAddress.setStreet		("Nehru Street");
		thirdAddress.setCity		("Thiruvallur");
		thirdAddress.setPostalCode	(600001);
		
		Address fourthAddress= new Address();
		fourthAddress.setStreet    	("Bose Street");
		fourthAddress.setCity      	("Chennai");
		fourthAddress.setPostalCode	(600101);
		
		
		return new Object[][] {
			{ "http://localhost:8080/webservice/Address", firstAddress},
			{ "http://localhost:8080/webservice/Address", secondAddress},
			{ "http://localhost:8080/webservice/Address", thirdAddress},
			{ "http://localhost:8080/webservice/Address", fourthAddress}
		};
	}

	@Test(dataProvider = "testDoGetPositiveDP")
	private void testDoGetPositive(String url, Address expected) throws Exception {

			Address actual = new RequestHelper().setMethod(HttpMethod.GET)
											    .requestObject(url, Address.class);

			Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
	}

	@DataProvider
	private Object[][] testDoGetPositiveDP() {

		Address firstAddress = new Address();
		firstAddress.setId			(1l);
		firstAddress.setStreet		("7th Cross Street");
		firstAddress.setCity		("Chennai");
		firstAddress.setPostalCode	(600040);
		
		Address secondAddress= new Address();
		secondAddress.setId			(2l);
		secondAddress.setStreet		("Gandhi Street");
		secondAddress.setCity		("Chennai");
		secondAddress.setPostalCode	(600050);
		
		Address thirdAddress= new Address();
		thirdAddress.setId			(3l);
		thirdAddress.setStreet		("Nehru Street");
		thirdAddress.setCity		("Thiruvallur");
		thirdAddress.setPostalCode	(600001);
		
		Address fourthAddress= new Address();
		fourthAddress.setId	   	   	(4l);
		fourthAddress.setStreet    	("Bose Street");
		fourthAddress.setCity      	("Chennai");
		fourthAddress.setPostalCode	(600101);		
		
		return new Object[][] {
			{ "http://localhost:8080/webservice/Address?id=1", firstAddress },
			{ "http://localhost:8080/webservice/Address?id=2", secondAddress },
			{ "http://localhost:8080/webservice/Address?id=3", thirdAddress },
			{ "http://localhost:8080/webservice/Address?id=4", fourthAddress }
		};
	}
	
	@Test(dataProvider = "testDoPostPositiveDP")
	public void testDoPostPositive(String url, Address address) throws Exception  {
		
			Address actual = new RequestHelper().setMethod(HttpMethod.POST)
											    .setInput(address)
										   	    .requestObject(url, Address.class);

			Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(address));
	}
	
	@DataProvider
	private Object[][] testDoPostPositiveDP() {
		
		Address firstAddress = new Address();
		firstAddress.setId			(1l);
		firstAddress.setStreet		("12th Main Road");
		firstAddress.setCity		("Chennai");
		firstAddress.setPostalCode	(600010);
		
		Address secondAddress= new Address();
		secondAddress.setId			(2l);
		secondAddress.setStreet		("Ambedhkar Street");
		secondAddress.setCity		("Salem");
		secondAddress.setPostalCode	(700012);
		
		Address thirdAddress= new Address();
		thirdAddress.setId			(3l);
		thirdAddress.setStreet		("HeyRam Street");
		thirdAddress.setCity		("Pondicherry");
		thirdAddress.setPostalCode	(100001);
		
		Address fourthAddress= new Address();
		fourthAddress.setId	   	   	(4l);
		fourthAddress.setStreet    	("Nandhanam Street");
		fourthAddress.setCity      	("Madurai");
		fourthAddress.setPostalCode	(400121);	
		
		return new Object[][] {
			{ "http://localhost:8080/webservice/Address", firstAddress },
			{ "http://localhost:8080/webservice/Address", secondAddress },
			{ "http://localhost:8080/webservice/Address", thirdAddress },
			{ "http://localhost:8080/webservice/Address", fourthAddress }
		};
	}
	
	@Test(dataProvider = "testDoDeletePositiveDP")
	public void testDoDeletePositive(String url, Address address) throws Exception  {
		
			long actual = new RequestHelper().setMethod(HttpMethod.DELETE)
											 .setInput(address)
										   	 .requestObject(url, long.class);

			Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(address));
	}
	
	
	@DataProvider
	private Object[][] testDoDeletePositiveDP() {
		
		Address firstAddress = new Address();
		firstAddress.setId(1l);
		
		return new Object[][] {
			{ "http://localhost:8080/webservice/Address?id=1", firstAddress },
		};
	}
}
