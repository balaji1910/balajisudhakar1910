package com.objectfrontier.training.webservice.servlet.test;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.webservice.pojo.Address;
import com.objectfrontier.training.webservice.pojo.Person;
import com.objectfrontier.training.webservice.utils.HttpMethod;
import com.objectfrontier.training.webservice.utils.JsonUtil;
import com.objectfrontier.training.webservice.utils.RequestHelper;


public class PersonServletTest {

    RequestHelper requestHelper;

    @BeforeClass()
    private void setup() throws Exception {
        requestHelper = new RequestHelper();
    }

    @Test(dataProvider = "testRead", priority = 3)
    private void testRead(String uri, Person expectedPerson) throws Exception {
            Person person = requestHelper.setMethod(HttpMethod.GET).requestObject(uri, Person.class);
            Assert.assertEquals(JsonUtil.toJson(person), JsonUtil.toJson(expectedPerson));
    }

    @DataProvider
    private Object[][] testRead() {
        String uri = "http://localhost:8080/ws/person?id=1&include=true";
        Person person = new Person(1, "HariHaran", "sekar", "hari@ofs", Date.valueOf("1996-06-19"), 
                new Address(1, "kk nagar", "chennai", 600028));

        return new Object[][] {
            {uri, person}
        };
    }

    @Test(dataProvider = "testReadAll", priority = 4)
    private void testReadAll(String uri, List<Person> expectedList) throws Exception {
            String personDetail = requestHelper.setMethod(HttpMethod.GET).requestString(uri);
            List<Person> Person = JsonUtil.toList(personDetail, Person.class);
            Assert.assertEquals(JsonUtil.toJson(Person), JsonUtil.toJson(expectedList));
    }

    @DataProvider
    private Object[][] testReadAll() {
        String uri = "http://localhost:8080/ws/person?include=true";

        List<Person> personList = new ArrayList<>();
        personList.add(new Person(1, "HariHaran", "sekar", "hari@ofs", Date.valueOf("1996-06-19"), 
                       new Address(1, "kk nagar", "chennai", 600028)));
        personList.add(new Person(2,"Naveen", "raj", "naveen@ofs", Date.valueOf("1996-07-09"), 
                       new Address(2, "Tnagar", "chennai", 600075)));
        personList.add(new Person(3, "almas", "mahamed", "almas@ofs", Date.valueOf("1996-07-09"), 
                       new Address(3, "nagar", "chennai", 600070)));
        personList.add(new Person(4, "prasanna", "mahesh", "lpk@ofs", Date.valueOf("1996-07-09"), 
                       new Address(4, "nagar", "chennai", 600070)));
        personList.add(new Person(5, "mani", "bharathi", "mani@ofs", Date.valueOf("1997-01-12"), 
                       new Address(5, "Tnagar", "chennai", 600075)));
        personList.add(new Person(6, "aravind", "Krishna", "ak@ofs", Date.valueOf("1997-01-01"), 
                       new Address(6, "taramani", "chennai", 600010)));
        personList.add(new Person(7, "karthi", "kk", "kk@ofs", Date.valueOf("1996-06-23"), 
                       new Address(7, "taramani", "chennai", 600010)));
        personList.add(new Person(8, "karthi", "uk", "uk@ofs", Date.valueOf("1996-06-23"), 
                       new Address(8, "perambur", "chennai", 600070)));
        personList.add(new Person(9, "Tamil", "arasan", "tamil@ofs", Date.valueOf("1996-06-19"), 
                       new Address(9, "food street", "chennai", 600075)));
        return new Object[][] {
            {uri, personList}
        };
    }

    @Test(dataProvider = "testCreate", priority = 1)
    private void testCreate(String uri, Person person) throws Exception {
            Person createdPerson = requestHelper.setInput(person)
                         .setMethod(HttpMethod.PUT)
                         .requestObject(uri, Person.class);
            person.setId(createdPerson.getId());
            person.setAddress(createdPerson.getAddress());
            Assert.assertEquals(JsonUtil.toJson(createdPerson), JsonUtil.toJson(person));
    }

    @DataProvider
    private Object[][] testCreate() {
        Person person = new Person("vignesh", "sekar", "vignesh@ofs", Date.valueOf("1996-06-19"), 
                new Address("nungambakkam", "chennai", 600022));
        String uri = "http://localhost:8080/ws/person";
        return new Object[][] {
            {uri, person}
        };
    }

    @Test(dataProvider = "testUpdate", priority = 2)
    private void testUpdate(String uri, Person person) throws Exception {
            Person createdPerson = requestHelper.setInput(person)
                    .setMethod(HttpMethod.POST)
                    .requestObject(uri, Person.class);
            Assert.assertEquals(JsonUtil.toJson(createdPerson), JsonUtil.toJson(person));
    }

    @DataProvider
    private Object[][] testUpdate() {
        Person person = new Person(10, "vignesh", "manoharan", "vigneshManoharan@ofs", Date.valueOf("1996-06-19"), 
                new Address(10, "nungambakkam", "salem", 600022));
        String uri = "http://localhost:8080/ws/person";
        return new Object[][] {
            {uri, person}
        };
    }

    @Test(priority = 4)
    private void testDelete() throws Exception {
            String uri = "http://localhost:8080/ws/person?id=10";
            requestHelper.setMethod(HttpMethod.DELETE);
            String response = requestHelper.requestString(uri);
            System.out.println(response);
    }
}
