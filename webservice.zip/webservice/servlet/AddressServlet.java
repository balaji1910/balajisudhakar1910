package com.objectfrontier.training.webservice.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.training.webservice.main.AddressService;
import com.objectfrontier.training.webservice.main.ConnectionManager;
import com.objectfrontier.training.webservice.pojo.Address;
import com.objectfrontier.training.webservice.utils.JsonUtil;

//	class AddressServlet extends HttpServlet
//		getRequest()					  (define method to getRequest() from browser)
//			response.type()			      (check the response type, whether it is html or text)
//				perform operations
//					Address address 	  (create instance for Address)
//					Connection connection (create Connection)
//					addressService.read() (read AddressService)	
//			connection.close()	  		  (open connection)
//			write.response				  (write / send the response to browser)

public class AddressServlet extends HttpServlet {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException{

		Connection connection = ConnectionManager.initConnection();
		AddressService addressService = new AddressService();
		String id = request.getParameter("id");
		PrintWriter writer = response.getWriter();

		if (id == null) {
			List<Address> addresses = new ArrayList<>();
			try {
				addresses = addressService.readAll(connection);
				writer.println(JsonUtil.toJson(addresses));
			} catch (Exception exception) {
				writer.write(JsonUtil.toJson(exception));
			}
		} else {
			try {
				Address address = addressService.read(connection, Long.parseLong(id));
				writer.println(JsonUtil.toJson(address));
			} catch (Exception exception) {
				writer.write(JsonUtil.toJson(exception));
			} finally {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public void doDelete(HttpServletRequest request, HttpServletResponse response) throws IOException {

		AddressService addressService = new AddressService();
		Connection connection = ConnectionManager.initConnection();
		PrintWriter writer = response.getWriter();
		try {
			String id = request.getParameter("id");
			Address address = new Address();
			address.setId(Long.parseLong(id));
			addressService.delete(address, connection);
			writer.println(JsonUtil.toJson(address));
			connection.commit();
		} catch (Exception exception) {
			writer.write(JsonUtil.toJson(exception));
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void doPut(HttpServletRequest request, HttpServletResponse response) throws IOException {

		AddressService addressService = new AddressService();
		Connection connection = ConnectionManager.initConnection();
		PrintWriter writer = response.getWriter();
		
		try {
			BufferedReader reader = request.getReader();
			List<String> jsonLines = reader.lines().collect(Collectors.toList()); 
																					
			String addressJson = String.join("", jsonLines);
			System.out.format("Input JSON >> %s", addressJson);
			Address address = JsonUtil.toObject(addressJson, Address.class);
			Address createAddress = addressService.create(address, connection);
			writer.println(JsonUtil.toJson(createAddress));
			connection.commit();
		} catch (Exception exception) {
			writer.write(JsonUtil.toJson(exception));
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

		AddressService addressService = new AddressService();
		Connection connection = ConnectionManager.initConnection();
		PrintWriter writer = response.getWriter(); 
		
		try {
			BufferedReader reader = request.getReader();
			List<String> jsonLines = reader.lines().collect(Collectors.toList());

			String addressJson = String.join("", jsonLines);
			Address address = JsonUtil.toObject(addressJson, Address.class);
			Address updateAddress = addressService.update(address, connection);
			writer.println(JsonUtil.toJson(updateAddress));
			connection.commit();
		} catch (Exception exception) {
			writer.write(JsonUtil.toJson(exception));
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
