package com.objectfrontier.training.webservice.test;

import java.sql.Connection;
import java.sql.Date;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.webservice.main.AddressService;
import com.objectfrontier.training.webservice.main.AppException;
import com.objectfrontier.training.webservice.main.ConnectionManager;
import com.objectfrontier.training.webservice.main.PersonService;
import com.objectfrontier.training.webservice.pojo.Address;
import com.objectfrontier.training.webservice.pojo.Person;

public class PersonServiceTest {

AddressService addressService;
PersonService personService;
ConnectionManager connectionManager;

@BeforeClass
private void setUp() throws Exception {   
	
    connectionManager = new ConnectionManager();
    addressService = new AddressService();
    personService = new PersonService(addressService);
}

     @Test(priority = 1, dataProvider = "createPerson_positiveDP")
    private void testCreate_positive(Person person,  Person expectedResult) throws Exception {

    	Connection connection = ConnectionManager.initConnection();
        try {
            Person actualResult = personService.create(connection, person);
            Assert.assertEquals(actualResult.toString(), person.toString());
            connection.commit();
        } catch (Exception e) {
            Assert.fail(e.getMessage());
            connection.rollback();
        } finally {
        	connection.close();
        }
    }

    @DataProvider
    private Object[][] create_positiveDP() {
        Person personOne = new Person();
        personOne.setFirstName("Balaji");
        personOne.setLastName("Sudhakar");
        personOne.setEmail("balaji@gmail.com");
        personOne.setBirthDate(Date.valueOf("1996-10-19"));

        Address addressOne = new Address();
        addressOne.setStreet("7th Street");
        addressOne.setCity("Chennai");
        addressOne.setPostalCode(600040);

        Person personTwo = new Person();
        personTwo.setFirstName("Heath");
        personTwo.setLastName("Ledger");
        personTwo.setEmail("joker@gmail.com");
        personTwo.setBirthDate(Date.valueOf("1996-02-13"));

        Address addressTwo = new Address();
        addressTwo.setStreet("Cardiff Street");
        addressTwo.setCity("Cardiff");
        addressTwo.setPostalCode(100001);
        
        Person personThree = new Person();
        personThree.setFirstName("Harish");
        personThree.setLastName("Kumar");
        personThree.setEmail("harishKumar@gmail.com");
        personThree.setBirthDate(Date.valueOf("1997-10-21"));

        Address addressThree = new Address();
        addressThree.setStreet("Billgates Street");
        addressThree.setCity("Chennai");
        addressThree.setPostalCode(600011);
        
        return new Object[][] {
            {personOne, addressOne},
            {personTwo, addressTwo},
            {personThree, addressThree}
        };
    }

    @Test(priority = 2)
    private void testCreate_negative() throws Exception {

    	Connection connection = ConnectionManager.initConnection();
        try {
            Person person = new Person();
            person.setFirstName(null);
            personService.create(connection, person);
            Assert.fail("Expected an exception");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "postal code cannot be null");
        }
    }

    @Test(priority = 3, dataProvider = "testUpdatePerson_positiveDP")
    private void testUpdate_positive(Person person, Address address , Person expectedResult)  throws Exception {

    	Connection connection = ConnectionManager.initConnection();
    	try {
            Person actualResult = personService.update(person, address, connection);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        } finally {
        	connection.close();
        } 
    }

    @DataProvider
    private Object[][] testUpdate_positiveDP() {
    	
    	Address address = new Address();
    	address.setStreet("Batgirl Street");
    	address.setCity("Gotham");
    	address.setPostalCode(123456);

        Person person = new Person();
        person.setId(1);
        person.setFirstName("Christian");
        person.setLastName("Bale");
        person.setEmail("batman@gmail.com");
        person.setBirthDate(Date.valueOf("1975-05-02"));
        person.setAddress(address);
                
        Person expectedPerson = new Person();
        expectedPerson.setId(1);
        expectedPerson.setFirstName("Christian");
        expectedPerson.setLastName("Bale");
        expectedPerson.setEmail("batman@gmail.com");
        expectedPerson.setBirthDate(Date.valueOf("1975-05-02"));
        expectedPerson.setAddress(address);
        
        return new Object[][] {
            {person, address, expectedPerson}
        };
    }

    @Test(priority = 4)
    private void testUpdate_negative() throws Exception {

    	Connection connection = ConnectionManager.initConnection();
        try {
            Person person  = new Person();
            Address address = new Address();
            person.setId(0);
            person.setFirstName(null);
            person.setLastName(null);
            person.setEmail(null);
            person.setAddress(null);
            person.setBirthDate(null);
            personService.update(person, address, connection);
            Assert.fail("Expected an exception.");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "email cannot be null");
        }
    }

    @Test(priority = 5, dataProvider = "testReadCheck_positiveDP", groups = {"read"})
    private void testRead_positive(Person person, boolean includeAddress, long id) throws Exception {
        
    	Connection connection = ConnectionManager.initConnection();
        try {
            Person personDetail = personService.read(connection, includeAddress, id);
            Assert.assertEquals(personDetail.toString(), person.toString());
        } catch (Exception e) {
            Assert.fail("read operation fails");
        } finally {
            connection.close();
        }
    }

    @DataProvider
    private Object[][] testRead_positiveDP() {
        Person person = new Person();
        person.setId(1);
        Address address = new Address();
        address.setId(1);
        person.setAddress(address);

        Person personDetail = new Person();
        personDetail.setId(1);
        
        return new Object[][] {
            {person, true}, 
            {personDetail, false}
        };
    }
    
    @Test(priority = 6, dataProvider = "testDelete_positiveDP")
    private void testDelete_positive(Person person) throws Exception {
        Connection connection = ConnectionManager.initConnection();
        try {
            personService.delete(connection, person);
            connection.commit();
        } catch (AppException e) {
            connection.rollback();
            Assert.fail();
        } finally {
            connection.close();
        }
    }

    @DataProvider
    private Object[][] testDelete_positiveDP() {
        Person person = new Person();
        person.setId(9);
        Address address = new Address();
        address.setId(9);
        person.setAddress(address);
        return new Object[][] {
            {person}
        };
    }

    
    @AfterClass
    private void afterClass() {
//    	addressService = null;
//    	connection = null;
    }
}
