package com.objectfrontier.training.webservice.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

import com.objectfrontier.training.webservice.pojo.Address;
import com.objectfrontier.training.webservice.pojo.Person;

public class PersonService {

//    Address address;
//	ConnectionManager connectionManager;
//    Connection connection;
    
    private AddressService addressService = new AddressService();
    public PersonService(AddressService addressService) {
    	this.addressService = addressService;
    }
    
    public Person create(Connection connection, Person person) {

    	Address address = person.getAddress();
    	List<ErrorCode> errors = new ArrayList<>();
    	try {
	    	addressService.create(address, connection);
    	} catch (AppException exception) {
            if (exception.getCause() != null) {
                throw new AppException(ErrorCode.SQL_EXCEPTION, exception);
            }
        }
    	
    	validate(connection, person, errors);
        String query = new StringBuilder()
        		.append("INSERT INTO person_service (first_name " )
        		.append(" 						   , last_name	" )
				.append("						   , email      " )
				.append("						   , address_id " )
				.append(" 						   , birth_date)" )
				.append("	VALUES (?, ?, ?, ?, ?)				").toString();
	        
        try {
	        PreparedStatement preparedStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
	        preparedStatement.setString(1, person.getFirstName());
	        preparedStatement.setString(2, person.getLastName());
	        preparedStatement.setString(3, person.getEmail());
	        preparedStatement.setObject(4, address.getId());
	        preparedStatement.setDate(5, person.getBirthDate());
	        preparedStatement.executeUpdate();
	        ResultSet resultSet = preparedStatement.getGeneratedKeys();
            resultSet.next();
            person.setId(resultSet.getLong(1));
    	} catch(SQLException exception) {
    		throw new AppException(ErrorCode.SQL_EXCEPTION, exception);
    	}
        
        if (person.getId() == 0) {
            errors.add(ErrorCode.PERSON_ID_ERROR);
            throw new AppException(errors);
        }
        return person;
	}
    
    private boolean isEmpty(String value) {
        return (Objects.isNull(value) || "".equals(value));
    }


    public Person update(Connection connection, Person person) {

    	String query = new StringBuilder()
    			.append("UPDATE person_service SET first_name =?	")
				.append("					  	  , last_name = ?	")
				.append("					  	  , email = ?		")
				.append("					  	  , address_id = ?	")
				.append("					  	  , birth_date = ?	")
				.append("   WHERE id = ?").toString();

    	List<ErrorCode> errors = new ArrayList<>();
    	try {
    		validate(connection, person, errors);
    	} catch (AppException errorCode) {
    		throw new AppException(errors);
    	}
    	
    	try {
	    	PreparedStatement preparedStatement = connection.prepareStatement(query);
	    	preparedStatement.setString(1, person.getFirstName());
	    	preparedStatement.setString(2, person.getLastName());
	    	preparedStatement.setString(3, person.getEmail());
	    	preparedStatement.setLong(4, person.getAddress().getId());
	        preparedStatement.setDate(5, person.getBirthDate());
	        preparedStatement.setLong(6, person.getId());
	        preparedStatement.executeUpdate();
    	} catch (Exception exception) {
            throw new AppException(ErrorCode.UPDATE_OPERATION_FAILED, exception);
        }
        if (person.getAddress() != null) {
        	Address address = person.getAddress();
            addressService.update(address, connection);
        }
        return person;
    }

    public void delete(Connection connection, long id) {
    	
		String query = new StringBuilder()
    			.append("DELETE 					")
    			.append("	FROM person_service WHERE id = ?").toString();
		Person person = read(connection, true, id);
	    	
		try {
	    	PreparedStatement preparedStatement = connection.prepareStatement(query);
	    	preparedStatement.setLong(1, id);
	    	preparedStatement.executeUpdate();
    	} catch (Exception exception) {
    		throw new AppException(ErrorCode.DELETE_OPERATION_FAILED, exception);
    	}
	
    	Address address = person.getAddress();
    	addressService.delete(address, connection);
    }

    private void validate(Connection connection, Person person, List<ErrorCode> exceptions) {

		if (isEmpty(person.getFirstName())) {
			exceptions.add(ErrorCode.FIRST_NAME_NOT_FOUND);
		}
		
		if (isEmpty(person.getLastName())) {
			exceptions.add(ErrorCode.LAST_NAME_NOT_FOUND);
		}

		boolean isDuplicatePerson = isDuplicatePerson(connection, person);
		if (isDuplicatePerson) {
			exceptions.add(ErrorCode.DUPLICATE_NAME);
		}
		
		boolean isDuplicateEmail = isDuplicateEmail(connection, person);
		if (isDuplicateEmail) {
			exceptions.add(ErrorCode.DUPLICATE_EMAIL);
		}
		
		if (Objects.isNull(person.getBirthDate())) {
			exceptions.add(ErrorCode.DOB_NOT_FOUND);
		}
		
		if (person.getBirthDate() != null) {
			java.util.Date today = new java.util.Date();
			java.sql.Date now = new java.sql.Date(today.getTime());

			if (now.compareTo(person.getBirthDate()) == -1) {
				exceptions.add(ErrorCode.ILLEGAL_DOB_FORMAT);
			}
		}
		
		if (exceptions.size() > 0) {
			throw new AppException(exceptions);
		}
    }

//    private boolean validateId(Connection connection, Person person) throws SQLException {
//    	
//    	int count = 0;
//    	if (person.getId() >= 0) {
//    		String countId = new StringBuilder()
//    				.append("SELECT count(id) ")
//    				.append(	"FROM person_service WHERE id = ?").toString();
//    		
//    		PreparedStatement preparedStatement = connection.prepareStatement(countId);
//    		preparedStatement.setLong(1, person.getId());
//    		
//    		ResultSet resultSet = preparedStatement.executeQuery();
//    		resultSet.next();
//    		
//    		long count = resultSet.getLong(1);
//    		if (count == 0) {
//    			throw new AppException(ErrorCode.PERSON_ID_NOT_FOUND);
//    		}
//    	} else {
//    		throw new AppException(ErrorCode.PERSON_ID_NOT_FOUND);
//    	}
//    	return count > 0 ? true : false;
//    }
		
	private boolean isDuplicateEmail(Connection connect, Person person) {
		
		int count = 0;
		try {
			String query = new StringBuilder()
			  .append("SELECT COUNT(id) AS duplicate_email ")
			  .append("	   FROM trn_person 				   ")
			  .append("	   WHERE email = ? AND id != ? 	   ").toString();
			PreparedStatement statement = connect.prepareStatement(query);
			statement.setString(1, person.getEmail());
			statement.setLong(2, person.getId());
			ResultSet result = statement.executeQuery();
			while (result.next()) {
				count = result.getInt("duplicate_email");
			}
		} catch (SQLException sqlException) {
			throw new AppException(ErrorCode.SQL_EXCEPTION, sqlException);
		}
		return count > 0 ? true : false;
	}
	
	private boolean isDuplicatePerson(Connection connect, Person person) {
		
		int idCount = 0;
		try {
			String anotherQuery = new StringBuilder()
			      .append("SELECT COUNT(id) AS duplicate_name FROM trn_person WHERE      ")
			      .append("first_name =? AND last_name = ? AND id != ?                  ")
			      .toString();
			PreparedStatement statement = connect.prepareStatement(anotherQuery);
			statement.setString(1, person.getFirstName());
			statement.setString(2, person.getLastName());
			statement.setLong(3, person.getId());
			ResultSet anotherResult = statement.executeQuery();
			while (anotherResult.next()) {
			  idCount = anotherResult.getInt("duplicate_name");
			}
		} catch (SQLException sqlException) {
			throw new AppException(ErrorCode.SQL_EXCEPTION, sqlException);
		}
		return idCount > 0 ? true : false;
	}

	public Person read(Connection connection, boolean includeAddress, long id) {
		
		Person person = new Person();
		try {
			String query = new StringBuilder()		
				.append("SELECT  id					 ")
				.append("	   , first_name			 ")
				.append("	   , last_name			 ")
				.append("	   , email				 ")
				.append("	   , date_of_birth		 ")
				.append("	   , address_id 		 ")
				.append("   FROM person WHERE id = ? ").toString();
		
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setLong(1, id);
			
			ResultSet resultSet = preparedStatement.executeQuery();
	
			if (resultSet.next()) {
			
				person.setId(resultSet.getLong("id"));
				person.setFirstName(resultSet.getString("firstname"));
				person.setLastName(resultSet.getString("lastname"));
				person.setEmail(resultSet.getString("email"));
				person.setBirthDate(resultSet.getDate("birth_date"));
				Address address = new Address();
				address.setId(resultSet.getLong("id"));
				address = addressService.read(connection, id);
				person.setAddress(address);
			} else {
				throw new AppException(ErrorCode.NO_RECORD_FOUND);
			}
			
		} catch (Exception exception) {
			throw new AppException(ErrorCode.READ_OPERATION_FAILED, exception);
		}
		
		if (includeAddress) {
            Address address = person.getAddress();
            long addressId = address.getId();
            Address addressDetail = addressService.read(connection, addressId);
            person.setAddress(addressDetail);
        }
			return person;
	}

	public List<Person> readAll(Connection connection, boolean includeAddress) {

		if (!includeAddress) {
			String query = new StringBuilder()
					.append("SELECT id			")
					.append("	  , first_name	")
					.append("	  , last_name	")
					.append("	  , email		")
					.append("	  , birth_date	")
					.append("	FROM trn_person	").toString();
	
			List<Person> personList = new ArrayList<>();
			try {
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				ResultSet resultSet = preparedStatement.executeQuery();
				while (resultSet.next()) {
					Person person = new Person();
					person.setId(resultSet.getLong("id"));
					person.setFirstName(resultSet.getString("firstname"));
					person.setLastName(resultSet.getString("lastname"));
					person.setEmail(resultSet.getString("email"));
					person.setBirthDate(resultSet.getDate("birth_date"));
					personList.add(person);
				}
			} catch (Exception exception) {
				throw new AppException(ErrorCode.SQL_EXCEPTION, exception);
			}
			return personList;
		} else {
			String query = new StringBuilder()
					.append("SELECT id			")
					.append("	  , first_name	")
					.append("	  , last_name	")
					.append("	  , email		")
					.append("	  , birth_date	")
					.append("	  , address_id	")
					.append("	FROM trn_person	").toString();
			try {
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				ResultSet resultSet = preparedStatement.executeQuery();
				
				List<Person> persons = new ArrayList<>();
				List<Address> addresses = addressService.readAll(connection);
				while (resultSet.next()) {
					Person person = new Person();
					person.setId(resultSet.getLong("id"));
					person.setFirstName(resultSet.getString("firstname"));
					person.setLastName(resultSet.getString("lastname"));
					person.setEmail(resultSet.getString("email"));
					person.setBirthDate(resultSet.getDate("birth_date"));
				
					long addressId = resultSet.getLong(6);
					addresses.stream()
							   .filter(address -> {return address.getId() == addressId;})
							   .forEach(address -> {person.setAddress(address);});
					persons.add(person);
				} catch (Exception exception) {
					throw new AppException(ErrorCode.SQL_EXCEPTION, exception);
				}
			return persons;
	}
}
