package com.objectfrontier.training.webservice.main;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Objects;
import java.util.Properties;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class ConnectionManager {
	
//    public static Connection initConnection() {
//        
//    	Properties properties = new Properties();
//    	InputStream inputStream = ConnectionManager.class.getClassLoader().getResourceAsStream("connection.properties");
//    	Connection connection = null;
//    	try {
//        	properties.load(inputStream);
//        	connection = DriverManager.getConnection(properties.getProperty("url"), properties.getProperty("user"), properties.getProperty("password"));
//
//        	connection.setAutoCommit(false);
//        } catch (Exception e) {
//        	e.printStackTrace();
//        }
//    	return connection;
//    }

    private static HikariDataSource dataSource;
    static {
        InputStream inputStream = ConnectionManager.class.getClassLoader().getResourceAsStream("connection.properties");
        Properties property = new Properties();
          try {
            property.load(inputStream);
        } catch (IOException e) {
            System.out.println("error in reading property file");
        }
          HikariConfig config = new HikariConfig(property);
          dataSource = new HikariDataSource(config);
    }

    public static Connection initConnection() {

        Connection connection;
        if (Objects.isNull(dataSource)) {
            throw new AppException(ErrorCode.SQL_EXCEPTION);
        }
        try {
           connection = dataSource.getConnection();
       } catch (SQLException exception) {
           throw new AppException(ErrorCode.CONNECTION_ERROR, exception);
       }
        return connection;
    }

    public static void releaseConnection(Connection connection, boolean doCommit) {

        try {
            if (doCommit) {
                connection.commit();
            } else {
                connection.rollback();
            }
            connection.close();
        } catch (SQLException sqlException) {
        	throw new AppException(ErrorCode.CONNECTION_ERROR, sqlException);
        }
    }
        
    public static void main(String[] args) {
    	ConnectionManager.initConnection();
    }
}
