package com.objectfrontier.training.webservice.main;

public enum ErrorCode {
	
	NO_RECORD_FOUND			(100, "Record not found"),
	SQL_EXCEPTION 			(101, "SQL Syntax or Server Error"),
    ADDRESS_ID_NOT_FOUND 	(102, "Address id column is empty"),
    ADDRESS_ID_ERROR    (103, "Address id column is not auto generated"),
    STREET_FIELD_NOT_FOUND	(104, "Street field is empty"),
    CITY_FIELD_NOT_FOUND	(105, "City field is empty"),
    PINCODE_NOT_FOUND		(106, "Pincode is empty"),
    PINCODE_INVALID			(107, "Pincode is invalid"),

    PERSON_ID_NOT_FOUND		(108, "Person id column is empty"),
    FIRST_NAME_NOT_FOUND    (109, "First name field is empty"),
    LAST_NAME_NOT_FOUND		(110, "Last name field is empty"),
    DUPLICATE_NAME			(111, "Name already exist"),
    PERSON_ID_ERROR			(112, "Person id column is not auto incremented"),
    DUPLICATE_EMAIL			(113, "Duplicate email found"),
    EMAIL_NOT_FOUND			(114, "Email is empty"),
	ILLEGAL_DOB_FORMAT  	(115, "DOB should be in 'dd-mm-yyyy' format"),
	DOB_NOT_FOUND			(116, "DOB is empty"),
	
	CREATE_OPERATION_FAILED	(117, "Error in creating person"), 
    READ_OPERATION_FAILED	(118, "Error in reading person details"), 
    UPDATE_OPERATION_FAILED	(119, "Error in Updating person"), 
    DELETE_OPERATION_FAILED	(120, "Error in deleting person"),
    SEARCH_OPERATION_FAILED	(121, "Error in searching address details"), 
    ENTER_VALID_INPUT		(122, "Error occured while parsing input"),
    READALL_OPERATION_FAILED(118, "Error in reading all person details"),
    
	CONNECTION_ERROR		(123, "database connection error"), 
    DATASOURCE_ERROR		(124, "Datasource error"), 
    LOAD_JSON_ERROR			(125, "error in loading json"), 
    STORE_JSON_ERROR		(126, "error in storing json"), 
    UNKNOWN_ERROROR			(127, "UnKnown error");
	
    private int errorCode;
    private String message;

    private ErrorCode(int errorCode, String message) {
        this.message = message;
        this.errorCode = errorCode;
    }

    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }

    public int getErrorCode() {
        return errorCode;
    }
    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }
    
    @Override
    public String toString() {
        return String.format("ErrorCode = %d, ErrorMessage = %s", errorCode, message);
    }
};
