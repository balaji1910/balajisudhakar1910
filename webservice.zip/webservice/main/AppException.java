package com.objectfrontier.training.webservice.main;

import java.util.ArrayList;
import java.util.List;

public class AppException extends RuntimeException{

    private static final long serialVersionUID = -2182006191391350339L;

    private ErrorCode errorCode;
    private List<ErrorCode> errorList;

    public AppException(ErrorCode errorCode) {
    	this.errorCode = errorCode;
    }

    public AppException(List<ErrorCode> errorList) {
      this.errorList = errorList;
  }

    public AppException(ErrorCode errorCode, Exception cause) {
    	super(cause.getMessage(), cause);
    	errorList = new ArrayList<>();
    	errorList.add(errorCode);
    }
}
