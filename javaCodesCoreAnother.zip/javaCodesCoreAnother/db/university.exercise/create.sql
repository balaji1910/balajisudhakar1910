CREATE TABLE edu_university(
									univ_code CHAR(4) PRIMARY KEY
									, university_name VARCHAR(100) NOT NULL
									);

CREATE TABLE edu_department(
									  dept_code CHAR(4) PRIMARY KEY
									  , dept_name VARCHAR(50) NOT NULL
									  , univ_code CHAR(4)
									  , CONSTRAINT fk_department_university FOREIGN KEY(univ_code) 
									  	 REFERENCES edu_university(univ_code)
									);
CREATE TABLE edu_college(
								id INT PRIMARY KEY
								, code CHAR(4) NOT NULL
								, name VARCHAR(100) NOT NULL
								, univ_code CHAR(4)
								, CONSTRAINT fk_college_university FOREIGN KEY(univ_code)
								  REFERENCES edu_university(univ_code)
								, city VARCHAR(50) NOT NULL
								, state VARCHAR(50) NOT NULL
								, year_opened year(4) NOT NULL
								);
CREATE TABLE edu_college_department(
											  cdept_id INT PRIMARY KEY
											  , udept_code CHAR(4)
											  , college_id INT 
											  , CONSTRAINT fk_college_department_college FOREIGN KEY (college_id)
											  REFERENCES edu_college (id)
											  , CONSTRAINT fk__college_department_department FOREIGN KEY (udept_code)
											    REFERENCES edu_department (dept_code)
											  );
CREATE TABLE edu_designation(
									 id INT PRIMARY KEY AUTO_INCREMENT
									 , name VARCHAR(20) NOT NULL
									 , rank CHAR(1) NOT NULL
									 );

CREATE TABLE edu_employee (
								 id INT PRIMARY KEY
								 , name VARCHAR(100) NOT NULL
								 , dob DATE NOT NULL
								 , email VARCHAR(50) UNIQUE NOT NULL
								 , phone BIGINT NOT NULL
								 , college_id INT
								 , CONSTRAINT fk_employee_college FOREIGN KEY(college_id)
								   REFERENCES edu_college (id)
								 , cdept_id INT
								 , desig_id INT
								 , CONSTRAINT fk_employee_college_department FOREIGN KEY(cdept_id)
								   REFERENCES edu_college_department (cdept_id)
								 , CONSTRAINT fk_employee_designation FOREIGN KEY(desig_id)
								   REFERENCES edu_designation (id)
								 );
CREATE TABLE edu_syllabus(
								 id INT PRIMARY KEY
								 , cdept_id INT
								 , syllabus_code CHAR(4) NOT NULL
								 , syllabus_name VARCHAR(100) NOT NULL
								 , CONSTRAINT fk_syllabus_college_department FOREIGN KEY (cdept_id)
								   REFERENCES edu_college_department(cdept_id)
								 );
CREATE TABLE edu_professor_syllabus(
												emp_id INT 
											   , CONSTRAINT fk_professor_syllabus_employee FOREIGN KEY (emp_id) 
												REFERENCES edu_employee (id)
											   ,	syllabus_id INT
											   , CONSTRAINT fk_professor_syllabus_syllabus FOREIGN KEY(syllabus_id)
											     REFERENCES edu_syllabus (id)
											   , semester TINYINT NOT NULL
												);
CREATE TABLE edu_student(
							   id INT PRIMARY KEY AUTO_INCREMENT
							   , roll_number CHAR(100) NOT NULL
							   , name VARCHAR(100) NOT NULL
							   , dob DATE NOT NULL
							   , gender CHAR(1) NOT NULL
							   , email VARCHAR(50) NOT NULL
							   , phone BIGINT NOT NULL
							   , address VARCHAR(200) NOT NULL
							   , academic_year YEAR(4) NOT NULL
							   , cdept_id INT
							   , college_id INT
							   , CONSTRAINT fk_student_college_department FOREIGN KEY (cdept_id)
							     REFERENCES edu_college_department (cdept_id)
							   , CONSTRAINT fk_student_college FOREIGN KEY(college_id)
							     REFERENCES edu_college (id)
							   );
CREATE TABLE edu_semester_fee(
										cdept_id INT 
										, stud_id INT
										, semester TINYINT
										, amount DOUBLE(18,2) NULL
										, paid YEAR NULL
										, paid_status VARCHAR(10) NOT NULL
										, CONSTRAINT fk_semester_fee_college_department FOREIGN KEY(cdept_id)
										REFERENCES edu_college_department (cdept_id)
										, CONSTRAINT fk_semester_fee_student FOREIGN KEY(stud_id)
										REFERENCES edu_student (id)
										);
CREATE TABLE edu_semester_result(
											stud_id INT
											, syllabus_id INT
											, semester TINYINT NOT NULL
											, grade VARCHAR(2) NOT NULL
											, credit FLOAT NOT NULL
											, result_date DATE NOT NULL
											, CONSTRAINT fk_semester_result_student FOREIGN KEY (stud_id)
											REFERENCES edu_student(id)
											, CONSTRAINT fk_semester_result_syllabus FOREIGN KEY(syllabus_id)
											REFERENCES edu_syllabus(id)
											);
											