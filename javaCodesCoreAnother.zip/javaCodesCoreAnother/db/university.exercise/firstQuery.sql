SELECT code
		, col.name
		, university_name
		,city
		,state
		, year_opened
		, dept_name
		, emp.name AS Hod_name
		, desig.name AS designation
FROM edu_college AS col
INNER JOIN edu_university AS uni ON uni.univ_code=col.univ_code
INNER JOIN edu_college_department AS colldep ON colldep.college_id=col.id
INNER JOIN edu_department AS dept ON dept.dept_code=colldep.udept_code
INNER JOIN edu_employee AS emp ON emp.cdept_id=colldep.cdept_id
INNER JOIN edu_designation AS desig ON desig.id=emp.desig_id 
WHERE desig.name='Head of the department' AND dept_name IN ('Computer Science Engineering','Information Technology');