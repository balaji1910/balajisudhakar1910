UPDATE edu_semester_fee SET paid_status='PAID', paid_year=2017
WHERE stud_id = (Select id FROM edu_student
					WHERE roll_number ='gkit01');



UPDATE edu_semester_fee SET paid_status='PAID', paid_year=2016
WHERE stud_id IN (Select id FROM edu_student
					WHERE roll_number IN ('aucs01','aucs04','auit04','auit02','auit01','aucs02'));
					
					

UPDATE edu_semester_fee SET paid_status='PAID', paid_year=2017
WHERE stud_id =30;
