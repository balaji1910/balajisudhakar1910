	 
SELECT roll_number
 		, stu.name AS Student_name
 		, gender
 		, stu.dob
 		, stu.email
 		, stu.phone
 		, col.city
 		, col.name AS College_name
 		, dept.dept_name AS department_name
 		, des.name AS designation_name
 		, emp.name
 		FROM edu_student AS stu
 		INNER JOIN edu_college AS col ON col.id=stu.college_id
  		INNER JOIN edu_college_department AS ecd ON ecd.cdept_id=stu.cdept_id
 		INNER JOIN edu_department AS dept ON dept.dept_code=ecd.udept_code
 		INNER JOIN edu_employee AS emp ON emp.cdept_id=ecd.cdept_id
 		INNER JOIN edu_designation AS des ON des.id=emp.desig_id
	 WHERE  des.name='Head of the department'   AND col.univ_code='AU';