SELECT roll_number
 		, stu.name AS 
 		, gender 
 		, dob
 		, email
 		, phone
 		, col.city
 		, col.name
 	 FROM edu_student AS stu
 	 INNER JOIN edu_college AS col ON col.id=stu.college_id
	 WHERE  col.city='Chennai' 
	 AND stu.academic_year=2014 
	 AND col.univ_code='UA';
 	 