SELECT emp.id, emp.name,emp.dob,emp.email,emp.phone AS Phone,edc.name AS College_name,des.rank AS Rank, des.name AS designation_name, dept.dept_name
FROM edu_employee AS emp
INNER JOIN edu_designation AS des ON des.id=emp.desig_id
INNER JOIN edu_college AS edc ON edc.id=emp.college_id 
INNER JOIN edu_college_department AS ecd ON ecd.cdept_id=emp.cdept_id
INNER JOIN edu_department AS dept ON dept.dept_code=ecd.udept_code
GROUP BY  des.rank, edc.name; 
