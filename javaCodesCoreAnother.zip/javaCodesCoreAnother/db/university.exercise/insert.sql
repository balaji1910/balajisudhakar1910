INSERT INTO edu_university(univ_code, university_name) 
VALUES('AU', 'Anna University')
	 , ('UA','University of Andhra')
	 , ('KU','Kerala University');
	 
INSERT INTO edu_department (dept_code, dept_name, univ_code) 
VALUES('AUCE','Civil Engineering','AU')
		, ('AUEE','Electrical and Electronics Engineering','AU')
		, ('AUCS','Computer Science Engineering','AU')
		, ('AUIT','Information Technology','AU')
		, ('AUBT','Biotechnology','AU')
		, ('KUCS','Computer Science Engineering','KU')
		, ('KUIT','Information Technology','KU')
		, ('KUEC','Electronics and Communication engineering','KU')
		, ('KUME','Mechanical Engineering','KU')
		, ('KUPE','Polymer Engineering','KU')
		, ('UACS','Computer Science Engineering','UA')
		, ('UAIT','Information Technology', 'UA')
		, ('UAME','Mechanical Engineering','UA')
		, ('UACE','Civil Engineering','UA')
		, ('UAAE','Automobile Engineering','UA');

INSERT INTO edu_college(id,code,name,univ_code,city,state,year_opened)
VALUES  (1,'AUCE','Anna University College of Engineering','AU','Chennai','Tamil Nadu',1978)
		, (2,'PSG','PSG College of Technology','AU','Coimbatore','Tamil Nadu',1951)
		, (3,'SSN','Sri Sivasubramaniya Nadar College of Engineering','AU','Coimbatore','Tamil Nadu',1996)
		, (4,'KLU','K L University','UA','Vijayawada','Andhra Pradesh',1970)
		, (5,'AUC','Andhra University of Engineering','UA','Vishakapatnam','Andhra Pradesh',1960)
		, (6,'GCK','Government College','KU','Kariavattom','Kerala',1997)
		, (7,'GCA','Government College','KU','Attingal','Kerala',1975); 
		
INSERT INTO edu_college_department (cdept_id,udept_code,college_id)
VALUES  (101,'AUCE',1)
		, (102,'AUCS',1)
		, (103,'AUIT',1)
		, (201,'AUEE',2)
		, (202,'AUCS',2)
		, (203,'AUIT',2)
		, (301,'AUCS',3)
		, (302,'AUIT',3)
		, (401,'UAIT',4)
		, (402,'UAME',4)
		, (501,'UAIT',5)
		, (502,'UAAE',5)		
		, (601,'KUIT',6)
		, (602,'KUEC',6)
		, (701,'KUCS',7)
		, (702,'KUIT',7);

INSERT INTO edu_designation(id, name, rank) VALUES (1,'Principal','A')
																 , (2,'Head of the Department','B')
																 , (3,'Professor','C')
																 , (4,'Assistant Professor','D');
																 ,	(5,'Lab Assistant','E');

INSERT INTO edu_employee (id, name, dob, email, phone, college_id, cdept_id, desig_id)
VALUES 

		, (10,'kamaraj',19600616,'kamaraj1960@gmail.com',9865321980,1,101,1)
		, (11,'velraj',19610618,'velraj1961@gmail.com',9865322,1,101,2)
		, (12,'anandhi',19630622,'ram@gmail.com',9865323,1,101,3)
		, (13,'vishnu',19630424,'vishnu@gmail.com',9865324,1,101,4)
		, (14,'Banhi',19630624,'banhi@gmail.com',9865320,1,102,2)
		, (15,'yashika',19630628,'vijay@gmail.com',9865325,1,102,3)
		, (16,'ajith',19630629,'ajith@gmail.com',9865326,1,102,4)
		, (17,'vignesh',19630630,'vignesh@gmail.com',9865327,1,103,2)
		, (18,'karthi',19630621,'karthi@gmail.com',9865328,1,103,3)		
		, (19,'shalini',19630601,'tamil@gmail.com',98653289,1,103,4)
      
		, (21,'vetri',19640603,'vetri@gmail.com',9876541,2,201,2)
		, (22,'anbu',19640604,'anbu@gmail.com',9876542,2,201,3)
		, (23,'Nivetha',19640605,'balaji@gmail.com',9876543,2,201,4)
		, (24,'hemanth',19640606,'hemanth@gmail.com',9876544,2,202,2)
		, (25,'gowtham',19640607,'gowtham@gmail.com',9876545,2,202,3)
		, (26,'madhumitha',19640608,'yuvaraj@gmail.com',9876546,2,202,4)
		, (27,'millan',19640609,'millan@gmail.com',9876547,2,203,2)
		, (28,'ayyapan',19640610,'ayyapan@gmail.com',9876548,2,203,3)
		, (20,'jaya',19640611,'jaya@gmail.com',9876549,2,203,4)
		
		
		, (31,'siva',19640612,'siva@gmail.com',9876551,3,301,1)
		, (32,'jayanthi',19640613,'jayanthi@gmail.com',9876552,3,301,2)
		, (33,'sriram',19640614,'sriram@gmail.com',9876553,3,301,3)
		, (34,'manjula',19640615,'manjula@gmail.com',9876554,3,301,4)
		, (35,'arivu',19640616,'arivu@gmail.com',9876555,3,302,2)
		, (36,'bala',19640617,'bala@gmail.com',9876556,3,302,3)
		, (37,'kathir',19640617,'kathir@gmail.com',9876557,3,302,4)
		
 
		
		, (40,'seetha',19640619,'seetha@gmail.com',978960,4,401,1)
		, (41,'eswar',19640620,'eswar@gmail.com',9789601,4,401,2)
		, (42,'madhan',19640621,'madhan@gmail.com',9789602,4,401,3)
		, (43,'anjali',19640622,'anjali@gmail.com',9789603,4,401,4)
		, (44,'raman',19640623,'raman@gmail.com',9789604,4,402,2)
		, (45,'lakshman',19640624,'lakshman@gmail.com',9789605,4,402,3)
		, (46,'kamban',19640625,'kamban@gmail.com',9789606,4,402,4)
 		
		
		, (51,'akash',19640626,'akash@gmail.com',978961,5,501,1)
		, (52,'karteek',19640627,'karteek@gmail.com',978962,5,501,2)
		, (53,'viji',19640628,'viji@gmail.com',978963,5,501,3)
		, (54,'rama',19640629,'ramz@gmail.com',978964,5,501,4)
		, (55,'sri',19640630,'sri@gmail.com',978965,5,502,2)
		, (56,'reddy',19640701,'reddy@gmail.com',978966,5,502,3)
		, (57,'arjun',19640702,'arjun@gmail.com',978967,5,502,4)
		
		
		, (60,'vijaya',19640802,'vijaya@gmail.com',97896001,6,601,1)
		, (61,'ajitha',19640803,'ajitha@gmail.com',97896002,6,601,2)
		, (62,'keerthana',19640804,'keerthana@gmail.com',978960003,6,601,3)
		, (63,'manish',19640805,'manish@gmail.com',978960004,6,601,4)
		, (64,'hari',19640806,'hari@gmail.com',978960005,6,602,2)
		, (65,'naveen',19640807,'naveen@gmail.com',978960006,6,602,3)
		, (66,'raj',19640808,'raj@gmail.com',978960007,6,602,4)
		
		
		, (70,'vikram',19640819,'vikram@gmail.com',978960790,7,701,1)
		, (71,'karan',19640820,'karan@gmail.com',978960791,7,701,2)
		, (72,'mani',19640821,'mani@gmail.com',978960792,7,701,3)
		, (73,'aravi',19640822,'aravi@gmail.com',978960793,7,701,4)
		, (74,'deva',19640823,'deva@gmail.com',978960794,7,701,2)
		, (75,'gokul',19640824,'gokul@gmail.com',978960795,7,701,3)
		, (76,'krishna',19640825,'krishna@gmail.com',978960796,7,701,4)
		
		, (77,'kathir',19600526,'kathi@gmail.com',9944621157,1)
		, (78,'karteek',19700625,'io@gmail.com',9944615723,1)
		, (79,'priya',19700624,'priya@gmail.com',9944615733,1)

		, (80,'vikram',19750602,'vikra@gmail.com',9924615723,2)
		, (81,'Vinoth',19740607,'vinotih@gmail.com',9944651157,2)
		, (82,'alpha',19700825,'alpha@gmail.com',9948615723,2)
	
	
		, (83,'ronal',19850227,'ronal@gmail.com',9944815723,3,301,4)
		, (84,'inista',19790825,'iniseta@gmail.com',9944685723,3,302,4);

INSERT INTO edu_syllabus(id,cdept_id, syllabus_code, syllabus_name) 
VALUES (1, 101,1000,'Engineering Graphics')
	  , (2, 101,1001,'Mechanics of Fluids')
	  , (3, 101,1002, 'Soil Strengths')
	  
	  , (4,102,1003 , 'Operating systems')
	  , (5,102, 1004, 'Java Programming')
	  , (6,102, 1005, 'Data Structures')
	  
	  , (7, 103, 1005,'Cloud Computing')
	  , (8, 103, 1006,'Information Management')
	  , (9, 103, 1007,'Python')
	  
	  , (10, 201 ,1008, 'Measurements and Instrumentation' )
	  , (11, 201,1009, 'Power Electronics')
	  , (12,201,1010,'High Voltage Engineering')
	
	  , (13,202,1003,'Operating systems')
	  , (14,202, 1004,'Java Programming')
	  , (15,202, 1005, 'Data Structures')
	  
	  , (16, 203, 1005,'Cloud Computing')
	  , (17, 203, 1011,'Python')
	  , (18, 203,1012,'Database')
	  
	  , (19,301, 1003 , 'Operating systems')
	  , (20,301, 1004, 'Java Programming')
	  , (21,301, 1005, 'Data Structures')
	  
	  , (22, 302, 1005,'Cloud Computing')
	  , (23, 302, 1011,'Python')
	  , (24, 302,1012,'Database')
	  
	  , (25, 401, 1013, 'Cloud Computing')
	  , (26,401,1014, 'Operating System')
	  , (27,401,1015, 'File Structures')
	  
	  , (28,402,1016,'Engineering Mechanics')
	  , (29,402,1017,'Fluid Mechanics')
	  , (30, 402,1018, 'Machine Theory')
	  
	  , (31, 501, 1013, 'Cloud Computing')
	  , (32,501,1014, 'Operating system')
	  , (33,501,1015, 'File Structures')
	  
	  , (34,502,1019, 'Design of machines')
	  , (35,502,1020,'Heat Transfer')
	  , (36,502,1021,'Automotive Engines')
	  
	  
	  , (37,601, 1022, 'Cloud Computing')
	  , (38,601,1023, 'Operating System')
	  , (39,601,1024,'Computer Networks')
	  
	  , (40,602,1025,'Analog Communication')
	  , (41,602,1026,'Digital Signal Processing')
	  , (42,602, 1027,'Embedded Systems')
	  
	  , (43,701, 1022, 'Cloud Computing')
	  , (44,701,1023, 'Operating System')
	  , (45,701,1024,'Computer Networks')
	  
	  , (46,702,1029,'Operating systems')
	  , (47,702,1030,'Java Programming')
	  , (48,702, 1031,'Data Structures')
	  
	  
     , (49,101,1090,'Mathematics-I') 
	  , (50,102,1091,'Engineering Physics-I')
	  , (51,103,1092,'Database Management')
	  
	  , (52,201,1093,'Mathematics II');

INSERT INTO edu_professor_syllabus (emp_id,syllabus_id,semester)
VALUES (11,1,2)
		, (12,2,3)
		, (13,3,4)
		
		, (14,4,2)
		, (15,5,4)
		, (16,6,7)
		
		, (17,7,3)
		, (18,8,6)
		, (19,9,7)
		
		, (21,10,5)
		, (22,11,4)
		, (23,12,6)
		
		, (24,13,4)
		, (25,14,3)
		, (26,15,5)
		
		, (27,16,3)
		, (28,17,4)
		, (20,18,5)
		
		, (31,19,5)
		, (32,20,4)
		, (33,21,3)
		
		, (34, 22,3)
		, (35, 23,4)
		, (36, 24,6)
		
		, (41, 25 ,6)
		, (42, 26,4)
		, (43, 27,3)
		
		
	   , (44,28,5)
	   , (45,29,3)
	   , (46,30,2)
	   
	   , (52,31,5)
	   , (53,32,4)
	   , (54,33,2)
	   
	   , (55,34,4)
	   , (56,35,3)
	   , (57,36,2)
	   
	   , (61,37,6)
	   , (62,38,5)
	   , (63,39,4)
	   
	   , (64,40, 5)
	   , (65,41,3)
	   , (66,42,2)
	   
	   , (71,43,5)
	   , (72,44,4)
	   , (73,45,3)
	   
	   , (74,46,6)
	   , (75,47,4)
	   , (76,48,3);

INSERT INTO edu_student (roll_number,name,dob,gender,email,phone,address,academic_year,cdept_id,college_id)
VALUES 

			('auce01','Akshaya',19961125,'F','akshaya@gmail.com',9789607902,'12 braman Street salem-636008',2014,101,1)
			,('auce02','Anandh',19971021,'M','anandh@gmail.com',9689231478,'2 raman Street salem-636003',2015,101,1)
			,('auce03','Anitha',19980405,'F','anitha@gmail.com',9847216354,'9 ameen Street salem-636001',2016,101,1)
			,('auce04','Balaji',19990102,'M','balaji@gmail.com',9032165478,'11 veeran Street salem-636006',2017,101,1)
						
			,('aucs01','Anjali',19961026,'F','anjali@gmail.com',9856231471,'10 Paruthipalli Road karur-15',2014,102,1)
			,('aucs02','Anitha',19971024,'F','anitha@gmail.com',9846231471,'11 Paruthipalli Road erode-14',2015,102,1)
			,('aucs03','balaguru',19981023,'M','balaguru@gmail.com',9656231471,'13 kamban Road erode',2016,102,1)
			,('aucs04','Karthi',19991026,'M','karthi@gmail.com',9853231471,'10 kannan Road hosur-13',2017,102,1)
			
			,('auit01','Anu',19961006,'F','anu@gmail.com',9856231470,'10 Anu street salem-15',2014,103,1)
			,('auit02','Kaviya',19971026,'F','kaviya@gmail.com',9856231481,'11 vallalar nagar salem-15',2015,103,1)
			,('auit03','anbu',19981104,'M','anbu@gmail.com',9856261471,'bye pass main Road salem-15',2016,103,1)
			,('auit04','deva',19991021,'M','deva@gmail.com',9856271471,'kannan street salem-15',2014,102,1)
			
				
			
			,('psee01','hemanth',19961001,'M','hemanth@gmail.com',7856271471,'hema street ooty-15',2014,201,2)
			,('psee02','jaba',19971002,'M','jaba@gmail.com',8956271471,'ambedkar street Namakkal-11',2015,201,2)
			,('psee03','naveen',19981003,'M','naveen@gmail.com',8056271471,'gandhi street bangalore-12',2016,201,2)
			,('pse04','Raja',19991004,'M','raja@gmail.com',8956271481,'nehru street erode-15',2017,201,2)
			
			,('pscs01','millan',19960601,'M','deva@gmail.com',9856271871,'gowtham street Namakkal-15',2014,202,2)
			,('pscs02','karthi',19970611,'M','deva@gmail.com',9856271771,'millan street chennai-15',2015,202,2)
			,('pscs03','raja',19980113,'M','deva@gmail.com',9856271671,'udha street nellore-15',2016,202,2)
			,('pscs04','vaishnu',19990602,'M','deva@gmail.com',9856271571,'ronaldo street vellore-15',2017,202,2)
			
			,('psit01','jayanth',19960605,'M','jayanth@gmail.com',9856271871,'sai street Coimbatore-15',2014,203,2)
			,('psit02','navin',19970608,'M','navin@gmail.com',9856371871,'baba street Ariyalur-15',2015,203,2)
			,('psit03','prakash',19980609,'M','prakash@gmail.com',9856471871,'Thendral street Dharmapuri-15',2016,203,2)
			,('psit04','jaya',19990618,'M','jaya@gmail.com',9856571871,'thamarai street chennai-15',2017,203,2)
			
			
			,('sscs01','praveen',19960518,'M','praveen@gmail.com',9856571871,'thamarai street madurai-15',2014,301,3)
			,('sscs02','viswa',19970418,'M','viswa@gmail.com',9856571872,'baba street Namakkal-15',2015,301,3)
			,('sscs03','barath',19980318,'M','barath@gmail.com',9856571873,'then street Karur-15',2016,301,3)
			,('sscs04','arun',19990218,'M','arun@gmail.com',9856571874,'baby street Kanniyakumari-15',2017,301,3)
			
			,('ssit01','gayathri',19960618,'M','gayathri@gmail.com',9856571871,'thamarai street krishnakiri-15',2014,302,3)
			,('ssit02','pradeepa',19970618,'M','pradeepa@gmail.com',985657161,'malar street Nilgiris-15',2015,302,3)
			,('ssit03','deepa',19980618,'M','deepa@gmail.com',9856575871,'iniya street pudhukottai-15',2016,302,3)
			,('ssit04','dhivya',19990618,'M','dhivya@gmail.com',9856471871,'nalan street ramanathapuram-15',2017,302,3)
			
			
			,('klit01','shahul',19960611,'M','shahul@gmail.com',9856571871,'kanna street Annatapur-15',2014,401,4)
			,('klit02','kashyap',19970417,'M','kashap@gmail.com',9856571871,'leela street chittor-15',2015,401,4)
			,('klit03','Lokesh',19980319,'M','lokesh@gmail.com',9856571871,'mari street guntur-15',2016,401,4)
			,('klit04','ragul',19990420,'M','ragul@gmail.com',9856571871,'bharathi street kurnool-15',2017,401,4)
			
			,('klme01','gokul',19990420,'M','gokul@gmail.com',9856371871,'fathima street Nellore-15',2014,402,4)
			,('klme02','pullela',19970415,'M','pullela@gmail.com',7856571871,'vicki street srikakulam-15',2015,402,4)
			,('klme03','karteek',19980916,'M','karteek@gmail.com',9556571871,'pullela street krishnakiri-15',2016,402,4)
			,('klme04','Sri',19990117,'M','Sri@gmail.com',9896571871,'thamarai st thomas west godavari-15',2017,402,4)
			
			,('acit01','krish',19960117,'M','krish@gmail.com',6896571871,'govindha st thomas west Annatapur-15',2014,501,5)
			,('acit02','prassana',19970117,'M','prassana@gmail.com',7896571871,'hanuman st thomas west godavari-15',2015,501,5)
			,('acit03','Aravind',19980117,'M','aravind@gmail.com',8896571871,'lakshman st thomas west guntur-15',2016,501,5)
			,('acit04','Ishwarya',19990117,'F','ishwarya@gmail.com',8196571871,'bramna st thomas west kurnol-15',2017,501,5)
			
			,('acae01','rekha',19961117,'F','rekha@gmail.com',9196571871,'iniya st thomas west srikakulam-15',2014,502,5)
			,('acae02','edward',19971007,'M','edward@gmail.com',9296571871,'malar st thomas west nellore-15',2015,502,5)
			,('acae03','nagraja',19981003,'M','nagaraj@gmail.com',9396571871,'pullela st thomas west chittor-15',2016,502,5)
			,('acae04','natraj',19991009,'M','natraj@gmail.com',9496571871,'vikram st thomas west godavari-15',2017,502,5)

			,('gkit01','sai ',19960117,'F','sai@gmail.com',9296571871,'sai st thomas west idukki-15',2014,601,6)
			,('gkit02','mamuti',19971107,'M','mamuti@gmail.com',9396571871,'baba st thomas west kollam-15',2015,601,6)
			,('gkit03','pallavi',19981117,'F','pallavi@gmail.com',9496571871,'aluva st thomas west kottayam-15',2016,601,6)
			,('gkit04','rekha',19991117,'F','rekha@gmail.com',9696571871,'mayil st thomas west mallapuram-15',2017,601,6)	
			
			,('gkec01','gokul',19990420,'M','gokul@gmail.com',9956371871,'fathima street kottayam-15',2014,602,6)
			,('gkec02','pullela',19970415,'M','pullela@gmail.com',8856571871,'vicki street kollam-15',2015,602,6)	
			,('gkec03','Anjali',19961026,'F','anjali@gmail.com',9856231471,'10 Paruthipalli Road karur-15',2016,602,6)
			,('gkec04','Anitha',19971024,'F','anitha@gmail.com',9846231471,'11 Paruthipalli Road erode-14',2017,602,6)		
			
			,('gacs01','Anu',19961006,'F','anu@gmail.com',9856231470,'10 Anu street salem-15',2014,701,7)
			,('gacs02','edward',19971007,'M','edward@gmail.com',9296571871,'malar st thomas west kollam-15',2015,701,7)
			,('gacs03', 'Ulka',19980101,'F','ulka@gmail.com',9879607907,'kollam main road ',2016,701,7)
			,('gacs04', 'Uma',19990101,'F','uma@gmail.com',9879607906,'mallapuram main road ',2017,701,7)
			
			,('gait01','Alaka',19961006,'F','alka@gmail.com',9856231478,'10 alaka street kollam-15',2014,702,7)
			,('gait02','kanv',19970908,'F','kanv@gmail.com',9856231476,' brama street mallapuram-15',2015,702,7)
			,('gait03','lalu',19980501,'F','lalu@gmail.com',9856231475,'10 amen street idukki-15',2016,702,7)
			,('gait04','som',19990302,'F','som@gmail.com',9856231474,'10 Ant street coimbatore-15',2017,702,7);
			
INSERT INTO edu_semester_fee (cdept_id,stud_id,semester,amount,paid_status) 
							  VALUES(101,1,7,50000,'UNPAID')
							  		 , (102,5,7,50000,'PAID')
							  		 , (103,9,7,50000,'UNPAID')
							  		 , (102,12,7,50000,'PAID')
							  		 , (201,13,7,50000,'UNPAID')
							  		 , (202,17,7,50000,'PAID')
							  		 , (203,21,7,50000,'UNPAID')
							  		 , (301,25,7,50000,'PAID')
							  		 , (302,29,7,50000,'UNPAID')
							  		 
							  		 
							  		 , (101,2,5,40000,'UNPAID')
							  		 , (102,6,5,40000,'UNPAID')
							  		 , (103,10,5,40000,'PAID')
							  		 , (201,14,5,40000,'UNPAID')
							  		 , (202,18,5,40000,'UNPAID')
							  		 , (203,22,5,40000,'PAID')
							  		 , (301,26,5,40000,'UNPAID')
							  		 , (302,30,5,40000,'PAID')
							  		 
							  		 
							  		 , (101,3,3,40000,'PAID')
							  		 , (102,7,3,40000,'PAID')
							  		 , (103,11,3,40000,'PAID')
							  		 , (201,15,3,40000,'UNPAID')
							  		 , (202,19,3,40000,'UNPAID')
							  		 , (203,23,3,40000,'PAID')
							  		 , (301,27,3,40000,'PAID')
							  		 , (302,31,3,40000,'PAID')
							  		 
							  		 
  							  		 , (101,4,1,10000,'PAID')
							  		 , (102,8,1,10000,'UNPAID')
							  		 , (103,16,1,10000,'UNPAID')
							  		 , (201,20,1,10000,'PAID')
							  		 , (202,24,1,10000,'UNPAID')
							  		 , (203,28,1,10000,'PAID')
							  		 , (301,32,1,10000,'UNPAID');
							  		 
INSERT INTO edu_semester_result(stud_id,syllabus_id, semester,grade, credit, result_date)
VALUES (1,1,2,'A',8.56,20150425)	
		, (1,2,3,'B',8.36,20160425)
		, (1,3,4,'C',7.23,20161225)
		, (5,5,4,'B',8.26,20160425)
		, (9,7,3,'A',8.460,20151228)
		, (12,4,2,'A',8.96,20150425)
		, (13,11,4,'C',7.020,20160425) 
		, (21,16,3,'B',8.003,20151228)
		, (25,21,3,'A',8.508,20151228)
		, (29,24,6,'S',9.6032,20170427);
