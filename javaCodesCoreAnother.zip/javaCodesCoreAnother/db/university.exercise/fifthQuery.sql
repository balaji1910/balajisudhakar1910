SELECT stu.id
		, roll_number
		, stu.name
		, stu.dob
		, stu.email
		, stu.phone
		, stu.address
		, stu.academic_year
		, grade
		, credit
		, semester
	FROM edu_student AS stu
	INNER JOIN edu_semester_result AS semres
		ON semres.stud_id=stu.id
	INNER JOIN edu_college AS col
	ON col.id=stu.college_id
	WHERE col.name='Anna University college of engineering' AND semres.semester=3;
	