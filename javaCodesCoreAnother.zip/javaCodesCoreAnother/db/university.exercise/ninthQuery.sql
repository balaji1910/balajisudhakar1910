SELECT SUM(amount) AS collected_fees, paid_status, col.name AS college_name , univ.university_name
,semfee.semester AS Semester
FROM edu_semester_fee AS semfee
INNER JOIN edu_college_department AS coldep
ON coldep.cdept_id=semfee.cdept_id
INNER JOIN edu_college AS col
ON col.id=coldep.college_id
INNER JOIN edu_university AS univ 
ON univ.univ_code=col.univ_code
WHERE paid_status='PAID'

UNION

SELECT SUM(amount) AS uncollected_fees, paid_status, col.name AS college_name , univ.university_name
,semfee.semester AS Semester
FROM edu_semester_fee AS semfee
INNER JOIN edu_college_department AS coldep
ON coldep.cdept_id=semfee.cdept_id
INNER JOIN edu_college AS col
ON col.id=coldep.college_id
INNER JOIN edu_university AS univ 
ON univ.univ_code=col.univ_code
WHERE paid_status='UNPAID' AND univ.univ_code='AU' AND col.code='PSG';

SELECT SUM(amount) AS collected_fees, col.name AS college_name , univ.university_name
,semfee.semester AS Semester
FROM edu_semester_fee AS semfee
INNER JOIN edu_college_department AS coldep
ON coldep.cdept_id=semfee.cdept_id
INNER JOIN edu_college AS col
ON col.id=coldep.college_id
INNER JOIN edu_university AS univ 
ON univ.univ_code=col.univ_code
WHERE univ.univ_code IN('AU','UA') AND paid_year=2016;
