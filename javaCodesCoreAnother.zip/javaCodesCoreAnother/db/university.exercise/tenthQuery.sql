SELECT id, roll_number, name, dob, gender, academic_year,syllabus_id, grade,credit
FROM edu_student AS stu
INNER JOIN edu_semester_result AS semres 
ON semres.stud_id=stu.id
WHERE credit>8 AND semester=3;

SELECT id, roll_number, name, dob, gender, academic_year,syllabus_id, grade,credit
FROM edu_student AS stu
INNER JOIN edu_semester_result AS semres 
ON semres.stud_id=stu.id
WHERE credit>5 AND semester=3;
