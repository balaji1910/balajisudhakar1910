SELECT  des.name
		, emp.name
		, col.name
		, univ.university_name
FROM edu_syllabus AS syl
LEFT JOIN edu_professor_syllabus AS profsyl
ON profsyl.syllabus_id=syl.id
LEFT JOIN edu_employee AS emp
ON emp.id=profsyl.emp_id
RIGHT JOIN edu_designation AS des
ON des.id=emp.desig_id
LEFT JOIN edu_college As col
ON col.id=emp.college_id
LEFT JOIN edu_college_department AS coldep
ON coldep.cdept_id=emp.cdept_id
LEFT JOIN edu_department AS dep
ON dep.dept_code=coldep.udept_code
LEFT JOIN edu_university AS univ
ON univ.univ_code=col.univ_code
