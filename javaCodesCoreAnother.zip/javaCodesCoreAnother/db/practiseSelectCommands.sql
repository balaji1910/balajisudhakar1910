SELECT  player
		, age 
	   , (SELECT country FROM trn_nation 
			WHERE country = "spain") 
AS Country 
FROM trn_football_players 
WHERE ranking=4;
 
SELECT * FROM trn_football_players 
WHERE nation_id= (
					SELECT nation_id FROM trn_nation 
					WHERE country=);
 



SELECT * from trn_football_players 
	GROUP BY age;

SELECT * FROM trn_football_players 
	ORDER BY player ASC;

SELECT player, age, ranking 
from football_players 
ORDER BY player DESC;




SELECT * FROM trn_nation as n 
RIGHT JOIN trn_football_players as f 
ON n.nation_id=f.nation_id;

SELECT * FROM trn_nation as n 
LEFT JOIN trn_football_players as f 
ON n.nation_id=f.nation_id;

SELECT nation_id,country FROM trn_nation
UNION DISTINCT SELECT player,age 
FROM trn_football_players;

SELECT * FROM trn_nation CROSS JOIN trn_football_players;

SELECT * FROM trn_nation INNER JOIN trn_football_players;

SELECT * FROM trn_football_players 
WHERE club_id=(
SELECT club_id FROM trn_club 
WHERE clubname="juventus") 
AND nation_id=(
SELECT nation_id FROM trn_nation 
WHERE country="portugal");

SELECT * FROM trn_football_players 
WHERE player 
LIKE "%si";

SELECT * FROM trn_football_players 
WHERE nation_id 
IN (1,2,3);

SELECT max(age) AS max_age,player 
FROM trn_football_players;

CREATE INDEX indi ON trn_football_players(player, goals);


SELECT SUM(age) FROM trn_football_players;

SELECT player, age FROM trn_football_players GROUP BY player HAVING MAX(age)>30;



SELECT * FROM trn_football_players 
WHERE nation_id= (SELECT trn_nation.nation_id FROM trn_nation 
						WHERE country="france");
						


SELECT player, country, age FROM trn_nation
RIGHT JOIN trn_football_players
ON trn_nation.nation_id=trn_football_players.nation_id;


SELECT *
FROM  trn_nation
RIGHT JOIN trn_football_players
ON trn_football_players.nation_id=trn_nation.nation_id;

CREATE INDEX footy On trn_football_players (player,ranking,nation_id);


SELECT DISTINCT age FROM trn_football_players;

SELECT COUNT(nation_id) FROM trn_football_players;

SELECT * FROM trn_football_players 
GROUP BY player
HAVING COUNT(trn_football_players.nation_id) > 1;


	 







/*TRUNCATE trn_football_players;*/




      /*CREATING VIEW:*/