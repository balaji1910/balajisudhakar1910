SELECT ranking, player, age,nation_id, club_id, role_id 
	FROM trn_football_players;
	
SELECT role_id, role_name FROM trn_role;

SELECT club_id, clubname FROM trn_club;

SELECT nation_id, country FROM trn_nation;

SELECT player, age,(SELECT country FROM trn_nation 
						  WHERE nation_id) AS Country 
						,(SELECT clubname FROM trn_club 
						  WHERE club_id=2) AS Club
						,(SELECT role_name FROM trn_role 
						  WHERE role_id=2) AS Role
FROM trn_football_players WHERE ranking=4;

SELECT player,age,nation_id 
FROM trn_football_players 
WHERE nation_id= (SELECT nation_id 
						FROM trn_nation 
						WHERE country="spain");
						
SELECT ranking, player, age,nation_id, club_id, role_id  
FROM trn_football_players 
WHERE role_id
IN ( SELECT role_id FROM trn_football_players 
	 GROUP BY role_id
	 HAVING COUNT(role_id) >1);
	 
SELECT player, age,COUNT(role_id)>3 AS cnt 
FROM trn_football_players;  	 

SELECT player,IF (age>20,"YES", "NO") AS true_or_false FROM trn_football_players WHERE ranking=1;


SELECT player, age FROM trn_football_players 
WHERE player 
LIKE "%%";

SELECT player, age FROM trn_football_players 
WHERE player 
LIKE "%l%";


SELECT players FROM trn_football_players 
GROUP BY age 
HAVING age > 20;

SELECT COUNT(age) AS ages 
FROM trn_football_players  
GROUP BY age 
Having ages > 1;


SELECT trn_football_players.player, trn_football_players.age,trn_nation.country FROM trn_football_players 
INNER JOIN trn_nation 
ON  trn_football_players.nation_id=trn_nation.nation_id
WHERE trn_nation.nation_id BETWEEN 1 AND 5;

SELECT  trn_nation.country
		, trn_football_players.player
		, trn_club.clubname 
FROM trn_nation 
CROSS JOIN trn_football_players 
ON trn_nation.nation_id = trn_football_players.nation_id 
CROSS JOIN trn_club 
ON trn_club.club_id=trn_football_players.club_id;
 
SELECT trn_football_players.player AS player,
       trn_football_players.age AS AGE,
		 trn_nation.country AS Country
	FROM trn_football_players 
	RIGHT JOIN trn_nation
	ON trn_football_players.nation_id=trn_nation.nation_id;
	
SELECT trn_football_players.player AS player,
       trn_football_players.age AS AGE,
		 trn_nation.country AS Country
	FROM trn_football_players 
	RIGHT JOIN trn_nation
	ON trn_football_players.nation_id=trn_nation.nation_id;

SELECT * FROM trn_football_players 
RIGHT JOIN trn_nation 
ON trn_nation.nation_id = trn_football_players.nation_id;

CREATE VIEW foots AS 
SELECT trn_football_players.ranking AS rank
 		, trn_football_players.player AS players 
		, trn_football_players.age AS Age 
		, trn_nation.country AS COUNTRY 
		, trn_club.clubname AS CLUB
		, trn_role.role_name AS ROLE
		, trn_football_players.goals
		, trn_football_players.matches
		, trn_football_players.sponsors
			FROM trn_football_players
 			JOIN trn_nation ON trn_football_players.nation_id = trn_nation.nation_id 
 			JOIN trn_club ON trn_football_players.club_id=trn_club.club_id
 			JOIN trn_role ON trn_football_players.role_id = trn_role.role_id;

SELECT player, age FROM trn_football_players 
WHERE age>29 AND goals > 200;