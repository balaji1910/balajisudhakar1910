ALTER TABLE trn_football_players MODIFY goals INT;

ALTER TABLE trn_football_players ADD matches INT;

ALTER TABLE trn_football_players ADD salary VARCHAR(30);

ALTER TABLE trn_football_players ADD sponsors VARCHAR(30);

UPDATE trn_football_players SET salary="3500$" WHERE ranking=1; 
UPDATE trn_football_players SET salary="4500$" WHERE ranking=2;
UPDATE trn_football_players SET salary="2500$" WHERE ranking=3; 
UPDATE trn_football_players SET salary="1500$" WHERE ranking=4; 
UPDATE trn_football_players SET salary="1500$" WHERE ranking=5; 
UPDATE trn_football_players SET salary="500$" WHERE ranking=6; 

UPDATE trn_football_players SET sponsors="Addidas" WHERE ranking =1; 
UPDATE trn_football_players SET sponsors="Nike" WHERE ranking=2;
UPDATE trn_football_players SET sponsors="Addidas" WHERE ranking =3;
UPDATE trn_football_players SET sponsors="Nike" WHERE ranking=4; 
UPDATE trn_football_players SET sponsors="Addidas" WHERE ranking =5; 
UPDATE trn_football_players SET sponsors="Nike" WHERE ranking=6;


UPDATE trn_football_players SET matches=500 WHERE ranking=1;
UPDATE trn_football_players SET matches=400 WHERE ranking=2;
UPDATE trn_football_players SET matches=250 WHERE ranking=3;
UPDATE trn_football_players SET matches=237 WHERE ranking=4;
UPDATE trn_football_players SET matches=150 WHERE ranking=5;
UPDATE trn_football_players SET matches=200 WHERE ranking=6;