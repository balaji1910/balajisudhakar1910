/*CREATING TABLE*/
CREATE TABLE trn_nation(
		   nation_id INT PRIMARY KEY
			, country VARCHAR(20)
			);
CREATE TABLE trn_club(			
			 club_id INT PRIMARY KEY 
			 , clubname VARCHAR(20)
			 );
CREATE TABLE trn_role(
			 role_id INT PRIMARY KEY
			 , role_name VARCHAR(20)
				);
CREATE TABLE trn_football_players(			  
				ranking INT PRIMARY KEY
				, player VARCHAR(30)
				, age INT
				, nation_id INT
				, club_id INT
				, role_id INT
				, goals VARCHAR(20)
				, KEY ky_nation_id (nation_id)
				, KEY ky_club_id (club_id)
				, KEY ky_role_id (role_id)
				, CONSTRAINT cons_nation FOREIGN KEY (nation_id) REFERENCES trn_nation (nation_id)
				, CONSTRAINT cons_club FOREIGN KEY (club_id) REFERENCES trn_club (club_id)
				, CONSTRAINT cons_role FOREIGN KEY (role_id) REFERENCES trn_role (role_id)
				);


INSERT INTO trn_nation(nation_id, country) VALUES (1, 'argentina');
INSERT INTO trn_nation(nation_id, country) VALUES (2, 'Brasil');
INSERT INTO trn_nation(nation_id, country) VALUES (3, 'france');
INSERT INTO trn_nation(nation_id, country) VALUES (4, 'Portugal');
INSERT INTO trn_nation(nation_id, country) VALUES (5, 'Spain');

INSERT INTO trn_role (role_id, role_name) VALUES (1, 'forward');
INSERT INTO trn_role (role_id, role_name) VALUES (2, 'mid fielder');
INSERT INTO trn_role (role_id, role_name) VALUES (3, 'defender');
INSERT INTO trn_role (role_id, role_name) VALUES (4, 'goal keeper');


INSERT INTO trn_club (club_id, clubname) VALUES (1, 'Barcelona FC');
INSERT INTO trn_club (club_id, clubname) VALUES (2, 'Juventus');
INSERT INTO trn_club (club_id, clubname) VALUES (3, 'Manchester United');
INSERT INTO trn_club (club_id, clubname) VALUES (4, 'Real Madrid');
INSERT INTO trn_club (club_id, clubname) VALUES (5, 'Tottenham Hotspurs');


INSERT INTO trn_football_players (ranking, player, age, nation_id, club_id, role_id, goals) 
	VALUES (3,'Pogba', 26, 3, 3, 2, 158);         
INSERT INTO trn_football_players (ranking, player, age, nation_id, club_id, role_id, goals) 
	VALUES (4, 'Sergio ramos', 32, 5, 4, 3, 100);
INSERT INTO trn_football_players (ranking, player, age, nation_id, club_id, role_id, goals) 
	VALUES (1, 'Lionel Messi', 31, 1, 1, 1, 200 );          
INSERT INTO trn_football_players (ranking, player, age, nation_id, club_id, role_id, goals) 
	VALUES (5, 'marcelo', 34, 2, 4, 3, 123 ); 
INSERT INTO trn_football_players (ranking, player, age, nation_id, club_id, role_id, goals) 
	VALUES (6, 'Lloris', 30, 3, 5, 4, 20);
INSERT INTO trn_football_players (ranking, player, age, nation_id, club_id, role_id, goals) 
	VALUES (2, 'Ronaldo', 34,4, 2, 1, 300 );
	
	

INSERT INTO trn_football_players(ranking, player)values(8,'neymar');
