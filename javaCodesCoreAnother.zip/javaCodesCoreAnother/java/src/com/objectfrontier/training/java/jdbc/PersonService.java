package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;


public class PersonService {

    private static Connection connection = null;
    private static PreparedStatement preparedStatement = null;
    private static ResultSet result = null;

    static final String user = "arvindhakrishna_k";
    static final String password = "demo";
    static final String url = "jdbc:mysql://pc1620:3306/arvindhakrishna_k?useSSL=false";

    public boolean createTable(String create) {
        try {
            connection = DriverManager.getConnection(url, user, password);
            Statement statement = connection.createStatement();
            boolean result = statement.execute(create);
            connection.close();
            return result;
        } catch (Exception error) {
            throw new RuntimeException("Error with create table syntax or Already table exists");
        }
    }

    public int insertTable(String name, String email, Date birthDate, long addressId) {
        try {
            connection = DriverManager.getConnection(url, user, password);
            String insertQuery = "INSERT INTO person(name, email, birth_date, address_id) VALUES " +
                                "(?, ?, ?, ?)";

            preparedStatement = connection.prepareStatement(insertQuery);

            PersonDatabase person = new PersonDatabase();
            person.setName(name);
            person.setEmail(email);
            person.setBirthDate(birthDate);
            person.setAddressId(addressId);

            preparedStatement.setString(1, person.getName());
            preparedStatement.setString(2, person.getEmail());
            preparedStatement.setDate(3, (Date) person.getBirthDate());
            preparedStatement.setLong(4, person.getAddressId());

            int actualResult = preparedStatement.executeUpdate();
            connection.close();
            return actualResult;

        } catch(Exception error) {
            throw new RuntimeException("Email Address is repeated");
        }
    }
}
