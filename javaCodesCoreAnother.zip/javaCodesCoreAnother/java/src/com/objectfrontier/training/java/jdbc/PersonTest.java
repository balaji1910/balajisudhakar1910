package com.objectfrontier.training.java.jdbc;



import java.sql.Date;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class PersonTest {

    PersonService person;
    private Object createQuery;

    @BeforeTest
    private void initAddress() {
        person = new PersonService();
    }

    @Test (priority = 1, dataProvider = "testCreate_positiveDP")
    private void createTable_positive(String create) {

        try {
            boolean expectedResult = false;
            boolean actualResult = person.createTable(create);
            Assert.assertEquals(actualResult, expectedResult);
        } catch (Exception e) {
            Assert.fail("Error with create table syntax or Already table exists");
        }
    }

    @DataProvider
    private Object[][] testCreate_positiveDP() {
        return new Object[][] { {"CREATE TABLE person" +
                                 " (id BIGINT(20) PRIMARY KEY AUTO_INCREMENT" +
                                 ", name VARCHAR(50)" +
                                 ", email VARCHAR(100) UNIQUE" +
                                 ", birth_date DATE NOT NULL" +
                                 ", created_date DATETIME DEFAULT CURRENT_TIMESTAMP" +
                                 ", address_id BIGINT(20) NOT NULL" +
                                 ", CONSTRAINT fk_address_id FOREIGN KEY(address_id) REFERENCES address(id)" +
                                 ");"} };
    }

    @Test (priority = 2, dataProvider = "testCreate_negativeDP")
    private void createTable_negative(String create) {

        try {
            boolean result = person.createTable(create);
            Assert.fail("Expected an exception");
        } catch (RuntimeException e) {
            Assert.assertEquals(e.getMessage(), "Error with create table syntax or Already table exists");
        }
    }

    @DataProvider
    private Object[][] testCreate_negativeDP() {
        Object firstCreate = "CREATE TABLE person" +
                             " (id BIGINT(20) PRIMARY KEY AUTO_INCREMENT" +
                             ", name VARCHAR(50) NOT NULL" +
                             ", email VARCHAR(100) UNIQUE" +
                             ", birth_date DATE NOT NULL" +
                             ", created_date DATETIME DEFAULT CURRENT_TIMESTAMP" +
                             ", address_id BIGINT(20) NOT NULL" +
                             ", CONSTRAINT fk_address_id FOREIGN KEY(address_id) REFERENCES address(id)" +
                             ");";
        Object secondCreate = "";
        return new Object[][] { {firstCreate}, {secondCreate} };
    }

    @Test (priority = 3, dataProvider = "testInsert_positiveDP")
    private void insertTable_positiveDP(String name, String email, Date birthDate, long addressId) {

        try {
            int expectedResult = 1;
            int actualResult = person.insertTable(name, email, birthDate, addressId);
            Assert.assertEquals(actualResult, expectedResult);
        } catch(Exception error) {
            Assert.fail("Error in insertion");
        }
    }

    @DataProvider
    private Object[][] testInsert_positiveDP() {
        return new Object[][]{
            {"Arvindh", "karthi.arvindh96@gmail.com", Date.valueOf("1996-11-24"), 1},
            {"Almas" ,"almas1997@gmail.com", Date.valueOf("1997-06-02"), 2},
            {"Karthi", "karthi96@gmail.com", Date.valueOf("1996-6-3"), 3}
        };
    }
}
