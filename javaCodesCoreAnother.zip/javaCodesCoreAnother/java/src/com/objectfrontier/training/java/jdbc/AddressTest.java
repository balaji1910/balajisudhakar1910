package com.objectfrontier.training.java.jdbc;

import java.sql.ResultSet;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class AddressTest {

    AddressService address;
    private Object createQuery;

    @BeforeTest
    private void initAddress() {
        address = new AddressService();
    }

    @Test (priority = 1, dataProvider = "testCreate_positiveDP")
    private void createTable_positive(String create) {

        try {
            boolean expectedResult = false;
            boolean actualResult = address.createTable(create);
            Assert.assertEquals(actualResult, expectedResult);
        } catch (Exception e) {
            Assert.fail("Error with create table syntax or Already table exists");
        }
    }

    @DataProvider
    private Object[][] testCreate_positiveDP() {
        return new Object[][] { {"CREATE TABLE address" + "(id BIGINT(20) PRIMARY KEY AUTO_INCREMENT, "
                + "street VARCHAR(100) NOT NULL, "
                + "city VARCHAR(15) NOT NULL, "
                + "postal_code INT(11) NOT NULL);"} };
    }

    @Test (priority = 2, dataProvider = "testCreate_negativeDP")
    private void createTable_negative(String create) {

        try {
            boolean result = address.createTable(create);
            Assert.fail("Expected an exception");
        } catch (RuntimeException e) {
            Assert.assertEquals(e.getMessage(), "Error with create table syntax or Already table exists");
        }
    }

    @DataProvider
    private Object[][] testCreate_negativeDP() {
        Object create = "CREATE TABLE address" + "(id BIGINT(20) PRIMARY KEY AUTO_INCREMENT, "
                        + "street VARCHAR(100) NOT NULL, "
                        + "city VARCHAR(15) NOT NULL, "
                        + "postal_code INT(11) NOT NULL);";
        Object secondCreate = "";
        return new Object[][] { {create}, {secondCreate} };
    }

    @Test (priority = 3, dataProvider = "testInsert_positiveDP")
    private void insertTable_positiveDP(String street, String city, long postalCode) {
        try {
            int expectedResult = 1;
            int actualResult = address.insertTable(street, city, postalCode);
            Assert.assertEquals(actualResult, expectedResult);
        } catch(Exception error) {
            Assert.fail("Null value is identified");
        }
    }

    @DataProvider
    private Object[][] testInsert_positiveDP() {

        return new Object[][]{
            {"vallalar nagar", "salem", 636008},
            {"mahendrapuri", "salem", 636009},
            {"Nanganallur", "Chennai", 600004}
        };
    }

    @Test (priority = 4, dataProvider = "testInsert_negativeDP")
    private void insertTable_neagtiveDP(String street, String city, long postalCode) {
        try {
            int actualResult = address.insertTable(street, city, postalCode);
            Assert.fail("Expected an exception");
        } catch(Exception error) {
            Assert.assertEquals(error.getMessage(), "Null value is identified");
        }
    }

    @DataProvider
    private Object[][] testInsert_negativeDP() {

        return new Object[][] {
            {null, null, 0},
            {null, "erode", 636009},
            {"kamalesh nagar", null, 600007}
        };
    }

    @Test (priority = 5, dataProvider = "testUpdate_positiveDP")
    private void updateTable_positiveDP(String street, String city, long postalCode, int id) {
        try {
            int expectedResult = 1;
            int actualResult = address.updateTable(street, city, postalCode, id);
            Assert.assertEquals(actualResult, expectedResult);
        } catch (Exception error) {
            Assert.fail("Error in updation");
        }
    }

    @DataProvider
    private Object[][] testUpdate_positiveDP() {

        return new Object[][] {
            {"Anna nagar" ,"chennai", 6360098, 3},
            {"Mahendrapuri", "Salem", 636009, 2},
            {"323/1 Vallalar Nagar", "Salem", 636008, 1}
        };
    }

    @Test (priority = 6, dataProvider = "testUpdate_negativeDP")
    private void updateTable_negativeDP(String street, String city, long postalCode, int id) {
        try {
            int expectedResult = 1;
            int actualResult = address.updateTable(street, city, postalCode, id);
            Assert.fail("Error in updation");
        } catch(Exception error) {
            Assert.assertEquals(error.getMessage(), "Postal code is invalid");
        }
    }

    @DataProvider
    private Object[][] testUpdate_negativeDP() {

        return new Object[][] {
            {"Anna Nagar", "Chennai", 0, 3}
        };
    }

    @Test (priority = 7, dataProvider = "testRead_positiveDP")
    private void readTable_positiveDP(long id, String expectedResult) {

      try {
          String actualResult = address.readTable(id);
          Assert.assertEquals(actualResult, expectedResult);
      } catch(Exception error) {
          Assert.fail("Record not found");
      }
    }

    @DataProvider
    private Object[][] testRead_positiveDP(){

        return new Object[][] {
                                {1, "323/1 Vallalar Nagar"},
                                {2, "Mahendrapuri"},
                                {3, "Anna nagar"}
        };
    }

    @Test (priority = 8, dataProvider = "testPositive_DP")
    public void readAllRecord(int expectedResult) {

        try {
            int actualResult = address.readAllRecord();
            Assert.assertEquals(actualResult, expectedResult);
        } catch(Exception error) {
            Assert.fail("Error in selection");
        }
    }

    @DataProvider
    private Object[][] testPositive_DP() {

        return new Object[][] {
            {3},
        };
    }
}
