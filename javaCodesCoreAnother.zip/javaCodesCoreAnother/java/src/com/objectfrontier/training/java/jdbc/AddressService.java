package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.testng.annotations.DataProvider;

public class AddressService {

    private static Connection connection = null;
    private static PreparedStatement preparedStatement = null;
    private static ResultSet result = null;

    static final String user = "arvindhakrishna_k";
    static final String password = "demo";
    static final String url = "jdbc:mysql://pc1620:3306/arvindhakrishna_k?useSSL=false";

//    AddressDatabase address = null;
//    public void initAddress() {
//        address = new AddressDatabase();
//    }

    public boolean createTable(String create) {
        try {
            connection = DriverManager.getConnection(url, user, password);
            Statement statement = connection.createStatement();
            boolean result = statement.execute(create);
            connection.close();
            return result;
        } catch (Exception error) {
            throw new RuntimeException("Error with create table syntax or Already table exists");
        }
    }

    public int insertTable(String street, String city, long postalCode) {
        try {
            connection = DriverManager.getConnection(url, user, password);
            String insertQuery = "INSERT INTO address (street, city, postal_code)" + "VALUES (?, ?, ?);";

            preparedStatement = connection.prepareStatement(insertQuery);

            AddressDB address = new AddressDB();
            address.setStreet(street);
            address.setCity(city);
            address.setPostalCode(postalCode);

            preparedStatement.setString(1, address.getStreet());
            preparedStatement.setString(2, address.getCity());
            preparedStatement.setLong(3, address.getPostalCode());

            int actualResult = preparedStatement.executeUpdate();
            connection.close();
            return actualResult;
        } catch(Exception error) {
            throw new RuntimeException("Null value is identified");
        }
    }

    public int updateTable(String street, String city, long postalCode, int id) {

        if (postalCode == 0) {
            throw new RuntimeException("Postal code is invalid");
        } else {
            try {
                connection = DriverManager.getConnection(url, user, password);
                String updateQuery = "UPDATE address SET " +
                                     "street = ?, city = ?, postal_code = ? " +
                                     "WHERE id = ?";
                preparedStatement = connection.prepareStatement(updateQuery);

                AddressDB address = new AddressDB();

                address.setStreet(street);
                address.setCity(city);
                address.setPostalCode(postalCode);
                address.setId(id);

                preparedStatement.setString(1, address.getStreet());
                preparedStatement.setString(2, address.getCity());
                preparedStatement.setLong(3, address.getPostalCode());
                preparedStatement.setLong(4, address.getId());

                int actualResult = preparedStatement.executeUpdate();
                connection.close();
                return actualResult;
            } catch(Exception error) {
                throw new RuntimeException("Postal code is invalid");
            }
        }
    }

    public String readTable(long id) {

        try {
            connection = DriverManager.getConnection(url, user, password);
            String selectQuery = "SELECT street FROM address WHERE id = ?";
            preparedStatement = connection.prepareStatement(selectQuery);

            AddressDB address = new AddressDB();
            address.setId(id);

            preparedStatement.setLong(1, address.getId());

            result = preparedStatement.executeQuery();
            StringBuilder sb = new StringBuilder();

            while (result.next()) {
                String streets = result.getString(1);
                sb.append(streets);
            }

            String actualResult = sb.toString();
            connection.close();
            return actualResult;
        } catch(Exception error) {
            throw new RuntimeException("Record not found");
        }
    }

    public int readAllRecord() {

        try {
            connection = DriverManager.getConnection(url, user, password);
            String selectQuery = "SELECT street, city, postal_code, id FROM address";
            preparedStatement = connection.prepareStatement(selectQuery);
            result = preparedStatement.executeQuery();
            int count = 0;

            while(result.next()) {
                    count ++;
                }
            return count;
        } catch(Exception error) {
            throw new RuntimeException("Error in selection");
        }
    }
}
