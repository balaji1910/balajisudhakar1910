package com.ofs.training;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileDirectoryFinder {

    public static void main(String[] args) {

        Path path = Paths.get("D:/temp/java.io.examples/");
        try{
            boolean directory = Files.isDirectory(path);
            System.out.println(directory);

            boolean file = Files.isRegularFile(path);
            System.out.println(file);
        }catch(Exception e) {
            e.printStackTrace();
        }
        System.out.println();
    }
}
