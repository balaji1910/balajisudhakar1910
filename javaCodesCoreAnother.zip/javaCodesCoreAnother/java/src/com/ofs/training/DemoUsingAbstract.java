package com.ofs.training;

abstract class DemoUsingAbstract {

    public int add(int firstNumber, int secondNumber) {
        int addition = firstNumber + secondNumber;
        return addition;
    }

    public abstract int multiply(int firstNumber, int secondNumber);
}
