package com.ofs.training;

public class InitialFinder {

	public void initialFinder(String fullName) {
		String[] result = fullName.split(" ");
		char initial = 0;
		for (int i=0 ; i < result.length; i++) {
			initial = result[i].charAt(0);
		System.out.print(initial);
		}
	}
	public static void main(String[] args) {

		InitialFinder initial = new InitialFinder();
		String inputString = "Krishnasamy Karuppaiahj";
		initial.initialFinder(inputString);
	}

}
