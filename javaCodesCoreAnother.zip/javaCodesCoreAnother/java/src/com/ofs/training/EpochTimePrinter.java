package com.ofs.training;

import java.time.Instant;
import java.util.Calendar;
import java.util.TimeZone;

public class EpochTimePrinter {

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }

    public static void main(String[] args) {

        System.out.println(Instant.now().getEpochSecond());
    }
}
