package com.ofs.training;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SortPerson {

    public static void main(String[] args) {

        SortPerson sort = new SortPerson();
        List<Person> person = Person.createRoster();
        List<Person> sortedPerson = sort.getSortedPerson(person);
        System.out.println(sortedPerson);
    }
    private List<Person> getSortedPerson(List<Person> persons) {

        return persons.stream()
                      .sorted(Comparator.comparing(Person::getAge)
                                        .reversed())
                      .collect(Collectors.toList());
    }
}
