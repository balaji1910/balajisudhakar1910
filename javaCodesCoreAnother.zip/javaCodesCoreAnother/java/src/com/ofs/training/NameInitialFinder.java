package com.ofs.training;

public class NameInitialFinder {

	public static char computeInitial(String fullName) {

		char initial = 0;
		if (fullName == null) {
			throw new RuntimeException("Cannot operate null value");
		}

		if (!(fullName == null)) {
			int lastSpace = fullName.lastIndexOf(" ");
			String sirName = fullName.substring(lastSpace + 1, fullName.length());
			initial = sirName.charAt(0);
		}
		return initial;
	}
}
