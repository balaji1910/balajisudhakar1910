package com.ofs.training;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalTime;

public class TimeStampPrinter {

    private static void print() {

        Timestamp time = Timestamp.from(Instant.now());
        log("Time Stamp for the current time is: %s", time);
    }

    public static void main(String[] args) {

        TimeStampPrinter.print();
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
