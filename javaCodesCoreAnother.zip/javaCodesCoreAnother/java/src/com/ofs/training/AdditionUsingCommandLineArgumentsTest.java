package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class AdditionUsingCommandLineArgumentsTest {

    AdditionUsingCommandLineArguments addition;

    @BeforeTest
    private void initClass() {
        addition = new AdditionUsingCommandLineArguments();
    }

    @Test(dataProvider = "testType_positiveDP")
private void testCompare_positiveDP(int[] inputNumbers, int expectedResult) {

        int actualResult = 0;
        try {
            actualResult = addition.add(inputNumbers);
            Assert.assertEquals(actualResult, expectedResult);
        } catch(Exception e) {
            Assert.fail("Unexpected Result: " + actualResult + "Expected Result is:" + expectedResult);
        }
    }

    @DataProvider
    private Object[][] testType_positiveDP() {

        return new Object[][] { { new int[] {10, 20, 30, 40, 50, 60}, 210 }, 
            { new int[] { 20, 30, 40, 60 }, 150 },
            { new int[] { 50, 60, 80, 56, 23 }, 269 }
        };
    }

    @Test(dataProvider = "testType_negativeDP")
    private void testCompare_negativeDP(int[] inputNumbers) {

        try {
            int actualResult = addition.add(inputNumbers);
            Assert.fail("No input is given");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Cannot be added");
        }
    }

    @DataProvider
    private Object[][] testType_negativeDP() {

        return new Object[][] { { new int[] {} },
            { new int[] { 101 } } 
        };
    }
}
