//Create two paths and test whether they represent same path

package com.ofs.training;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class PathChecker {

    public static void main(String[] args) throws Exception {

        Path path = Paths.get(args[0]);
        Path anotherPath = Paths.get(args[1]);

        PathChecker checker = new PathChecker();
        boolean compareTo = checker.compareTo(path, anotherPath);
        System.out.println(compareTo);
        boolean sameFile = checker.sameFile(path, anotherPath);
        System.out.println(sameFile);
    }

    private boolean compareTo(Path path, Path anotherPath) {

        if (path.compareTo(anotherPath) == 0) {
            return true;
        } else { return false; }
    }

    private boolean sameFile(Path path, Path anotherPath) throws Exception {

        if (Files.isSameFile(path, anotherPath)) {
            return true;
        } else { return false; }
    }
}
