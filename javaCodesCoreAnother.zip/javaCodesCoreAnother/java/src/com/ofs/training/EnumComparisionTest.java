package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class EnumComparisionTest {

	EnumComparision compare;

	@BeforeTest
	private void initClass(){

		compare = new EnumComparision();
	}

	@Test(dataProvider = "testCompare_positiveDP")
	private void compare_positiveDP(Object obj1, Object obj2, boolean b1, boolean b2) {

		try {
			boolean comparatorResult = compare.compareEnumValue(obj1, obj2);
			boolean equalsResult = compare.equalCompare(obj1, obj2);
			Assert.assertEquals(comparatorResult, b1);
			Assert.assertEquals(equalsResult, b1);
		} catch(Exception e) {
			Assert.fail("Unexpected result");
		}
	}

	@DataProvider
	private Object[][] testCompare_positiveDP() {
        return new Object[][] {
                                { EnumShape.Circle, EnumShape.Rectangle, false, false},
                                { EnumShape.Rectangle, EnumShape.Rectangle, true, true },
                                { EnumSeason.AUTUMN, EnumSeason.SPRING, false, false },
                                { EnumSeason.AUTUMN, EnumShape.Rectangle, false, false }
        };
	}
	@Test
	private void compare_negativeDP() {

		try {
			Object obj1 = null;
			Object obj2 = null;
			boolean result = compare.compareEnumValue(obj1, obj2);
			Assert.fail("Null is identified");
		} catch(Exception e) {
			Assert.assertEquals(e.getMessage(), "Null cannot be compared");
		}
	}
}
