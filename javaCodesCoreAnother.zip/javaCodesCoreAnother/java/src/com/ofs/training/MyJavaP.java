package com.ofs.training;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Constructor;

//class MyJavaP {
public class MyJavaP {

    public static void modifier(int mod) {
        if (Modifier.isPublic(mod)) {
            System.out.print("public" + " ");
        }
        if (Modifier.isPrivate(mod)) {
            System.out.print("private" + " ");
        }
        if (Modifier.isProtected(mod)) {
            System.out.print("protected" + " ");
        }
        if (Modifier.isStatic(mod)) {
            System.out.print("static" + " ");
        }
        if (Modifier.isFinal(mod)) {
            System.out.print("final" + " ");
        }
        if (Modifier.isSynchronized(mod)) {
            System.out.print("synchronized" + " ");
        }
        if (Modifier.isVolatile(mod)) {
            System.out.print("volatile" + " ");
        }
        if (Modifier.isTransient(mod)) {
            System.out.print("transient" + " ");
        }
        if (Modifier.isInterface(mod)) {
            System.out.print("interface" + " ");
        }
        if (Modifier.isAbstract(mod)) {
            System.out.print("abstract" + " ");
        }
        if (Modifier.isStrict(mod)) {
            System.out.print("strict" + " ");
        }
        if (Modifier.isNative(mod)) {
            System.out.print("native" + " ");
        }
    }

    // static void execute() {
    public static void main(String[] args) throws Exception {

        System.out.println("Compiled from" + " " + String.class.getSimpleName() + ".java");

        //Get the implemented interface of the class
        Class className = Class.forName(args[0]);
        String classNam = className.getName();
        int classModifier = className.getModifiers();
        modifier(classModifier);
        System.out.print(className + " " + "implements" + "");
        Class[] classInterface = className.getInterfaces();
            for(Class classInter : classInterface) {
                System.out.print(" " + classInter.getName() + ",");
            }
        System.out.println();

        // field = currentClass.getFieldName();
        Field[] field = className.getFields();
        for (int index1 = 0; index1 < field.length; index1++) {
            String fieldName = field[index1].getName();
            String fieldType = field[index1].getGenericType().getTypeName();
            int returnType = field[index1].getModifiers();
            modifier(returnType);
            System.out.println(" " + fieldName + " " + fieldType + "");
        }

        // Constructor = currentClass.getConstructorName();
        // print (constructor details)
        Constructor[] constructor = className.getConstructors();
        for (int index4 = 0; index4 < constructor.length; index4++) {
            String constructorName = constructor[index4].getName();
            int returnTypeConstructor = constructor[index4].getModifiers();
            modifier(returnTypeConstructor);
            Class[] constructorParameter = constructor[index4].getParameterTypes();
            for (Class parameter : constructorParameter) {
                System.out.print("(" + parameter.getTypeName() + "");
            }
            System.out.println(")");
        }

        // method = currentClass.getMethodName();
        Method[] method = className.getMethods();
        for (int index2 = 0; index2 < method.length; index2++) {
            String methodName = method[index2].getName();
            String methodType = method[index2].getReturnType().getTypeName();
            int returnTypeMethod = method[index2].getModifiers();
            modifier(returnTypeMethod);
            Class[] classMethod = method[index2].getParameterTypes();
            for (int index3 = 0; index3 < classMethod.length; index3++) {
                System.out.print("(" + classMethod[index3].getTypeName() + "");
            }
            System.out.println(")");
        }
    }
}
