package com.ofs.training;

public class AbsolutePathFinder {

        //static void execute() {
        public static void main(String[] args) {

        //classFileLocationFinder cf = getCurrentProgram();
        AbsolutePathFinder absolute = new AbsolutePathFinder();

        // class currentClass = cf.getClass()
        Class currentClass = absolute.getClass();

        // File currentClassFile = currentClass.getFile()
        // String absPath = curentClassFile.getAbsolutePath()
        String absolutePath = currentClass.getProtectionDomain()
                                     .getCodeSource()
                                     .getLocation()
                                     .getFile();

        // Console console = getConsole()
        // console.print(absPath)
        System.out.println(absolutePath + currentClass.getName() + ".class");
        }
}
