package com.ofs.training;

enum EnumShape { Circle,
             Rectangle,
             Square,
             Triangle; }
