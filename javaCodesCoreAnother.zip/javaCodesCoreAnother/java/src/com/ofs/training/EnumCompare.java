package com.ofs.training;

public class EnumCompare {

    public static void main(String[] args) {

        System.out.println(EnumSeason.SUMMER == EnumSeason.AUTUMN);
        System.out.println((EnumSeason.AUTUMN).equals(EnumSeason.AUTUMN));
        System.out.println(EnumShape.Circle == EnumShape.Triangle);
    }
}
