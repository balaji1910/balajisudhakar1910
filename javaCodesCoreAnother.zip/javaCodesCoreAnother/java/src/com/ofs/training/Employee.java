package com.ofs.training;

public class Employee {

    public static int id = 0;
    private String name;

    Employee(String employeeName) {
        this.name = name;
        id = id + 1;
    }

    public String toString() {
        return "Id Number: " + id + "\t Employee Name:" + name;
    }

    public static void main(String[] args) {

        Employee arvind = new Employee("Arvindhakrishna");
        System.out.println(arvind);

        Employee vignesh = new Employee("Vignesh");
        System.out.println(vignesh);

        Employee Karthi = new Employee("Karthick");
        System.out.println(Karthi);

        Employee Vinoth = new Employee("Vinoth");
        System.out.println(Vinoth);

        Employee Almas = new Employee("Almas");
        System.out.println(Almas);

        Employee Balaji = new Employee("Balaji");
        System.out.println(Balaji);

        Employee Tamil = new Employee("Tamil");
        System.out.println(Tamil);

        Employee Harish = new Employee("Harish");
        System.out.println(Harish);
    
        Employee Arun = new Employee("Arun");
        System.out.println(Arun);

        Employee Kumar = new Employee("Kumar");
        System.out.println(Kumar);

    }
}
