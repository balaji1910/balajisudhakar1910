package com.ofs.training;

public class ResultTypeFinder {

    private void printDataType(Object[] obj) {

        for (int index = 0; index < obj.length; index++) {

            if (obj[index] instanceof Integer) {
                System.out.println(obj[index] + "-->" + "Type is int");
            }

            if (obj[index] instanceof Float) {
                System.out.println(obj[index] + "-->" + "Type is float");
            }

            if (obj[index] instanceof Double) {
                System.out.println(obj[index] + "-->" + "Type is double");
            }

            if (obj[index] instanceof Long) {
                System.out.println(obj[index] + "-->" + "Type is long");
            }
        }
    }

    public static void main(String[] args) {

        ResultTypeFinder resultType = new ResultTypeFinder();
        Object[] obj = { 100 / 24,
                         100.10 / 10,
                         'Z' / 2,
                         10.5 / 0.5,
                         12.4 % 5.5,
                         100 % 56 };

        resultType.printDataType(obj);
    }
}
