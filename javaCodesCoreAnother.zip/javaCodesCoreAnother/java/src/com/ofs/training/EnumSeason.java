package com.ofs.training;

enum EnumSeason { WINTER,
                SUMMER,
                SPRING,
                AUTUMN; }
