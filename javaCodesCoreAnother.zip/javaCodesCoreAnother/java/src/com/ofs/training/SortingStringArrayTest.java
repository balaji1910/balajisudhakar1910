package com.ofs.training;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class SortingStringArrayTest {

    private SortingString sort;

    @BeforeMethod
    private void init() {
        sort = new SortingString();
    }

    @Test(dataProvider = "testFindIntial_positiveDP")
    private void testSortStringMethod_positiveDP(String[] input, String[] expectedResult) {

        try {
            String[] result = sort.sortStringMethod(input);
            Assert.assertEquals(result, expectedResult);
        } catch (Exception e) {
            Assert.fail("Unexpected result /n ERROR");
        }
    }

    @Test
    private void testSortStringMethod_negativeDP() {

        try {

            String[] inputArrays = { "AK" };
            String[] testArrays = sort.sortStringMethod(inputArrays);
            Assert.fail("Single string is found");
        } catch (RuntimeException e) {

            Assert.assertEquals(e.getMessage(), "Cannot sort single string");
        }
    }

    @DataProvider
    private Object[][] testFindIntial_positiveDP() {
        String[] inputOne = { "Madurai", "Thanjavur", "TRICHY", "Karur", "Erode", "trichy", "Salem" };

        String[] expectedResultOne = { "ERODE", "Karur", "MADURAI", "Salem", "THANJAVUR", "TRICHY", "TRICHY" };

        String[] inputTwo = { "Chennai", "Thanjavur", "TRICHY", "Namakkal", "CHITTUR", "trichy", "America" };

        String[] expectedResultTwo = { "AMERICA", "Chennai", "CHITTUR", "Namakkal", "THANJAVUR", "TRICHY", "TRICHY" };

        return new Object[][] { { inputOne, expectedResultOne }, { inputTwo, expectedResultTwo } };
    }
}
