package com.ofs.training;

public class SubStringOperation {

    public String subStringMethod(String inputString) {

        if (inputString == null) { 
            throw new RuntimeException("Null value is found");
        }
        return inputString.substring(9, 12);
    }

    public int subStringFindLength(String stringResult) {
        int stringLength = stringResult.length();
        return stringLength;
    }
}
