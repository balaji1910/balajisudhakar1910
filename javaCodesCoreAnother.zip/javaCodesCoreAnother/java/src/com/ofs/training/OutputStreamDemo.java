package com.ofs.training;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class OutputStreamDemo {

    public static void main(String[] args) {

        String content = "I am tamilarasan.k";
        File file = new File("D:/temp/SampleFile.txt");

        try(OutputStream out = new FileOutputStream(file)) {
            file.createNewFile();
            byte[] byteContents = content.getBytes();
            out.write(byteContents);
            out.flush();
            out.close();
            System.out.print("String Content is added using OutputStreams");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
