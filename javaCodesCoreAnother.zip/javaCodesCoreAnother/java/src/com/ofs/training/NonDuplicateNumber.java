package com.ofs.training;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class NonDuplicateNumber {

    private List<Integer> getNonDuplicateList(List<Integer> randomNumbers) {
        return randomNumbers.stream()
                            .distinct()
                            .collect(Collectors.toList());
    }

    public static void main(String[] args) {

        NonDuplicateNumber remover = new NonDuplicateNumber();
        List<Integer> randomNumbers = Arrays.asList(1, 6, 6, 10, 10, 25, 78);
        System.out.println(remover.getNonDuplicateList(randomNumbers));
    }
}
