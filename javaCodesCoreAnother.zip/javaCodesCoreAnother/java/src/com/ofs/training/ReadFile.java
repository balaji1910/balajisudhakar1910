package com.ofs.training;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class ReadFile {

    private static String source = "PathTester.java";

    public static void main(String[] args) throws Exception{

        ReadFile rf = new ReadFile();
        rf.run();
    }

    public void run() throws Exception {

        InputStream file = getClass().getClassLoader().getResourceAsStream(source);
        InputStreamReader isr = new InputStreamReader(file);
        file.read();
        System.out.println("Reading the file using InputStream");
        file.close();
    }
}
