package com.ofs.training;

public class OopsDemoUsingCat extends OopsDemoUsingAnimal {

    void stretch() {
        System.out.println("Stretches");
    }

    void yawn(String name, int count) {
        System.out.println("Cat Yawns");
    }

    public static void main(String[] args) {

        OopsDemoUsingCat john = new OopsDemoUsingCat();
        // john.yawn();
        john.yawn("john", 10);
    }
}
