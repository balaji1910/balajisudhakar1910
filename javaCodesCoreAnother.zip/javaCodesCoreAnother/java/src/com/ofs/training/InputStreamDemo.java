package com.ofs.training;

import java.io.FileInputStream;
import java.io.InputStream;

public class InputStreamDemo {

    public static void main(String[] args) {

        InputStream input;
        int index;
        char ch = 0;
        try{
            input = new FileInputStream("D:/temp/java.io.examples/inputStreamFile.txt");
//            input.close();
            while ((index = input.read()) != -1) {
//                if (input.available() >= 10) {
                    ch = (char)index;
                    System.out.print(ch);
//                } else System.out.println("Input not found");
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
