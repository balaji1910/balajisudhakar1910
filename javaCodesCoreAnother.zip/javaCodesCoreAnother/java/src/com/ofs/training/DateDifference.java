//Find the difference between two dates.

package com.ofs.training;

import java.time.LocalDate;
import java.time.Period;

public class DateDifference {

    private void difference() {

        LocalDate dateOne = LocalDate.of(2018, 9, 25);
        LocalDate dateTwo = LocalDate.of(1997, 07, 16);
        System.out.println(Period.between(dateOne, dateTwo));
    }
    public static void main(String[] args) {

        DateDifference obj = new DateDifference();
        obj.difference();
    }
}
