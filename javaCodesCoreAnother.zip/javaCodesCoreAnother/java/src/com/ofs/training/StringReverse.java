package com.ofs.training;

public class StringReverse implements CharSequence {

    private String inputString;

    public StringReverse(String inputString) {
        this.inputString = inputString;
    }

    private char[] charArray ;

    @Override
    public int length() {
        charArray = inputString.toCharArray();
        int count = inputString.length();
        return count;
    }

    @Override
    public char charAt(int index) {
        char resultChar = charArray[index];
        return resultChar;
    }

    @Override
    public CharSequence subSequence(int start, int end) {

        char[] resultArrays = new char[length()];
        for (int i = start; i <= end; i++) {
            resultArrays[i] = charArray[i];
        }
        System.out.println(resultArrays);
        return new String(resultArrays);

    }

    @Override
    public String toString() {

        StringBuffer buffer = new StringBuffer(inputString);
        System.out.println(buffer.reverse());
        return null;
    }

    public static void main(String[] args) {

        StringReverse demo = new StringReverse("Was it a bus or cat i shot at?");
        demo.length();
        demo.subSequence(1, 5);
    }
}
