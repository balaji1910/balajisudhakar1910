package com.ofs.training;

public class MultipleAdder {

    private static final String ERR_NOT_ENOUGH_VALUES = "Require more than one input";

    public int add(String[] numbers) {

        if (numbers.length < 2) {
            throw new RuntimeException(ERR_NOT_ENOUGH_VALUES);
        }

        int sum = 0;
        for (String number : numbers) {
            sum += Integer.parseInt(number);
        }
        return sum;
    }

    public static void main(String[] args) {

        MultipleAdder adder = new MultipleAdder();
        int result = adder.add(args);
        System.out.format("Sum of the given values : %d", result);
    }
}
