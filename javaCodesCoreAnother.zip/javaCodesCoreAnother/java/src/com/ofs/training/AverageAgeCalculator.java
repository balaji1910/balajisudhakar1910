package com.ofs.training;

import java.util.List;

public class AverageAgeCalculator {

    public static void main(String[] args) {

        AverageAgeCalculator obj = new AverageAgeCalculator();
        List<Person> persons = Person.createRoster();
        double averageAge = obj.calculateAverageAge(persons);
        System.out.println(averageAge);
    }

    private double calculateAverageAge(List<Person> persons) {
        return persons.stream()
                      .mapToInt(person -> person.getAge())
                      .average()
                      .getAsDouble();
    }
}
