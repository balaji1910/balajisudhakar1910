package com.ofs.training;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class InputStreamToStringConvertor {

    public static void main(String[] args) {

        InputStreamToStringConvertor convertor = new InputStreamToStringConvertor();
        convertor.run();
    }

    private void run() {
        String content;

        try {
            InputStream file = InputStreamToStringConvertor.class.getResourceAsStream("PathTester.java");
            BufferedReader buffer = new BufferedReader(new InputStreamReader(file));
            while((content = buffer.readLine()) != null) {
                System.out.println(content);
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
