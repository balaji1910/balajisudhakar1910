package com.ofs.training;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderDemo {

    public static void main(String[] args) throws IOException {

        File file = new File("D:/temp/java.io.examples/writerDemo.txt");
        BufferedReader buffer = new BufferedReader(new FileReader(file));
        System.out.println(buffer.readLine());
    }
}
