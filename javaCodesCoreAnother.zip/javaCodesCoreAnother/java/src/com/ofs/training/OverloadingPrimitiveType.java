package com.ofs.training;

public class OverloadingPrimitiveType {

    public static void integer(int i) {
        System.out.println("Primitive type int:" + i);
    }

    private static void integer(Integer i) {
        System.out.println(i);
    }

    private static void integer(float i) {
        System.out.println(i);
    }

    public static void main(String[] args) {

        OverloadingPrimitiveType opt = new OverloadingPrimitiveType();
        opt.integer(10);
        opt.integer(new Long(500));
        System.out.println();
    }
}
