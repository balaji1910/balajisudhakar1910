package com.ofs.training;

import java.util.function.Predicate;

public class StreamOperation {

    private static Predicate<Person> isAdultMale() {

        return p -> (p.getAge() >21) && (p.getGender() == Person.Sex.MALE);
    }

    private static Predicate<Person> isMale() {

        return male -> male.getGender() == Person.Sex.MALE;
    }

    public static void main(String[] args) {

        Person.createRoster().stream()
                             .filter(isMale())
                             .forEach(male -> System.out.println(male.getName()));
    }
}
