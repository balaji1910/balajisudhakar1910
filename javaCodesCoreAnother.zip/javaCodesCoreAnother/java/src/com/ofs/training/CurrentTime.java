package com.ofs.training;

import java.text.SimpleDateFormat;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetTime;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;

import javafx.util.converter.LocalDateStringConverter;

public class CurrentTime {

    //Getting the time
    private void localTime() {
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
        LocalDate date = LocalDate.now();
    }

    //Getting the current time using the date class
    private Date date() {
        Date date = new Date();
        date.getTime();
        return date;
    }

    public static void main(String[] args) {

        // calling the above method
        CurrentTime time = new CurrentTime();
        System.out.println(time.date());

        Date date = new Date();
        System.out.println(date);

        System.out.println(LocalTime.now());
        System.out.println(LocalDateTime.now());
        LocalDateTime dateTime = LocalDateTime.now();
        System.out.println("Hours : " + dateTime.getHour() + " minutes: " + dateTime.getMinute() + " Seconds:" + dateTime.getSecond() +
                            "Nano seconds : " + dateTime.getNano());

        System.out.println(LocalTime.now(Clock.system(ZoneId.systemDefault())));
        System.out.println(Calendar.getInstance());

        System.out.println(OffsetTime.now());
        System.out.println(Clock.systemDefaultZone().instant());
    }
}
