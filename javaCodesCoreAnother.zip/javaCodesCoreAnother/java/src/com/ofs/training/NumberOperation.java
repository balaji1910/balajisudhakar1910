package com.ofs.training;

import java.util.Arrays;
import java.util.List;

public class NumberOperation {


//    private static int sum = 0;
//    private int sum() {
//        sum += randomNumbers.stream().reduce(0, (x,y) -> x+y);
//        return sum;
//    }

//    IntStream mapToInt = randomNumbers.stream().mapToInt(Integer::intValue);

    private void result() {

        List<Integer> randomNumbers = Arrays.asList(1, 6, 10, 25, 78);
        int total = randomNumbers.stream()
                    .mapToInt(Integer::intValue)
                    .sum();

        int minimumNumber = randomNumbers.stream()
                            .mapToInt(Integer::intValue)
                            .min()
                            .getAsInt();

        int maximumNumber = randomNumbers.stream()
                            .mapToInt(Integer::intValue)
                            .max()
                            .getAsInt();

        System.out.format("Sum: %d%n" + "minimum number: %d %n" + "maximum number: %d \n",
                          total, minimumNumber, maximumNumber);
    }

    public static void main(String[] args) {

        NumberOperation calculate = new NumberOperation();
        calculate.result();
    }
}
