package com.ofs.training;

import java.time.LocalTime;

public class MilliNanoSecond {

    public static void run() {

        int timeNano = LocalTime.now().getNano();
        long timeMilli = System.currentTimeMillis();
        log("Current time in NanoSeconds : %d%nCurrent Time in Milli seconds : %d%n", timeNano, timeMilli);
    }

    public static void main(String[] args) {

        MilliNanoSecond.run();
    }
    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
