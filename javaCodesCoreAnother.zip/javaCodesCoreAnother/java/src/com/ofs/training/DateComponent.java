package com.ofs.training;

import java.time.LocalDateTime;

public class DateComponent {

    public static void main(String[] args) {

        LocalDateTime date = LocalDateTime.now();
        System.out.format(" year : %s%n month : %s%n date : %s%n", date.getYear(), date.getMonth(), date.getDayOfMonth());
    }
}
