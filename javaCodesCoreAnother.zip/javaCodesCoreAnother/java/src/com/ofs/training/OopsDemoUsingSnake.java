package com.ofs.training;

public class OopsDemoUsingSnake extends OopsDemoUsingAnimal {

    void flick(String behavior) {
        System.out.println("Snakes flicks frequently");
    }

    void flick(int count) {
        System.out.println("Flicks counts 20 flicks/min");
    }

    void crawl() {
        System.out.println("Movement of snake is crawling");
    }

    public void eat(String eat) {
        System.out.println("Snakes eats");
    }

    public void eat() {
        System.out.println("Snake eats");
    }

    public static void main(String[] args) {

        OopsDemoUsingSnake cobra = new OopsDemoUsingSnake();
        OopsDemoUsingAnimal animalCobra = new OopsDemoUsingSnake();

        cobra.flick("behavior");
        cobra.flick(20);
        cobra.crawl();
        animalCobra.eat("Animal");
//        animalCobra.eat();
    }
}
