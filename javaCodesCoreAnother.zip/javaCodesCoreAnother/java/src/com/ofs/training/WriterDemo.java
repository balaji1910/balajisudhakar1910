package com.ofs.training;

import java.io.File;
import java.io.FileWriter;
import java.io.Writer;

public class WriterDemo {

    public static void main(String[] args) {

        String content = "I am Arvindhakrishna.k";
        File file = new File("D:/temp/java.io.examples/writerDemo.txt");

        try {
            Writer writeFile = new FileWriter(file);
            String sequence = "\tand my hobby is to play football\t";
//            if(!(file.exists())) {
                file.createNewFile();
//            }
            writeFile.write(content);
            writeFile.append(sequence);
            writeFile.append(sequence, 5, 9);
            writeFile.flush();
            writeFile.close();
            System.out.print("String is written using Writer");
        }catch(Exception e) {
            e.printStackTrace();
        }
    }
}
