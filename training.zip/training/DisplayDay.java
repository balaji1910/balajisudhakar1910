package com.ofs.training;

import java.time.DayOfWeek;
import java.time.Month;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;

public class DisplayDay {

    public static void main(String[] args) {

        YearMonth yearMonth = YearMonth.of(1996, 10);
        boolean leapYear = yearMonth.isLeapYear();
        Month month = yearMonth.getMonth();
        DayOfWeek monday = DayOfWeek.MONDAY;

        int length = month.length(leapYear);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
        for (int i = 1; i <= length; i++) {

            if(yearMonth.atDay(i).getDayOfWeek() == monday) {

                log("Monday : %s%n", yearMonth.atDay(i).format(formatter));
            }
        }
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
