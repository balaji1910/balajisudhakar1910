package com.ofs.training;

import java.util.List;
import java.util.stream.Collectors;

public class MinimalPersonCollector {

    private List<String> personStream(List<Person> persons) {
                   return persons.stream()
                                 .map(l->l.getName() + " " + l.getEmailAddress())
                                 .collect(Collectors.toList());
    }

    public static void main(String[] args) {

        MinimalPersonCollector collector = new MinimalPersonCollector();
        List<Person> persons = Person.createRoster();
        System.out.println(collector.personStream(persons));
    }
}
