package com.ofs.training;

import java.util.Arrays;

class ArraySortEvenUppercase {

    // static void execute
    public static void main(String[] args) {

        //
        String[] arr = { "Madurai",
                         "Thanjavur",
                         "TRICHY",
                         "Karur",
                         "Erode",
                         "trichy",
                         "Salem" };

        // Array sortArray = cp.sort()
        Arrays.sort(arr, String.CASE_INSENSITIVE_ORDER);
        for (int i = 0; i < arr.length; i++) {
            if ((i % 2 == 0) && (i != 0)) {
                System.out.println(arr[i].toUpperCase());
            } else {
                System.out.println(arr[i]);
            }
        }
    }
}
