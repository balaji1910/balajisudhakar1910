package com.ofs.training;

//class ExpressionResultType {
public class ExpressionResultType {

    public static void printType(Object object) {
        System.out.println(object.getClass().getSimpleName());
    }

    // static void execute() {
    public static void main(String[] args) {

        ExpressionResultType.printType(100 / 24);
        ExpressionResultType.printType(100.10 / 10);
        ExpressionResultType.printType('Z' / 2);
        ExpressionResultType.printType(10.5 / 0.5);
        ExpressionResultType.printType(12.4 % 5.5);
        ExpressionResultType.printType(100 / 56);
    }
}
