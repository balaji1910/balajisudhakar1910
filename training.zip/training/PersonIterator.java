// Iterate the roster list in Persons class and and print the person without using forLoop/Stream
//change the class name

package com.ofs.training;

import java.util.Iterator;
import java.util.List;

public class PersonIterator {

    public static void main(String[] args) {
        List<Person> persons = Person.createRoster();
        Iterator<Person> person = persons.iterator();

        while (person.hasNext()) {
            Person name = person.next();
            System.out.println(name.getName());
        }
    }
}
