//(3)Print the components of the current date

package com.ofs.training;

import java.time.LocalDate;

public class CurrentDateComponents {

	private void getCurrentDate() {

		LocalDate currentDate =  LocalDate.now();
		log("%d.%s.%d%n", currentDate.getDayOfMonth(), currentDate.getMonthValue(), currentDate.getYear());
		log("%d%n%s%n%d%n", currentDate.getDayOfMonth(), currentDate.getMonth(), currentDate.getYear());

	}

	public static void main(String[] args) {

		CurrentDateComponents component = new CurrentDateComponents();
		component.getCurrentDate();
	}

	private static void log(String format, Object... args) {

		System.out.format(format, args);
	}
}
