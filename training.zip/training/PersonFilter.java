//(1)filter
//    - predicates
//        - Write a program to filter the Person, who are male and age greater than 21

package com.ofs.training;

import java.util.List;
import java.util.Optional;

public class PersonFilter {

	private void filter(List<Person> roster) {

	System.out.println();
	}
    public static void main(String[] args) {

        PersonFilter filterPerson = new PersonFilter();
    	List<Person> roster = Person.createRoster();
    	filterPerson.filter(roster);
        Optional<String> findName = roster.stream()
                                          .filter(person -> person.getGender() == Person.Sex.MALE)
                                          .map(Person::getName)
                                          .findAny();
        if(findName.isPresent()) {
            System.out.println("name: " + findName.get());
        }
    }
}
