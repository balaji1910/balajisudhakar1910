//(1) Get current time using possible APIs

package com.ofs.training;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
// import java.util.Calendar;
import java.util.Calendar;
import java.util.Date;

public class CurrentTime {

    public static void main(String[] args) {

        CurrentTime instantTime = new CurrentTime();
        instantTime.getCurrentTime();
    }

    private void getCurrentTime() {

        LocalDate localDate = LocalDate.now();
        log("Current Date : " + localDate );

        LocalDateTime localDateTime = LocalDateTime.now();
        log("%nCurrent Date Time : " + localDateTime);

        ZonedDateTime zonedDateTime = ZonedDateTime.now();
        log("%nCurrent Date Time : " + zonedDateTime);

        Date date = Calendar.getInstance().getTime();  ;
        log("%nCurrent Date Time : " + date);

        Instant instantTime = Instant.now();
        System.out.println(instantTime);

        Clock currentClockTime = Clock.systemDefaultZone();
        System.out.println(currentClockTime.getZone());
    }

    private static void log(String format, Object... vargs) {
        System.out.format(format, vargs);
    }
}
