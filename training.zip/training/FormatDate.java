// Formatting current date to following formats: 2001-07-04T12:08:56.235-0700 and 2001.07.04 at 12:08:56 PDT

//package com.ofs.training;
//
//import java.text.SimpleDateFormat;
//import java.util.Date;
//
//public class FormatDate {
//   public static void main(String args[]) {
// 
//      Date d = new Date();
//      SimpleDateFormat simpleFormatTwo = new SimpleDateFormat ("yyyy-MM-dd'T'HH:mm:ss-SSSZ");
//      SimpleDateFormat simpleFormatOne = new SimpleDateFormat ("yyyy.MM.dd 'at' HH:mm:ss ");
//
//
//      System.out.println("Current Date & Time: " + simpleFormatOne.format(d));
//      System.out.println("Current Date & Time: " + simpleFormatTwo.format(d));
//   }
//}

package com.ofs.training;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class FormatDate {

    public static void main(String[] args) {

        Date now = new Date();
        System.out.println(now);
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
        Calendar edt = Calendar.getInstance(TimeZone.getTimeZone("EDT"));
        System.out.println("edt" + edt.getTime());
        System.out.println("cal" + cal.getTime());
        System.out.println("Day of the week   :" + cal.get(Calendar.DAY_OF_WEEK));
        System.out.println("days of the year  : " + cal.getCalendarType());
        System.out.println("days of the month :" + cal.DAY_OF_MONTH);
        System.out.println(cal.getTime());
        System.out.println(cal.getTimeZone());
        System.out.println(cal.getAvailableCalendarTypes());

        SimpleDateFormat dateFormatter = new SimpleDateFormat("E, y-M-d 'at' h:m:s a z");
        System.out.println("Format 1:   " + dateFormatter.format(now));

        dateFormatter = new SimpleDateFormat("E yyyy.MM.dd 'at' hh:mm:ss a zzz");
        System.out.println("Format 2:   " + dateFormatter.format(now));

        dateFormatter = new SimpleDateFormat("EEEE, MMMM d, yyyy");
        System.out.println("Format 3:   " + dateFormatter.format(now));

        dateFormatter = new SimpleDateFormat("EEEE, dd-MM-yyyy");
        System.out.println("Format 4 :  " + dateFormatter.format(now));

    }
}
