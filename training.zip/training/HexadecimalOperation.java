package com.ofs.training;

public class HexadecimalOperation {

    public static void main(String[] args) {
        int number = 65;
        System.out.println(Integer.toHexString(number));
    }
}
