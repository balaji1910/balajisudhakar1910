// sort the roster list based on the person's age in descending order using java.util.Stream

package com.ofs.training;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class PersonSort {

      private List<Person> getSortedPerson(List<Person> persons) {

          return persons.stream()
                        .sorted(Comparator.comparing(Person::getAge)
                        .reversed())
                        .collect(Collectors.toList());
      }

  public static void main(String[] args) {

      PersonSort sort = new PersonSort();
      List<Person> person = Person.createRoster();
      List<Person> sortedPerson = sort.getSortedPerson(person);
      System.out.println(sortedPerson);
  }
}
