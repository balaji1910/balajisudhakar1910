// ISO standard - Format and print current date into ISO date format

package com.ofs.training;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

public class IsoDate {

    public static void main(String[] args) {
        LocalDate localDate = LocalDate.now();
        OffsetDateTime now = OffsetDateTime.now();

        log("LOCAL DATE : " + localDate);
        log("%nOFFSET TIME : " + now);

        DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;
        DateTimeFormatter formatterLocalDate = DateTimeFormatter.ISO_DATE;

        log("%n" + formatter.format(now));
        log("%nCurrent Date into ISO date:" + formatterLocalDate.format(localDate));
    }

    private static void log(String format, Object... args) {

		System.out.format(format, args);
	}

}

