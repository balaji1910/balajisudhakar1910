// ISO standard - Format and print current date into ISO date format

package com.ofs.training;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

public class ISODate {

    public static void main(String[] args) {
        LocalDate localDate = LocalDate.now();
        OffsetDateTime now = OffsetDateTime.now();

        System.out.println("LOCAL DATE : " + localDate);
        System.out.println("OFFSET TIME : " + now);

        DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;
        DateTimeFormatter formatterLocalDate = DateTimeFormatter.ISO_DATE;

        System.out.println(formatter.format(now));
        System.out.println(formatterLocalDate.format(localDate));
    }
}
