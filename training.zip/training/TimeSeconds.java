// Print the current time in milliseconds and nanoseconds

package com.ofs.training;

public class TimeSeconds {

    public static void main(String[] args) {
        System.out.println(System.nanoTime());
        System.out.println(System.currentTimeMillis());
    }
}
