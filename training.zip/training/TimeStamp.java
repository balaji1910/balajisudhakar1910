// Create and print the time stamp for current date

package com.ofs.training;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;

public class TimeStamp {

    private void timeStampShow() {

        Timestamp timestampMilli = new Timestamp(System.currentTimeMillis());
        Timestamp timestamp = new Timestamp(0);
        Timestamp timestampNano = new Timestamp(System.nanoTime());

        System.out.println("time stamp in milli = " + timestampMilli);
        System.out.println("time stamp = " + timestamp);
        System.out.println("time stamp in nano = " + timestampNano);

        Date date = new Date();
        System.out.println("current date = " + Timestamp.from(Instant.now()));
		  
        System.out.println("date = " + date);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd - :  HH.mm.ss");
        System.out.println("formatted date = " + sdf.format(date));
    }

    public static void main(String[] args) {
        TimeStamp stampObj = new TimeStamp();
        stampObj.timeStampShow();
    }
}
