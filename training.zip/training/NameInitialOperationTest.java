package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class NameInitialOperationTest {
    
    NameInitialOperation initial;
    
    @BeforeClass
    private void baseClass(){
        initial = new NameInitialOperation();
    }        

    @Test(dataProvider ="testFindIntial_positiveDP")
    private void testFindIntial_positive(String name, String expectedResult) {
        
        try{
            String result = initial.findIntial(name);
            Assert.assertEquals(result, expectedResult,"Given input " + name);
            
        } catch (Exception e) {
            Assert.fail("Unexpected exception for input "
                    + name
                    + ". Expected result is "
                    + expectedResult
                    + ".",
                    e);
        }
        
    }
    
    @DataProvider
    private Object[][] testFindIntial_positiveDP() {
        return new Object[][] {
                                {"BalajiSudhakar","BS"},
                                {"Brindha Devi","BD"}
        };
    }
    
    @Test
    private void testFindIntial_negative(){
        
        try {
              initial.findIntial(null);
                Assert.fail("Expected an exception.");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Initial can not be find for null");
            
        }
    }
}
