// Addition/Update/Deletion of element to and from collections (addAll(), removeAll, add(), remove(), size())
// Contains
package com.ofs.training;

import java.time.chrono.IsoChronology;
import java.util.ArrayList;
import java.util.List;

public class ListOperation {

    public List<Person> addPerson(List<Person> roster) {

        List<Person> newRoster = new ArrayList<>();
        newRoster.add(new Person("John", IsoChronology.
                                  INSTANCE.date(1980, 6, 20),
                                  Person.Sex.MALE,
                                  "john@example.com"));
        newRoster.add(new Person("Jade",IsoChronology.
                                  INSTANCE.
                                  date(1990, 7, 15),
                                  Person.Sex.FEMALE,
                                  "jade@example.com"));
        newRoster.add(new Person("Donald",IsoChronology.
                                  INSTANCE.
                                  date(1991, 8, 13),
                                  Person.Sex.MALE,
                                  "donald@example.com"));
        newRoster.add(new Person("Bob",IsoChronology.
                                  INSTANCE.date(2000, 9, 12),
                                  Person.Sex.MALE,
                                  "bob@example.com"));

        roster.addAll(newRoster);
        System.out.format("%s%n", roster);
        System.out.println(roster.size());
        roster.removeAll(newRoster);

        return newRoster;

    }

    private void removePerson(List<Person> roster) {
        roster.removeAll(roster);
        System.out.format("%s%n", roster);
    }

    private boolean checkIfContains(List<Person> roster, Person person) {
        return roster.contains(person);
    }

    public static void main(String[] args) {
        ListOperation person = new ListOperation();
        List<Person> roster = Person.createRoster();
        person.addPerson(roster);
        person.removePerson(roster);

        Person bob = new Person("Bob",IsoChronology.
                                INSTANCE.date(2000, 9, 12),
                                Person.Sex.MALE,
                                "bob@example.com");
                                roster.add(bob);

        System.out.println(roster.size());
        boolean result = person.checkIfContains(roster, bob);
        System.out.println(result);
    }
}
