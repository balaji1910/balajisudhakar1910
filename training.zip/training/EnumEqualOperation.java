package com.ofs.training;

public class EnumEqualOperation {
	
	enum Gender {
		
		male,
		female,
		transgender
	}

	private static final String ERR_CODE = "error";
	
	public boolean equalOperator(Gender genderType1, Gender genderType2 ) {
		
		if(genderType1 == null || genderType2 == null) {
			throw new RuntimeException("Null value found in the parameter");
		}
		
		try {
			return (genderType1 == genderType2);
		} catch(Exception e) {
			throw new RuntimeException(ERR_CODE);
		}
	}
	
	public boolean equalMethod(Gender genderType1, Gender genderType2) {
		
		if(genderType1 == null || genderType2 == null) {
			throw new RuntimeException("Null value found in the parameter");
		}
		
		try {
			return (genderType1.equals(genderType2));
		} catch(Exception e) {
			throw new RuntimeException(ERR_CODE); 
		}
	}	

	public static void main(String[] args) {
		
		EnumEqualOperation enumEqual = new EnumEqualOperation();
		enumEqual.equalOperator(Gender.male, Gender.female);
	}
}
