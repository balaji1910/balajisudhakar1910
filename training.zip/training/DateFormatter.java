// Formatting current date to following formats: 2001-07-04T12:08:56.235-0700 and 2001.07.04 at 12:08:56 PDT

package com.ofs.training;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class DateFormatter {

    public void getDateFormatted() {

        LocalDateTime localdatetime = LocalDateTime.now();
        DateTimeFormatter localformatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
        String formatedDate = localdatetime.format(localformatter);
        log(formatedDate);

        ZoneId id = ZoneId.of("America/Los_Angeles");
        ZonedDateTime zone = ZonedDateTime.now(id);
        String date = DateTimeFormatter.ofPattern("yyyy.MM.dd 'at' hh:mm:ss z").format(zone);
        log(date);
    }

    private static void log(String format, Object... args) {

		System.out.format(format, args);
	}

    public static void main(String[] args) {

        DateFormatter obj = new DateFormatter();
        obj.getDateFormatted();
    }
}
