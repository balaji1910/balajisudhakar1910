package com.ofs.training;

import javax.management.RuntimeErrorException;

public class ResultValue {

	public String typeFinder(Object obj) {

		if (obj instanceof Integer) {
			return "int";
		}
		if (obj instanceof Float) {
			return "float";
		}
		if (obj instanceof Double) {
			return "double"; 
		}
		return null;
	}

	public String divide(int dividend, int divisor)throws Exception {
		
    	if (divisor == 0) {
    		throw new RuntimeException("Can not divide by zero");
    	}
        Object obj = dividend / divisor ;
        return typeFinder(obj);
	}

	public String divide1(double dividend, double divisor) {

		if (divisor == 0) {
    		throw new RuntimeException("Can not divide by zero");
    	}
		Object obj = dividend / divisor;
		return typeFinder(obj);
	}
}
