package com.ofs.training;

import java.io.FileInputStream;
import java.io.InputStream;

public class FileStream {  
    public static void main(String args[]){
        try {    
            InputStream stream = new FileInputStream("D:/dev/training/madhumitha.g/wbs/make.a.call/wbs.txt");
            int i;
            while((i = stream.read())!= -1) {
                System.out.print((char)i);
            }

            stream.close();    
        } catch(Exception e) {
            System.out.println(e);
        }
    }    
}
