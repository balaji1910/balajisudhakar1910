//map
//    - Write a program to print minimal person with name and email address from the Person class using java.util.Stream<T>#map API

package com.ofs.training;

import java.util.List;

public class MinimalPerson {

    private String name;
    private String emailId;

    private static MinimalPerson toMinimalList(Person person) {

        MinimalPerson detail = new MinimalPerson();
        detail.setName(person.getName());
        detail.setEmailId(person.getEmailAddress());
        return detail;
    }

    private String setEmailId(String mailId) {
        return this.emailId;
    }

    private String setName(String personName) {
        return this.name;
    }

    private void run() {

        List<Person> roster = Person.createRoster();
        roster.stream()
              .map(MinimalPerson::toMinimalList)
              .forEach(person -> System.out.println(person));
    }

    @Override
    public String toString() {
        return "PersonDetail [name=" + name + ", emailId=" + emailId + "]";
    }

    public static void main(String[] args) {

        MinimalPerson personDetail = new MinimalPerson();
        personDetail.run();
    }
}
