package com.ofs.training;

import java.time.Clock;
import java.time.Instant;
import java.util.Calendar;
import java.util.Date;

public class MilliNanoSeconds {

	private void printSecond() {
		
		Instant instant = Instant.now();
		log("%d", instant.getNano());

//		LocalDateTime localDateTime = LocalDateTime.now();
//		log("%d", localDateTime.getM)
	
//		Clock clock = Clock.m 
//		log("%d", Clock.millis();

		Date date = new Date();
		log("%n%d", date.getTime());
		
		Calendar calendar = Calendar.getInstance();
		log("%n%d", calendar.getTimeInMillis());
	}
	
	public static void main(String[] args) {
		
		MilliNanoSeconds milliNanoSeconds = new MilliNanoSeconds();
		milliNanoSeconds.printSecond();
	}

	private static void log(String format, Object... args) {

		System.out.format(format, args);
	}
}
