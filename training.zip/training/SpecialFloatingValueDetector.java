package com.ofs.training;

public class SpecialFloatingValueDetector {

    public static void main(String[] args) {

        Double x = new Double(2.0 / 0.0);
        Double y = new Double(0.0 / 0.0);

     // returns false if this Double value is not a Not-a-Number (NaN)
     System.out.println(y + " = " + y.isNaN());

     // returns true if this Double value is a Not-a-Number (NaN)
     System.out.println(x + " = " + x.isNaN());
    }
}
