package com.ofs.training;

import java.util.List;
import java.util.stream.Collectors;

public class FilterPerson {

    public static void main(String[] args) {

        List<Person> roster = Person.createRoster();

        List<Person> person = roster.stream()
                                    .filter(p -> { return p.getAge() > 21 && p.getGender() == Person.Sex.MALE; })
                                    .collect(Collectors.toList());

        for (Person name : person) {
            System.out.println(name.getName());
        }
    }
}
