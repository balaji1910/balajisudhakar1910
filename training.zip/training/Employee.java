package com.ofs.training;

// class Employee {
public class Employee {

    static int id = 0;
    String name;

    // Employee(){
    Employee(int id, String name) {

        // Initialize id and name
        // Auto increment id by its previous id
        this.id = Math.incrementExact(id);
        this.name = name;
    }

    public String toString() {
        return(id + " " + name);
    }

    // static execute(){
    public static void main(String[] args) {

        // Employee name = getEmployee();
        // Console console = getConsole();
        // console.print(id, name.toString());
        Employee karthi = new Employee(id, "karthi");
        System.out.println(karthi);

        Employee brindha = new Employee(id, "brindha");
        System.out.println(brindha);

        Employee balaji = new Employee(id, "balaji");
        System.out.println(balaji);

        Employee deborah = new Employee(id, "deborah");
        System.out.println(deborah);

        Employee deepika = new Employee(id, "deepika");
        System.out.println(deepika);

        Employee alisha = new Employee(id, "alisha");
        System.out.println(alisha);

        Employee hariPriya = new Employee(id, "hariPriya");
        System.out.println(hariPriya);

        Employee rahul = new Employee(id, "rahul");
        System.out.println(rahul);

        Employee surya = new Employee(id, "surya");
        System.out.println(surya);

        Employee vijay = new Employee(id, "vijay");
        System.out.println(vijay);
    }
}
