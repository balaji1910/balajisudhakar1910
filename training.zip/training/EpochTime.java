// Print the Epoch time

package com.ofs.training;

import java.time.Instant;

public class EpochTime {

	public static void main(String[] args) {

		EpochTime timestamp = new EpochTime();
		timestamp.timeStampDemo();
	}

	private void timeStampDemo() {

        Instant epochDate= Instant.EPOCH;
        log("EPOCH : %s%n", epochDate);

        Instant instant = Instant.now();
        log("instant time : %s", instant.getEpochSecond());
        
        long milli = instant.toEpochMilli();
        log("%nEPOCH LOCAL MILLI : " + milli);
    }

	private static void log(String format, Object... args) {

		System.out.format(format, args);
	}
}
