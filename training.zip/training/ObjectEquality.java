package com.ofs.training;

// Class ObjectEquality {
public class ObjectEquality {

    //static execute(){
    public static void main(String[] args) {

        // Class firstObject = "data"
        String queens = new String("We will rock you");

        // Class secondObject = "data"
        String rapsody = new String("We will rock you");

        // output = firstObject == secondObject
        boolean output = (queens == rapsody);

        // result = firstObject.equals(secondObject)
        boolean result = queens.equals(rapsody);

        // Console console = getConsole()
        // console.print(output)
        System.out.println(output);

        // Console console = getConsole()
        // console.print(result)
        System.out.println(result);
    }
}
