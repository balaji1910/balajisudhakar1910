package com.ofs.training;

import java.util.ArrayList;
import java.util.List;

public class ArrayCollectionConversion {

	private void arrayToCollectionConverter() {
		
		String[] names = new String[] {"Balaji", "Karthi", "ArvindKrishna"};
		List<String> name = new ArrayList<>();
		
	}
	
	public static void main(String[] args) {
		
		ArrayCollectionConversion arrayCollectionConversion = new ArrayCollectionConversion();
		arrayCollectionConversion.arrayToCollectionConverter();
	}

	private static void log(String format, Object... args) {

		System.out.format(format, args);
	}

	
}
