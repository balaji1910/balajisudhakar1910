package com.ofs.training;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayCollectionConversion {

	public static void main(String[] args) {
		
		ArrayCollectionConversion arrayCollectionConversion = new ArrayCollectionConversion();
		arrayCollectionConversion.arrayToCollectionConverter();
		arrayCollectionConversion.collectionToArray();
	}

	private void arrayToCollectionConverter() {
		
		String[] names = new String[] {"Balaji", "Karthi", "ArvindKrishna"};
		List<String> name = Arrays.asList(names);
		log("Array to Collection Converter : %s", name);
	}
	
	private void collectionToArray() {
		
		List<String> studentName = new ArrayList<>();
		studentName.add("Brindha");
		studentName.add("Deborah");
		studentName.add("Deepika");
		Object[] womanName = studentName.toArray();
		for (Object object : womanName) {
		log("%nCollection to Array Converter : %s", object);
		}
	}
	
	private static void log(String format, Object... args) {

		System.out.format(format, args);
	}
}
