package com.ofs.training;

//class OpenSourceFile {
public class OpenSourceFile {

    // static void execute() {
    public static void main(String[] args) throws Exception{

        // OpenSourceFile currentProgram = getCurrentProgram()
        OpenSourceFile currentProgram = new OpenSourceFile();

        // Class currentClass = currentProgram.getClass()
        Class currentClass = currentProgram.getClass();

        // File currentClassSourceFile = currentClass.getFile()
        // String filePath = currentClassSourceFile.getAbsolutePath()
        String filePath = currentClass.getProtectionDomain().getCodeSource().getLocation().getFile();

        // String notepad = notepadPath()
        String notepadPath = "D:/tools/Notepad++/notepad++.exe ";

        // String sourceFilePath = filePath + currentClass.getName() + extension
        String sourceFilePath =  filePath + currentClass.getName() + ".java";

        // String path = notepadPath + sourceFilePath.substring()
        String path = notepadPath + sourceFilePath.substring(1);

        // Process process = Runtime.getRuntime().execution()
        Process process = Runtime.getRuntime().exec(path);
    }
}
