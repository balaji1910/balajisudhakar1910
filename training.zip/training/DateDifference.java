// Date difference - Find the difference between two dates.

package com.ofs.training;

import java.time.LocalDate;
import java.time.Period;

public class DateDifference {

    public void dateDifferenceFinder() {

        LocalDate initialDate = LocalDate.of(2017, 8, 24);
        LocalDate finalDate = LocalDate.now();

        LocalDate currentDate = LocalDate.now();

        Period diff = Period.between(initialDate, currentDate);
        Period diffFinal = Period.between(initialDate, finalDate);

        log("Difference is %d days, %d months and %d years old", diff.getDays()
                                                               , diff.getMonths()
                                                               , diff.getYears());

        log("\nDifference is %d days, %d months and %d years old", diffFinal.getDays()
                                                                 , diffFinal.getMonths()
                                                                 , diffFinal.getYears());
    }

	private static void log(String format, Object... args) {

		System.out.format(format, args);
	}

    public static void main(String[] args) {

        DateDifference dateObj = new DateDifference();
        dateObj.dateDifferenceFinder();
    }
}
