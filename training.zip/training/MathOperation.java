package com.ofs.training;

public class MathOperation {

	private static final String ERR_DIVIDE_BY_ZERO = "cannot divide by 0";

	public int divide(int dividend, int divisor) {

		if (divisor == 0) {
			throw new RuntimeException(ERR_DIVIDE_BY_ZERO);
		}
		return (dividend/divisor);
	}
}
