package com.ofs.training;

public class Base5Operation {

   public static void main(String[] args) {
       String base5Number = "230";
       int result = Integer.valueOf(base5Number, 5);
       System.out.println(result);
    }
}
