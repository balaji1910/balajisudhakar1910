//6. Reducer methods(ToInt, ToLong)
//    - Write a program to find the average age of all the Person in the person List

package com.ofs.training;

import java.util.List;

public class AgeCalculator {

    private double personStream(List<Person> person) {
        double average =  person.stream()
                                 .mapToDouble(Person::getAge)
                                 .average()
                                 .getAsDouble();
        return average;
    }

    public static void main(String args[]) {

        List<Person> person = Person.createRoster();
        AgeCalculator age = new AgeCalculator();
        System.out.println(age.personStream(person));
    }
}

