// 4. For a given year, print the length of each month within that year
package com.ofs.training;

import java.time.Year;

public class LengthPrinter {

	public static void main(String[] args) {

		LengthPrinter lengthPrinter = new LengthPrinter();
		lengthPrinter.printLength();
	}

	private void printLength() {

		Year year = Year.now();
		for(int index = 1; index <= 12; index++)
			log("Number of days in %s month : %d %n",year.atMonth(index).getMonth(), year.atMonth(index).lengthOfMonth());
	}

	private static void log(String year, Object... args) {

		System.out.format(year, args);
	}
}
