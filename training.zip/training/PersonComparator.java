//lambda
// - sort the roster list based on the person's age in descending order using comparator

package com.ofs.training;

import java.util.Comparator;
import java.util.List;

public class PersonComparator {

    public static void main(String[] args) {
        List<Person> persons = Person.createRoster();
        Comparator<Person> comparator = Comparator.comparing(p -> p.getAge());
        persons.sort(comparator.reversed());
        persons.forEach(System.out::println);
    }
}
