package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.ofs.training.EnumOperation.Day;

public class EnumOperationTest {

	EnumOperation enumDay;

	@BeforeClass
	private void initClass() {
		
		enumDay = new EnumOperation();
	}	
	
	@Test
	private void testEqualOperator_positive1() {
		
		boolean expectedResult = true;
		Day weeklySunday = Day.SUN;
		Day monthlySunday = Day.SUN;
		boolean actualResult = enumDay.equalOperator(weeklySunday, monthlySunday);
		if (actualResult == expectedResult) {
			Assert.assertEquals(actualResult, expectedResult, "Given input " + weeklySunday + ", " + monthlySunday + "," );
		} else {
			Assert.fail("Unexpected exception for input " 
					+ weeklySunday
					+ " , "
					+ monthlySunday
					+ " , "
					+ "Expected result is "
					+ expectedResult );
		}
	}

	@Test
	private void testEqualOperator_positive2() {
	
		boolean expectedResult = true;
		Day weeklySunday = Day.SUN;
		Day monthlySunday = Day.SUN;
		boolean actualResult = enumDay.equalOperator(weeklySunday, monthlySunday);
		if (actualResult == expectedResult) {
			Assert.assertEquals(actualResult, expectedResult, "Given input " + weeklySunday + ", " + monthlySunday + "," );
		} else {
			Assert.fail("Unexpected exception for input "
					+ weeklySunday
					+ " , "
					+ monthlySunday
					+ " , "
					+ "Expected result is "
					+ expectedResult );
		}
	}
	
	@Test
	private void testEqualMethod_positive1() {
		
		boolean expectedResult = true;
		Day weeklyThursday = Day.THUR;
		Day monthlyThursday = Day.THUR;
		boolean actualResult = enumDay.equalMethod(weeklyThursday, monthlyThursday);
		if (actualResult == expectedResult) {
			Assert.assertEquals(actualResult, expectedResult, "Given input " + weeklyThursday + ", " + monthlyThursday + "," );
		}	else {
			Assert.fail("Unexpected exception for input "
					+ weeklyThursday
					+ " , "
					+ monthlyThursday
					+ " , "
					+ "Expected result is "
					+ expectedResult );
		}
	}
	
	@Test
	private void testEqualMethod_positive2() {
		
		boolean expectedResult = true;
		Day weeklyThursday = Day.THUR;
		Day monthlyThursday = Day.THUR;
		boolean actualResult = enumDay.equalMethod(weeklyThursday, monthlyThursday);
		if (actualResult == expectedResult) {
			Assert.assertEquals(actualResult, expectedResult, "Given input " + weeklyThursday + ", " + monthlyThursday + "," );
		}	else {
			Assert.fail("Unexpected exception for input "
					+ weeklyThursday
					+ " , "
					+ monthlyThursday
					+ " , "
					+ "Expected result is "
					+ expectedResult );
		}
	}
}
