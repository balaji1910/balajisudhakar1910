//4. Sum/Max/Min
//    - Consider a following code snippet:
//        List<Integer> randomNumbers = Array.asList({1, 6, 10, 25, 78})
//    - Find the sum of all the numbers in the list using java.util.Stream API
//    - Find the maximum of all the numbers in the list using java.util.Stream API
//    - Find the minimum of all the numbers in the list using java.util.Stream API

package com.ofs.training;

import java.util.Arrays;
import java.util.List;

public class NumberOperation {

    List<Integer> randomNumbers = Arrays.asList(1, 6, 10, 25, 78);

    private int minimumFinder() {

        return randomNumbers.
               stream().
               mapToInt(Integer :: intValue).
               min().getAsInt();
    }

    private int maximumFinder() {

        return randomNumbers.
                stream().
                mapToInt(Integer :: intValue).
                max().
                getAsInt();
    }

    private int sumFinder() {

        return randomNumbers.
               stream().
               mapToInt(Integer :: intValue).
               sum();
    }

    public static void main(String[] args) {

        NumberOperation calculate = new NumberOperation();
        System.out.format("%d%n", calculate.minimumFinder());
        System.out.format("%d%n", calculate.maximumFinder());
        System.out.format("%d%n", calculate.sumFinder());
    }
}
