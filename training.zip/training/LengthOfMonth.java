// For a given year, print the length of each month within that year

package com.ofs.training;

import java.time.Month;
import java.time.YearMonth;

public class LengthOfMonth {
    public static void main(String[] args) {

//    LocalDate date = LocalDate.now();
//    System.out.printf("%s: %d%n%n", date, date.lengthOfMonth());

        for (int month = 1; month <= 12; month++) {
            YearMonth yearMonth = YearMonth.of(2018, Month.of(month));
            System.out.printf("%s: %d%n", yearMonth, yearMonth.lengthOfMonth());
        }
    }
}
