// Print the time taken for the current method execution using Timer API

package com.ofs.training;

public class TimeLapse {

    private void timeFinder() {
        long startTime = System.currentTimeMillis();
        System.out.println(startTime);

        for (int i = 0; i < 10000; i++) {
            System.out.println();
        }

        long endTime = System.currentTimeMillis();
        System.out.println(endTime);

        long timeTaken = endTime - startTime;
        System.out.println(timeTaken);
    }

    public static void main(String[] args) {
        TimeLapse timeLapse = new TimeLapse();
        timeLapse.timeFinder();
    }
}
