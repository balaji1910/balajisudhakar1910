//Write a program to filter the Person, who are male and
//        - find the first person from the filtered persons
//        - find the last person from the filtered persons
//        - find random person from the filtered persons

package com.ofs.training;

import java.util.List;
import java.util.stream.Collectors;

import com.ofs.training.Person.Sex;

public class DisplayPerson {

    public static void main(String[] args) {

        List<Person> roster = Person.createRoster();

        List<Person> findName = roster.stream()
                                      .filter(person -> { return person.getGender() == Sex.MALE; } )
                                      .collect(Collectors.toList());

         findName.stream()
        .findFirst()
        .ifPresent(System.out::println);

         findName.stream()
        .findAny()
        .ifPresent(System.out::println);

         System.out.println(findName.get(findName.size() - 1));
    }
}
