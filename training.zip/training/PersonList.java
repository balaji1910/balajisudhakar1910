//Print all the persons in the roster using java.util.Stream<T>#forEach

package com.ofs.training;

import java.util.List;

public class PersonList {

	private List<Person> printList(List<Person> persons) {
		persons.stream()
			   .map(Person::getName)
			   .forEach(person -> System.out.println(person));
		return persons;
	}

	public static void main(String[] args) {
		List<Person> persons = Person.createRoster();
		PersonList list = new PersonList();
		list.printList(persons);
	}
}
