package com.ofs.training;

public class NameInitialOperation {

	public String findIntial(String name) {
	
		if (name == null) {
			throw new RuntimeException("Initial can not be find for null");
		}
		String[] fullName = new String[20];
		fullName = name.split(" ");
		String result;
		String finalResult = " ";
		String inital = " " ;
		
		for(String arr1 : fullName ) {
			result = (arr1.substring(0,1));
			inital = inital.concat(result);
			finalResult = inital.trim();
		} 
		//System.out.println(finalResult);
		return finalResult;
	}
}
