package com.ofs.training;

// class VariableArgument {

    // static soccer {
        // Console console = getConsole()
        // console.print(playerName)

        // for loop (String variable : argument)

        // Console console = getConsole()
        // console.print(variable)
    // }

    // static void execute() {
        // soccer("Data")
        // soccer("more than one data")
//}

public class VarArgs {

    static void soccer(String... playerName) {

        System.out.println("Name of players:");
        for (String englandPlayerName : playerName)
        System.out.println(englandPlayerName);
    }

    public static void main(String[] args) {
        soccer("Jesse Lingard");
        soccer("Dele Ali", "Harry Kane", "Ashley Young", "Wayne Rooney");
        //soccer();
    }
}
