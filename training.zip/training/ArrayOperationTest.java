package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ArrayOperationTest {

    ArrayOperation arrayOperation;

    
    @BeforeClass
    private void initClass() {

        arrayOperation = new ArrayOperation();
    }
    
    
    @Test (dataProvider = "testArraySort_positive_DP")
    private void testArraySort_positive(String[] input,String[] expectedResult) {
    	
		

    	try {
    		String[] actualResult = arrayOperation.arraySort(input);
    		Assert.assertEquals(actualResult, expectedResult);
    	} catch (Exception e) {
            Assert.fail("Unexpected exception for input "
                        + ". Expected result is "
                        + expectedResult
                        + ".",
                        e);
        }
    }
    
    @DataProvider
    private Object[][] testArraySort_positive_DP() {
    	

		String[] arrayName = { "Madurai", "Thanjavur", "TRICHY", "Karur", "Erode", "trichy", "Salem" };

		String[] expectedResult = { "Erode", "Karur", "MADURAI", "Salem", "THANJAVUR", "TRICHY", "TRICHY" };

        return new Object[][] {
                                { arrayName, expectedResult }
        };                      
    }
    
    
    @Test
	private void testSort_negative() {
        
    	 try {
        	arrayOperation.arraySort(null); 
            Assert.fail("Expected an exception");
	     } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), null);
	     }
    }

}  
    
//    @DataProvider
//    private Object[][] testSort_positiveDP() {
//    	
//    	String[] actualArray = { "Madurai",
//      		  					 "Thanjavur",
//      		  					 "TRICHY",
//      		  					 "Karur",
//      		  					 "Erode",
//      		  					 "trichy",
//      		  					 "Salem" };
//
//        return new Object[][] {	
//        	actualArray
//        };
//    }
//}
