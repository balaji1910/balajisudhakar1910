package com.ofs.training;

import java.util.Arrays;

// class ArrayOperation {
public class ArrayOperation {
	
	// if needed, create a constant

	// TODO : sort ignoring case
	// int arraySort(String... arguments) {
	public String[] arraySort(String[] name) {
		
		String[] arr = new String[name.length];
		Arrays.sort(name, String.CASE_INSENSITIVE_ORDER);
		for (int index = 0; index < name.length; index++) {
	           
			if ((index % 2 == 0) && (index != 0)) { 
				arr[index] = (name[index].toUpperCase()); 
			} else { arr[index] = (name[index]); }
		}
		return arr;
	}
}
