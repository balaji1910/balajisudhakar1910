package com.ofs.training;

public class EnumOperation {
	
	enum Day { 		  

		MON,
		TUE,
		WED,
		THUR,
		FRI,
		SAT,
		SUN ;
	}
	
 private static final String ERR_NO_VALUES = "no values" ;
 
 public boolean equalOperator(Day day, Day anotherDay) {
	 
	 try {
		 boolean result = day.equals(anotherDay);
		 return result;
	 } catch(Exception e) {
		 throw new RuntimeException(ERR_NO_VALUES);
	 }
 } 
	 
	public boolean equalMethod(Day day1, Day day2) {
		
		try {
			boolean result = (day1 == day2);
			return result;
		} catch(Exception e) {
			throw new RuntimeException(ERR_NO_VALUES);
		  }
	}
}
	