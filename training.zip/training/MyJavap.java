package com.ofs.training;

import java.lang.reflect.Modifier;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class MyJavap {

    public static void modifierType(int mod) {

        if (Modifier.isPublic(mod)) {

            System.out.print(" public");
        }
        if (Modifier.isPrivate(mod)) {

            System.out.print(" private");
        }
        if (Modifier.isProtected(mod)) {

            System.out.print(" protected");
        }
        if (Modifier.isNative(mod)) {

            System.out.print(" native");
        }
        if (Modifier.isFinal(mod)) {

            System.out.print(" final");
        }
        if (Modifier.isStatic(mod)) {

            System.out.print(" static");
        }
        if (Modifier.isAbstract(mod)) {

            System.out.print(" abstract");
        }
        if (Modifier.isInterface(mod)) {

            System.out.print(" interface");
        }
        if (Modifier.isStrict(mod)) {

            System.out.print(" strict");
        }
        if (Modifier.isSynchronized(mod)) {

            System.out.print(" synchronized");
        }
        if (Modifier.isTransient(mod)) {

            System.out.print(" transient");
        }
        if (Modifier.isVolatile(mod)) {

            System.out.print(" volatile");
        }
    }

    // static execute(className) {
    public static void main(String[] args) {

        try {

            Class currentClass = Class.forName(args[0]);

            // Class currentClass = className.getClass();
            // Class currentClass = currentProgram.getClass();

            // Modifier[] classModifier = currentClass.getModifiers();
            // console.print(classModifier.getName() + currentClass.getName());
            int modifierName = currentClass.getModifiers();

            modifierType(modifierName);
            System.out.print(" " + currentClass.getName());

            // Interface[] classInterface = currentClass.getInterfaces();
            Class[] classInterface = currentClass.getInterfaces();

            System.out.print(" implements ");
    
            // console.printSeperatedByComma(classInterface.getName());
            for (Class interfaceName : classInterface) {
               System.out.print(interfaceName.getName() + ", ");
            }

            System.out.println("{");
    
            // Field[] classField = currentClass.getFields();
            Field[] classField = currentClass.getFields();
            // console.printNewLine(fieldModifier.getName() + fieldType.getName() + classField.getName());
            for (Field fieldName : classField) {
    
                // Modifier[] fieldModifier = classField.getModifiers();
                int fieldModifier = fieldName.getModifiers();
                // Type[] fieldType = classField.getType();
                Class fieldType = fieldName.getType();
    
                System.out.println();
                modifierType(fieldModifier);
                System.out.print(" " + fieldType.getName() + " " + fieldName.getName());
                System.out.println(";");
            }
    
            // Constructor[] classConstructor = currentClass.getConstructors();
            Constructor[] classConstructor = currentClass.getConstructors();
    
            // console.printNewLine(constructorModifier.getName() + classConstructor.getName());
    
            for (Constructor constructorName : classConstructor) {
    
                // Modifier[] constructorModifier = classConstructor.getModifiers();
                int constructorModifier = constructorName.getModifiers();
    
                System.out.println();
                modifierType(constructorModifier);
                System.out.print(" "  + constructorName.getName() + "(");
    
                // ParameterType[] constructorParameter = classMethod.getParameterType();
                Class[] constructorParameter = constructorName.getParameterTypes();
    
                for (Class constructorParameterName : constructorParameter) {
    
                    System.out.print(constructorParameterName.getTypeName() + ", ");
                }
                System.out.print(")");
                
                Class[] exceptionType = constructorName.getExceptionTypes();
                
                for (Class exception : exceptionType) {
                	
                	System.out.print(exception.getTypeName());
                }
                System.out.print(";");
                
            }
            System.out.println();
    
            // Method[] classMethod = currentClass.getMethods();
            Method[] classMethod = currentClass.getDeclaredMethods();
    
            // Modifier[] methodModifier = classMethod.getModifiers();
            
            // ReturnType[] methodReturnType = classMethod.getReturnType();
            // ParameterType[] methodParameter = classMethod.getParameterType();
            // console.printNewLine(methodModifier.getName() + methodReturnType.getName() 
                                                        // + classMethod.getName()
                                                        // + methodParameter.getName());
            for (Method methodName : classMethod) {
    
                int methodModifier = methodName.getModifiers();
                modifierType(methodModifier);
                
                Class returnType = methodName.getReturnType();
                System.out.print(" " + returnType.getTypeName() + " " + methodName.getName() + "(");
    
                Class[] methodParameter = methodName.getParameterTypes();
    
                for (Class methodParameterType : methodParameter) {
                    System.out.print(methodParameterType.getTypeName() + ", ");
                }
                System.out.print(")");
                
                Class[] methodExceptionType = methodName.getExceptionTypes();
                
                for (Class methodException : methodExceptionType) {
                	
                	System.out.print(methodException.getTypeName());
                }
                System.out.println(";");
            }
        } catch(ClassNotFoundException e) {
            System.out.println("null");
        }
    }

}
