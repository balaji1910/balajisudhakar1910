// to read the file

package com.ofs.training;

import java.io.InputStream;

public class FileRead {

    private static String source = "ArrayOperation.java";

    public static void main(String[] args) throws Exception{

        FileRead fileRead = new FileRead();
        fileRead.Reader();
    }

    public void Reader() throws Exception {

        InputStream file = getClass().getClassLoader().getResourceAsStream(source);
        file.read();
        System.out.println("Reading the file using InputStream");
        file.close();
    }
}
