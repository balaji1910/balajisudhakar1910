package com.objectfrontier.training.webservice.servlet.test;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.webservice.pojo.Address;
import com.objectfrontier.training.webservice.pojo.Person;
import com.objectfrontier.training.webservice.utils.HttpMethod;
import com.objectfrontier.training.webservice.utils.JsonUtil;
import com.objectfrontier.training.webservice.utils.RequestHelper;


public class PersonServletTest {

    RequestHelper requestHelper;

    @BeforeClass()
    private void setup() throws Exception {
        requestHelper = new RequestHelper();
    }

    @Test(priority = 3, dataProvider = "testDoGetPositiveDP")
    private void testDoGetPositive(String url, Person expected) throws Exception {
    	
            Person actual = requestHelper.setMethod(HttpMethod.GET).requestObject(url, Person.class);
            Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
    }

    @DataProvider
    private Object[][] testDoGetPositiveDP() {
    	
    	Person firstPerson = new Person();
        firstPerson.setFirstName	("Balaji");
        firstPerson.setLastName		("Sudhakar");
        firstPerson.setEmail		("balaji.sudhakar@object-frontier.com");
        firstPerson.setBirthDate	(Date.valueOf("1996-10-19"));
        
    	Address firstAddress = new Address();
		firstAddress.setStreet		("7th Cross Street");
		firstAddress.setCity		("Chennai");
		firstAddress.setPostalCode	(600040);
		
		Person secondPerson = new Person();
		secondPerson.setFirstName	("Brad");
		secondPerson.setLastName	("Pitt");
		secondPerson.setEmail		("brad.pitt1812@gmail.com");
		secondPerson.setBirthDate	(Date.valueOf("1963-12-18"));
        
		Address secondAddress= new Address();
		secondAddress.setStreet		("Gandhi Street");
		secondAddress.setCity		("Chennai");
		secondAddress.setPostalCode	(600050);
		
		Person thirdPerson = new Person();
		thirdPerson.setFirstName	("Hugh");
		thirdPerson.setLastName		("Jackman");
		thirdPerson.setEmail		("hughjackman1210@gmail.com");
		thirdPerson.setBirthDate	(Date.valueOf("1968-10-12"));
        
		Address thirdAddress= new Address();
		thirdAddress.setStreet		("Nehru Street");
		thirdAddress.setCity		("Thiruvallur");
		thirdAddress.setPostalCode	(600001);
		
		Person fourthPerson = new Person();
		fourthPerson.setFirstName	("Ryan");
		fourthPerson.setLastName	("Reylonds");
		fourthPerson.setEmail		("ryanreylonds2310@object-frontier.com");
		fourthPerson.setBirthDate	(Date.valueOf("19976-10-23"));
        
		Address fourthAddress= new Address();
		fourthAddress.setStreet    	("Bose Street");
		fourthAddress.setCity      	("Chennai");
		fourthAddress.setPostalCode	(600101);
        
		return new Object[][] {
			{ "http://localhost:8080/webservice/Person", firstPerson },
			{ "http://localhost:8080/webservice/Person", secondPerson },
			{ "http://localhost:8080/webservice/Person", thirdPerson },
			{ "http://localhost:8080/webservice/Person", fourthPerson }
		};    
    }

    @Test(dataProvider = "testReadAll", priority = 4)
    private void testReadAll(String uri, List<Person> expectedList) throws Exception {
            String personDetail = requestHelper.setMethod(HttpMethod.GET).requestString(uri);
            List<Person> Person = JsonUtil.toList(personDetail, Person.class);
            Assert.assertEquals(JsonUtil.toJson(Person), JsonUtil.toJson(expectedList));
    }

    @DataProvider
    private Object[][] testReadAll() {
        String uri = "http://localhost:8080/ws/person?include=true";

        return new Object[][] {
            {uri, }
        };
    }

    @Test(priority = 1, dataProvider = "testDoPutPositiveDP")
    private void testDoPutPositive(String url, Person person) throws Exception {
        
    	Person created = requestHelper.setMethod(HttpMethod.PUT)
    										.setInput(person)
    										.requestObject(url, Person.class);
        
//    	person.setId(createdPerson.getId());
        person.setAddress(created.getAddress());
//		Assert.assertEquals(JsonUtil.toJson(created), JsonUtil.toJson(person));
    }

    @DataProvider
    private Object[][] testDoPutPositiveDP() {
        
    	Person firstPerson = new Person();
        firstPerson.setFirstName	("Balaji");
        firstPerson.setLastName		("Sudhakar");
        firstPerson.setEmail		("balaji.sudhakar@object-frontier.com");
        firstPerson.setBirthDate	(Date.valueOf("1996-10-19"));
        
    	Address firstAddress = new Address();
		firstAddress.setStreet		("7th Cross Street");
		firstAddress.setCity		("Chennai");
		firstAddress.setPostalCode	(600040);
		
		Person secondPerson = new Person();
		secondPerson.setFirstName	("Brad");
		secondPerson.setLastName	("Pitt");
		secondPerson.setEmail		("brad.pitt1812@gmail.com");
		secondPerson.setBirthDate	(Date.valueOf("1963-12-18"));
        
		Address secondAddress= new Address();
		secondAddress.setStreet		("Gandhi Street");
		secondAddress.setCity		("Chennai");
		secondAddress.setPostalCode	(600050);
		
		Person thirdPerson = new Person();
		thirdPerson.setFirstName	("Hugh");
		thirdPerson.setLastName		("Jackman");
		thirdPerson.setEmail		("hughjackman1210@gmail.com");
		thirdPerson.setBirthDate	(Date.valueOf("1968-10-12"));
        
		Address thirdAddress= new Address();
		thirdAddress.setStreet		("Nehru Street");
		thirdAddress.setCity		("Thiruvallur");
		thirdAddress.setPostalCode	(600001);
		
		Person fourthPerson = new Person();
		fourthPerson.setFirstName	("Ryan");
		fourthPerson.setLastName	("Reylonds");
		fourthPerson.setEmail		("ryanreylonds2310@object-frontier.com");
		fourthPerson.setBirthDate	(Date.valueOf("19976-10-23"));
        
		Address fourthAddress= new Address();
		fourthAddress.setStreet    	("Bose Street");
		fourthAddress.setCity      	("Chennai");
		fourthAddress.setPostalCode	(600101);
        
		return new Object[][] {
			{ "http://localhost:8080/webservice/Person", firstPerson },
			{ "http://localhost:8080/webservice/Person", secondPerson },
			{ "http://localhost:8080/webservice/Person", thirdPerson },
			{ "http://localhost:8080/webservice/Person", fourthPerson }
		};
    }

    @Test(priority = 2, dataProvider = "testUpdate")
    private void testDoPostPositive(String url, Person person) throws Exception {

    		Person updated = requestHelper.setMethod(HttpMethod.POST)
        								  .setInput(person)
                    				   	  .requestObject(url, Person.class);
            
    		Assert.assertEquals(JsonUtil.toJson(updated), JsonUtil.toJson(person));
    }

    @DataProvider
    private Object[][] testUpdate() {

     	Person firstPerson = new Person();
     	firstPerson.setId			(1l);
        firstPerson.setFirstName	("Bruce");
        firstPerson.setLastName		("Wayne");
        firstPerson.setEmail		("brucewayne@brucewayne.com");
        firstPerson.setBirthDate	(Date.valueOf("1939-11-03"));
        
    	Address firstAddress = new Address();
    	firstAddress.setId			(1l);
		firstAddress.setStreet		("Wayne Enterprises");
		firstAddress.setCity		("Gotham");
		firstAddress.setPostalCode	(100001);
		
    	return new Object[][] {
    		{ "http://localhost:8080/webservice/Person", firstPerson }
        };
    }

    @Test(dataProvider = "testDoDeletePositiveDP")
	public void testDoDeletePositive(String url, Person person) throws Exception  {
		
		long actual = requestHelper.setMethod(HttpMethod.DELETE)
								   .setInput(person)
								   .requestObject(url, long.class);

		Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(person));
	}
	
	
	@DataProvider
	private Object[][] testDoDeletePositiveDP() {
		
		Person firstPerson = new Person();
		firstPerson.setId(1l);
		
		return new Object[][] {
			{ "http://localhost:8080/webservice/Address?id=4", firstPerson },
		};
	}
}
