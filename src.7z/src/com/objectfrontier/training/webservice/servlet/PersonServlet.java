package com.objectfrontier.training.webservice.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.training.webservice.main.AddressService;
import com.objectfrontier.training.webservice.main.AppException;
import com.objectfrontier.training.webservice.main.ConnectionManager;
import com.objectfrontier.training.webservice.main.PersonService;
import com.objectfrontier.training.webservice.pojo.Person;
import com.objectfrontier.training.webservice.utils.JsonUtil;

public class PersonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private PersonService personService = new PersonService(new AddressService());
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	    String id = request.getParameter("id");
	    String include = request.getParameter("include");
	    boolean includeAddress = Boolean.parseBoolean(include);
	    Connection connection = ConnectionManager.initConnection();

	    if (Objects.isNull(id)) {
	        try {
    	        List<Person> person = personService.readAll(connection, includeAddress);
    	        String personDetail = JsonUtil.toJson(person);
    	        getWriter(personDetail, response);
	        } catch (AppException exception) {
	            getWriter(JsonUtil.toJson(exception), response);
	        }
	    } else {
	        long personId = Long.parseLong(id);
	        try {
	            Person person = personService.read(connection, includeAddress, personId);
	            String personDetail = JsonUtil.toJson(person);
	            getWriter(personDetail, response);
	        } catch (AppException exception) {
	            getWriter(JsonUtil.toJson(exception), response);
	        }
	    }
	    ConnectionManager.releaseConnection(connection, true);
	}
	
	    @Override
	    protected void doDelete(HttpServletRequest request, HttpServletResponse response) 
	                         throws ServletException, IOException {

	        String id = request.getParameter("id");
	        long personId = Long.parseLong(id);
	        Connection connection = ConnectionManager.initConnection();
	        try {
                personService.delete(connection, personId);
                getWriter(personId + "deleted Successfully", response);
                ConnectionManager.releaseConnection(connection, true);
	        } catch (AppException exception) {
	            ConnectionManager.releaseConnection(connection, false);
	            getWriter(JsonUtil.toJson(exception), response);
	        }
	   }

	    @Override
	    protected void doPut(HttpServletRequest request, HttpServletResponse response) 
                throws ServletException, IOException {
	
	        BufferedReader reader = request.getReader();
	        List<String> jsonLines = reader.lines().collect(Collectors.toList());
	        String personJson = String.join("", jsonLines);
	        Person person = JsonUtil.toObject(personJson, Person.class);
	        Connection connection = ConnectionManager.initConnection();

	        try {
                Person createdPerson = personService.create(connection, person);
                String json = JsonUtil.toJson(createdPerson);
                ConnectionManager.releaseConnection(connection, true);
                getWriter(json, response);
            } catch (AppException exception) {
                ConnectionManager.releaseConnection(connection, false);
                getWriter(JsonUtil.toJson(exception), response);
            }
	    }

	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

            BufferedReader reader = request.getReader();
            List<String> jsonLines = reader.lines().collect(Collectors.toList());
            String personJson = String.join("", jsonLines);
            Person person = JsonUtil.toObject(personJson, Person.class);
            Connection connection = ConnectionManager.initConnection();

            try {
                Person createdPerson = personService.update(connection, person);
                String json = JsonUtil.toJson(createdPerson);
                ConnectionManager.releaseConnection(connection, true);
                getWriter(json, response);
            } catch (AppException exception) {
                ConnectionManager.releaseConnection(connection, false);
                getWriter(JsonUtil.toJson(exception), response);
            }
	    }

	    private void getWriter(String json, HttpServletResponse response) throws IOException {
	        PrintWriter writer = response.getWriter();
	        writer.println(json);
	        writer.close();
	    }
}
