package com.objectfrontier.training.webservice.main;

public enum ErrorCode {

    NO_RECORD_FOUND			(100, "Record not found"),
    SQL_EXCEPTION 			(101, "SQL Syntax or Server Error"),
    ADDRESS_ID_NOT_FOUND 	(102, "Address id column is empty"),
    ADDRESS_ID_ERROR    	(103, "Address id column is not auto generated"),
    STREET_FIELD_NOT_FOUND	(104, "Street field is empty"),
    CITY_FIELD_NOT_FOUND	(105, "City field is empty"),
    PINCODE_NOT_FOUND		(106, "Pincode is empty"),
    PINCODE_INVALID			(107, "Pincode is invalid"),

    PERSON_ID_NOT_FOUND		(108, "Person id column is empty"),
    FIRST_NAME_NOT_FOUND    (109, "First name field is empty"),
    LAST_NAME_NOT_FOUND		(110, "Last name field is empty"),
    DUPLICATE_NAME			(111, "Name already exist"),
    PERSON_ID_ERROR			(112, "Person id column is not auto incremented"),
    DUPLICATE_EMAIL			(113, "Duplicate email found"),
    EMAIL_NOT_FOUND			(114, "Email is empty"),
	ILLEGAL_DOB_FORMAT  	(115, "DOB should be in 'dd-mm-yyyy' format"),
	DOB_NOT_FOUND			(116, "DOB is empty"),

	CREATE_OPERATION_FAILED	(117, "Error in creating person"), 
    UPDATE_OPERATION_FAILED	(118, "Error in Updating person"), 
    DELETE_OPERATION_FAILED	(119, "Error in deleting person"),
    READ_OPERATION_FAILED	(120, "Error in reading person details"), 
    SEARCH_OPERATION_FAILED	(121, "Error in searching address details"), 
    READALL_OPERATION_FAILED(122, "Error in reading all person details"),

	CONNECTION_ERROR		(123, "Database connection error"), 
    DATASOURCE_ERROR		(124, "Datasource error"), 
    LOAD_JSON_ERROR			(125, "Error in loading json"), 
    STORE_JSON_ERROR		(126, "Error in storing json"), 
    UNKNOWN_ERROR			(127, "UnKnown error"),
	ENTER_VALID_INPUT		(128, "Error occured while parsing input"),
	PROPERTY_FILE_ERROR		(129, "Property file not loaded properly"), 
	EMPTY_INPUT				(130, "Input not given in URL"),
	INVALID_URL_INPUT		(131, "Error in entering input in URL"),
	
	AUTHENTICAION_FAILED 	(132, "Given credentials are wrong"),
	INVALID_EMAIL			(133, "Given email is empty"),
	INVALID_PASSWORD		(134, "Given password is empty"), 
	ACCESS_DENIED			(135, "User not an admin");

    private int errorCode;
    private String message;

    private ErrorCode(int errorCode, String message) {
        this.message = message;
        this.errorCode = errorCode;
    }

    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }

    public int getErrorCode() {
        return errorCode;
    }
    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }
    
    @Override
    public String toString() {
        return String.format("ErrorCode = %d, ErrorMessage = %s", errorCode, message);
    }
};
