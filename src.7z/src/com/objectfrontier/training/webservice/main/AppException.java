package com.objectfrontier.training.webservice.main;

import java.util.ArrayList;

public class AppException extends RuntimeException{

    private static final long serialVersionUID = -2182006191391350339L;

    private ArrayList<ErrorCode> errors;

    public AppException(ErrorCode errorCode) {
    	errors = new ArrayList<>();
    	errors.add(errorCode);
    }

    public AppException(ArrayList<ErrorCode> errors) {
      this.errors = errors;
  }

    public AppException(ErrorCode errorCode, Exception e) {
    	super(e);
    	errors = new ArrayList<>();
    	errors.add(errorCode);
    }

    public ArrayList<ErrorCode> getExceptionList() {
        return errors;
    }
}
