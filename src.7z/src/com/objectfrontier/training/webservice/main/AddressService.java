package com.objectfrontier.training.webservice.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.objectfrontier.training.webservice.pojo.Address;

public class AddressService {

//    Address address;
//    String resultSet;
//    ConnectionManager connectionManager; 
//    Connection connection = null;
    
    public Address create(Address address, Connection connection) {
    	
//      if (addressPojo.getId() == 0) {
//      	throw new RuntimeException("id cannot be null");
//  	}
    	ArrayList<ErrorCode> errors = new ArrayList<>();
    	validate(address);
        try {
        	String query = new StringBuilder()      
        		.append("INSERT INTO address_service (street 		")
        		.append("						   , city 			")
				.append("						   , postal_code) 	") 
				.append("	VALUES(?, ?, ?)							").toString();

	        PreparedStatement preparedStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
	        preparedStatement.setString(1, address.getStreet());
	        preparedStatement.setString(2, address.getCity());
	        preparedStatement.setInt(3, address.getPostalCode());
	        preparedStatement.executeUpdate();
	
	        ResultSet id = preparedStatement.getGeneratedKeys();
			id.next();
			address.setId(id.getLong(1));
		
			if (address.getId() == 0) {
                errors.add(ErrorCode.ADDRESS_ID_ERROR);
                throw new AppException(errors);
			}
			return address;
        } catch (SQLException exception) {
        	throw new AppException(ErrorCode.SQL_EXCEPTION, exception);
        }
    }
    
   private boolean isEmpty(String value) {
       return Objects.isNull(value) || "".equals(value);
   }

   private void validate(Address address) {

       ArrayList<ErrorCode> exceptions = new ArrayList<>();
       if (isEmpty(address.getStreet())) {
           exceptions.add(ErrorCode.STREET_FIELD_NOT_FOUND);
       }

       if(isEmpty(address.getCity())) {
           exceptions.add(ErrorCode.CITY_FIELD_NOT_FOUND);
       }

       if(address.getPostalCode() == 0) {
           exceptions.add(ErrorCode.PINCODE_NOT_FOUND);
       }

       if((address.getPostalCode() < 100000) || (address.getPostalCode() > 1000000)) {
           exceptions.add(ErrorCode.PINCODE_INVALID);
       }

       if(exceptions.size() > 0) {
           throw new AppException(exceptions);
       }
   }


    public Address update(Address address, Connection connection) {

//        if (addressPojo.getId() == 0) {
//            throw new RuntimeException("id cannot be null");
//        }
    	try {
    		validate(address);
    		String query = new StringBuilder()
        		.append("UPDATE address_service SET street = ?	 	")
        		.append("						  , city = ?		")
        		.append("						  , postal_code = ? ")
        		.append("	WHERE id = ? ").toString();
        
    		PreparedStatement preparedStatement = connection.prepareStatement(query);
    		preparedStatement.setString(1, address.getStreet());
    		preparedStatement.setString(2, address.getCity());
    		preparedStatement.setInt(3, address.getPostalCode());
    		preparedStatement.setLong(4, address.getId());
    		preparedStatement.executeUpdate();
    	} catch (Exception exception){
    		throw new AppException(ErrorCode.UPDATE_OPERATION_FAILED, exception);
    	}
        return address;
    }

    public void delete(Address address, Connection connection) {
    	
//        if (addressPojo.getId() == 0) {
//            throw new RuntimeException("id cannot be null");
//        }
    	try {
	        validate(address);
	        String query = new StringBuilder()
	        		.append("DELETE 								")
	        		.append(	 "FROM address_service WHERE id = ? ").toString();
	        
	        PreparedStatement preparedStatement = connection.prepareStatement(query);
	        preparedStatement.setLong(1, address.getId());
	        preparedStatement.executeUpdate();
    	} catch (Exception exception){
    		throw new AppException(ErrorCode.DELETE_OPERATION_FAILED, exception);
    	}
	}

    public Address read(Connection connection, long id) {
    	
        String query = new StringBuilder()
        		.append("SELECT id			")
        		.append("	  , street		")
        		.append("	  , city		")
        		.append("     , postal_code	")
        		.append(	"FROM address_service WHERE id = ? ").toString();
	        
        Address address = new Address();
        try {
	        PreparedStatement preparedStatement = connection.prepareStatement(query);
	        preparedStatement.setLong(1, id);
	        
	        ResultSet resultSet = preparedStatement.executeQuery();
	        while(resultSet.next()) {
	        
		        address.setId(resultSet.getLong("id"));
		        address.setStreet(resultSet.getString("street"));
		        address.setCity(resultSet.getString("city"));
		        address.setPostalCode(resultSet.getInt("postal_code"));
        	}  
    	} catch (Exception exception) {
    		throw new AppException(ErrorCode.READ_OPERATION_FAILED, exception);
    	}
        return address;
    }
    
    public ArrayList<Address> search(Connection connect, Address address) {
        String query = new StringBuilder()
                .append("SELECT street, city, postal_code, id")
                .append(" FROM trn_address WHERE city        ")
                .append(" = ?                                ")
                .append("OR street                           ")
                .append(" = ?                                ")
                .append("OR postal_code                      ")
                .append(" = ?;                               ")
                .toString();
        ArrayList<Address> addresses = new ArrayList<>();
        try {
            PreparedStatement statement = connect.prepareStatement(query);
            statement.setString(1, address.getCity());
            statement.setString(2, address.getStreet());
            statement.setInt(3, address.getPostalCode());
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Address detail = new Address();
                constructAddress(detail, resultSet);
                addresses.add(detail);
            }
        } catch (Exception exception) {
            throw new AppException(ErrorCode.SEARCH_OPERATION_FAILED, exception);
        }
        return addresses;
    }
    
    private Address constructAddress(Address address, ResultSet result) {
        try {
            address.setId(result.getLong("id"));
            address.setStreet(result.getString("street"));
            address.setCity(result.getString("city"));
            address.setPostalCode(result.getInt("postal_code"));
        } catch (Exception exception) {
            throw new AppException(ErrorCode.SQL_EXCEPTION, exception);
        }
        return address;
    }

	public List<Address> readAll(Connection connection) {
	
		List<Address> addressList = new ArrayList<>();
	    try {
			if (connection == null) {
		        throw new RuntimeException("connection not available");
		    }
		
		    Statement statement = connection.createStatement();
		    
		    String query = new StringBuilder()
		    		.append("SELECT id			 	 ")
		    		.append("	  , street		 	 ")
					.append("	  , city			 ")
					.append("	  , postal_code 	 ")
					.append("	FROM address_service ").toString();
		    
		    ResultSet resultSet = statement.executeQuery(query);
		    
		    while(resultSet.next()) {
		        Address address = new Address();
		        address.setId(resultSet.getLong("id"));
		        address.setStreet(resultSet.getString("street"));
		        address.setCity(resultSet.getString("city"));
		        address.setPostalCode(resultSet.getInt("postal_code"));
		        addressList.add(address);
		    } 
	    } catch (Exception exception){
	    	throw new AppException(ErrorCode.READALL_OPERATION_FAILED, exception);
	    }
	    return addressList;
	}

	public static void main(String[] args) throws Exception {
		AddressService service = new AddressService();
		Connection initConnection = ConnectionManager.initConnection();
		Address read = service.read(initConnection, 4);
		System.out.println(read);
		initConnection.close();
	}
}
