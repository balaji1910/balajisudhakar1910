package com.objectfrontier.training.webservice.constantInterface;

public interface Query {
		
	public static final String CREATE_PERSON = new StringBuilder()                      
			.append("INSERT INTO person_service (first_name ") 
			.append(" 						   , last_name	")
			.append("						   , email      ")
			.append("						   , address_id ")
			.append(" 						   , birth_date	")
			.append(" 						   , password	")
			.append(" 						   , isAdmin)	")
			.append("	VALUES (?, ?, ?, ?, ?)				").toString();

	public static final String UPDATE_PERSON = new StringBuilder()
			.append("UPDATE person_service SET first_name = ?	")
			.append("					  	  , last_name = ?	")
			.append("					  	  , email = ?		")
			.append("					  	  , address_id = ?	")
			.append("					  	  , birth_date = ?	")
			.append("   WHERE id = ?							").toString();
	
	public static final String DELETE_PERSON = new StringBuilder()
			.append("DELETE 			 	")
			.append("	FROM person_service ")
			.append("	WHERE id = ?		").toString();
	
	public static final String READ_PERSON = new StringBuilder()
			.append("SELECT id  			 ")
	        .append("     , first_name       ")
	        .append("     , last_name        ")
	        .append("     , email            ")
	        .append("     , birth_date       ")
	        .append("     , address_id       ")
	        .append("    FROM person_service ")
	        .append("    WHERE id = ?		 ").toString();

    public static final String READALL_PERSON = new StringBuilder()
            .append("SELECT id               ")
            .append("     , first_name       ")
            .append("     , last_name        ")
            .append("     , email            ")
            .append("     , birth_date       ")
            .append("     , address_id       ")
            .append("    FROM person_service ").toString();
    
    public static final String READALL_PERSON_WITHOUT_ADDRESS = new StringBuilder()
    		.append("SELECT id               ")
    		.append("     , first_name       ")
    		.append("     , last_name        ")
    		.append("     , email            ")
    		.append("     , birth_date       ")
    		.append("    FROM person_service ").toString();
    
    public static final String CREATE_ADDRESS = new StringBuilder()      
    		.append("INSERT INTO address_service (street 		")
    		.append("						    , city 			")
			.append("						    , postal_code) 	") 
			.append("	VALUES(?, ?, ?)							").toString();
    
    public static final String UPDATE_ADDRESS = new StringBuilder()
    		.append("UPDATE address_service SET street = ?	 	")
    		.append("						  , city = ?		")
    		.append("						  , postal_code = ? ")
    		.append("	WHERE id = ?						    ").toString();
    
    public static final String DELETE_ADDRESS = new StringBuilder()
    		.append("DELETE 								")
    		.append(	 "FROM address_service WHERE id = ? ").toString();
    
    public static final String READ_ADDRESS = new StringBuilder()
    		.append("SELECT id								")
    		.append("	  , street							")
    		.append("	  , city							")
    		.append("     , postal_code						")
    		.append("	FROM address_service			    ")
    		.append("	WHERE id = ? 						").toString();
    
    public static final String READALL_ADDRESS = new StringBuilder()
    		.append("SELECT id           	 ")
            .append("     , street     		 ")
            .append("     , city        		 ")
            .append("     , postal_code  	 ")
            .append("    FROM address_service ").toString();
    
    public static final String DUPLICATE_EMAIL = new StringBuilder()
            .append("SELECT COUNT(id) AS duplicate_email ")
            .append("	FROM person_service 		     ")
            .append("	WHERE email =? AND id != ? 		 ").toString();
    
    public static final String DUPLICATE_NAME =  new StringBuilder()
            .append("SELECT COUNT(id) AS duplicate_name                	  ")
            .append("	FROM person_service 							  ")
            .append("	WHERE first_name =? AND last_name = ? AND id != ? ").toString();
    
	public static final String AUTHENTICATION =  new StringBuilder()
            .append("SELECT id                        	 ")
            .append("     , email                     	 ")
            .append("	FROM person_service            	 ")
            .append("	WHERE email = ? AND password = ? ").toString();
	
}
