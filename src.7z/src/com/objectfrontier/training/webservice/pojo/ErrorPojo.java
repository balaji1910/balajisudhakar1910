package com.objectfrontier.training.webservice.pojo;

import java.util.List;

import com.objectfrontier.training.webservice.main.ErrorCode;

public class ErrorPojo {

	List<ErrorCode> errors;

	@Override
	public String toString() {
		return "ErrorPojo [errors=" + errors + "]";
	}

	public List<ErrorCode> getErrors() {
		return errors;
	}

	public void setErrors(List<ErrorCode> errors) {
		this.errors = errors;
	}
}
