package com.objectfrontier.training.webservice.filter;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.objectfrontier.training.webservice.main.AppException;
import com.objectfrontier.training.webservice.main.ConnectionManager;

public class TransactionFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
    
        Connection connection = ConnectionManager.initConnection();
        try {
            filterChain.doFilter(servletRequest, servletResponse);
            ConnectionManager.releaseConnection(connection, true);
        } catch (Exception exception) {
            if (exception instanceof AppException) {
                ConnectionManager.releaseConnection(connection,false);
                throw new AppException(((AppException) exception).getExceptionList());
            }
            ConnectionManager.releaseConnection(connection,false);
        }
    }

    @Override
    public void destroy() {}
}
