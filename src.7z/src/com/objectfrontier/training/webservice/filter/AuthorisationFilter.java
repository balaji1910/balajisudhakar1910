package com.objectfrontier.training.webservice.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.objectfrontier.training.webservice.main.AppException;
import com.objectfrontier.training.webservice.main.ErrorCode;
import com.objectfrontier.training.webservice.pojo.ErrorPojo;
import com.objectfrontier.training.webservice.pojo.Person;
import com.objectfrontier.training.webservice.utils.JsonUtil;

public class AuthorisationFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        
    	HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
        HttpServletResponse httpServletResponse = (HttpServletResponse) servletResponse;
        HttpSession session = httpServletRequest.getSession(false);
        Person person = (Person) session.getAttribute("person");
        PrintWriter writer = httpServletResponse.getWriter();
        
        try {
            if (person.isAdmin()) {
            filterChain.doFilter(servletRequest, servletResponse);
                } else {
                	if ("PUT".equals(httpServletRequest.getMethod()) || "DELETE".equals(httpServletRequest.getMethod())) {
                		throw new AppException(ErrorCode.ACCESS_DENIED);
                }
            }
        } catch (AppException appException) {
        	ErrorPojo error = new ErrorPojo();
            error.setErrors(appException.getExceptionList());
            writer.write(JsonUtil.toJson(error));
        }
    }

    @Override
    public void destroy() {}
}
