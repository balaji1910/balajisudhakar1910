package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
//import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class AddressService {

    Address address = new Address();
    String result;
    TransactionManager txnManager =  new TransactionManager(); 
    Connection conn = null;

    public int queryInsert(String street, String city, int postal_code, Connection conn) throws Exception {

        if (postal_code == 0) {
            throw new RuntimeException("postal code cannot be zero");
        }
        Connection connection = txnManager.connectionEstablish("jdbc:mysql://pc1620:3306/balaji_sudhakar?useSSL=false", "balaji_sudhakar", "demo");
        String sql = "INSERT INTO addressService(street, city, postal_code)VALUES(?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, street);
        preparedStatement.setString(2, city);
        preparedStatement.setInt(3, postal_code);
        int result = preparedStatement.executeUpdate();
//        connection.close();
        return result;
    }



    public int queryUpdate(String street, String city, Connection conn) throws Exception {

        if (street == null) {
            throw new RuntimeException("street cannot be null");
        }
        Connection connection = txnManager.connectionEstablish("jdbc:mysql://pc1620:3306/balaji_sudhakar?useSSL=false", "balaji_sudhakar", "demo");
        String sql = "UPDATE addressService SET street = ? WHERE city = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, street);
        preparedStatement.setString(2, city);
        int result = preparedStatement.executeUpdate();
//        connection.close();
        return result;

    }


    public int queryDelete(String street, Connection conn) throws Exception {
        if(street == null) {
            throw new RuntimeException("street cannot be null");
        }
        Connection connection = txnManager.connectionEstablish("jdbc:mysql://pc1620:3306/balaji_sudhakar?useSSL=false", "balaji_sudhakar", "demo");
        String sql = "DELETE FROM addressService WHERE street = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, street);
        int result = preparedStatement.executeUpdate();
//        connection.close();
        return result;
    }


    public String queryRead(long id, Connection conn) throws Exception {
        if(id == 0) {
            throw new RuntimeException("id should not be empty");
        }
        Connection connection = txnManager.connectionEstablish("jdbc:mysql://pc1620:3306/balaji_sudhakar?useSSL=false", "balaji_sudhakar", "demo");
        String readQuery = "SELECT city FROM addressService WHERE id = ?";
        // String readQuery = "SELECT street FROM jdbc_address WHERE id = ?";

        PreparedStatement statement = connection.prepareStatement(readQuery);
        statement.setLong(1, id);
        ResultSet resultSet = statement.executeQuery();
        String record;

        resultSet.next();

        //address.setStreet(resultSet.getString("street"));
        address.setCity(resultSet.getString("city"));

        record = address.getCity();

        //System.out.println(records.get(0).getStreet());
        //System.out.println(records.get(0).getCity());
        //System.out.println(records.toString());
        //System.out.println(records);

        return record;
    }


    public int queryReadAll(String addressService, Connection conn) throws Exception {

        if (addressService == null) {
            throw new RuntimeException("connection not established");
        }
        Connection connection = txnManager.connectionEstablish("jdbc:mysql://pc1620:3306/balaji_sudhakar?useSSL=false", "balaji_sudhakar", "demo");
        Statement statement = connection.createStatement();
        String sql = "SELECT id, street, city, postal_code FROM addressService";
        ResultSet rs = statement.executeQuery(sql);

        List<String> addressList = new ArrayList<String>();
        while(rs.next()) {
            address.setId(rs.getInt("id"));
            address.setStreet(rs.getString("street"));
            address.setCity(rs.getString("city"));
            address.setPostalCode(rs.getInt("postal_code"));
            String appender = address.getId() + "," + address.getStreet() + "," + address.getCity() + "," + address.getPostalCode();
            addressList.add(appender);
//            System.out.println(addressList);
            //addr = addressList.toString();
        }
        int size = addressList.size();

        //                System.out.println(addressList.get(0).getId());
        //                System.out.println(addressList.get(0).getStreet());
        //                System.out.println(addressList.get(0).getCity());
        //                System.out.println(addressList.get(0).getPostal_code());

//        connection.close();
        return size;
    }


//    public static void main(String[] args) throws Exception {
//        AddressService service = new AddressService();

//                List<Address> address = new ArrayList<Address>();

//                System.out.println(service.queryInsert("sss", "chennai", 9987, null));
//                service.queryUpdate();
//                service.queryDelete();
//                service.queryRead();
              
//               System.out.println(service.queryReadAll());
//    }
}
