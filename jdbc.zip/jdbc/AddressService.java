package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class AddressService {

    private Connection connectionEstablish() throws Exception {

        String url = "jdbc:mysql://pc1620:3306/balaji_sudhakar?useSSL=false";
        String username = "balaji_sudhakar";
        String password = "demo";
        Connection connection = DriverManager.getConnection(url, username, password);
        return connection;
    }

    private void queryInsert() throws Exception {

        Connection connection = connectionEstablish();
        String sql = "INSERT INTO addressService(street, city, postal_code)VALUES(?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, "lts");
        preparedStatement.setString(2, "salem");
        preparedStatement.setLong(3, 9008);
        int result = preparedStatement.executeUpdate();
        System.out.println(result);
        connection.close();
    }

    private void queryUpdate() throws Exception {

        Connection connection = connectionEstablish();
        String sql = "UPDATE addressService SET street = ?, city = ?, postal_code = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, "jks");
        preparedStatement.setString(2, "Chennai");
        preparedStatement.setLong(3, 10055);
        int result = preparedStatement.executeUpdate();
        System.out.println(result);
        connection.close();
    }

    private void queryDelete() throws Exception {
        Connection connection = connectionEstablish();
        String sql = "DELETE FROM addressService WHERE street = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, "jks");
        int result = preparedStatement.executeUpdate();
        System.out.println(result);
        connection.close();
    }

    private void queryRead() throws Exception {
        Connection connection = connectionEstablish();
        //Statement statement = connection.createStatement();
        String sql = "SELECT city FROM addressService WHERE id = 2 ";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet rs = preparedStatement.executeQuery(sql);
        while ( rs.next() ) {
            String city = rs.getString(1);
            System.out.format("city : %s", city);
        }
        connection.close();
    }

    private void queryReadAll() throws Exception {
        Connection connection = connectionEstablish();
        String sql = "SELECT * FROM addressService";
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery(sql);
        while(rs.next()) {
            String id = rs.getString("id");
            String street = rs.getString("street");
            String city = rs.getString("city");
            String postal_code = rs.getString("postal_code");

            System.out.println(id);
            System.out.println(street);
            System.out.println(city);
            System.out.println(postal_code);
        }
        connection.close();
    }

    public static void main(String[] args) throws Exception {
        AddressService service = new AddressService();
        service.connectionEstablish();
        //service.queryInsert();
        //service.queryUpdate();
        //service.queryDelete();
        //service.queryRead();
        service.queryReadAll();
    }
}
