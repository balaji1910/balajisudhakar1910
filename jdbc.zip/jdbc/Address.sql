/* Setup DB
- Refer the attached image and create respective tables and POJO (plain old java object) classes
- Person.id, Address.id and Person.created_date columns should be auto generated
- Address.pincode should not be empty
- Person.email should be constrained to be unique
- Define all requisite constraints for the table like PKs and FKs */

CREATE TABLE trn_address(id 				BIGINT (20) PRIMARY KEY AUTO_INCREMENT
							  , street 			VARCHAR(100)
							  , city 			VARCHAR(15)
							  , postal_code 	INT(11) NOT NULL
); 

CREATE TABLE trn_person(id BIGINT(20) PRIMARY KEY AUTO_INCREMENT
							 , `name` VARCHAR(50)
							 , email
							 , address_id
							 , birth_date DATE 
							 , created_date DATE TIME DEFAULT CURRENT_TIMESTAMP
							 , 
);

/* INSERT INTO  user_rights (`user_id`,`right`,`group_id`,`created_date`) VALUES ( '42',  '160',  '1',  now()) */