/* Setup DB
- Refer the attached image and create respective tables and POJO (plain old java object) classes
- Person.id, Address.id and Person.created_date columns should be auto generated
- Address.pincode should not be empty
- Person.email should be constrained to be unique
- Define all requisite constraints for the table like PKs and FKs */

CREATE TABLE AddressService(id 				BIGINT (20) PRIMARY KEY AUTO_INCREMENT
							  , street 			VARCHAR(100)
							  , city 			VARCHAR(15)
							  , postal_code 	INT(11) NOT NULL
); 

CREATE TABLE personService(id BIGINT PRIMARY KEY AUTO_INCREMENT
,name VARCHAR(50),email VARCHAR(100) UNIQUE,
						birth_date DATE,
						created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
						address_id BIGINT(20),
						CONSTRAINT fk_personService FOREIGN KEY(address_id) REFERENCES addressService(id)
);

DROP TABLE addressService;
DROP TABLE personService; 

SELECT * FROM AddressService;
SELECT * FROM personService;

/* INSERT INTO  user_rights balaji_sudhakar(`user_id`,`right`,`group_id`,`created_date`) VALUES ( '42',  '160',  '1',  now()) */