package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class PersonService {

    AddressService addressEntity = new AddressService();

    public PreparedStatement preparedStatement(Connection connection, String sql)throws Exception {
        PreparedStatement prepared = null;
        prepared = connection.prepareStatement(sql);
        log("PreparedStatement Running......%n");
        return prepared;
    }
    
    public int insertPersonRecord(Connection connection, Person person, Address address) throws Exception {

        addressEntity.insertRecord(connection, address);
        long addressId = addressEntity.readIdValue(connection);

        String personQuery = "INSERT INTO PERSON(`name`," + "`email`," 
                                                          + "`address_id`,"  
                                                          + "`birth_date`)"
                                                          + "VALUES (?, ?, ?, ?);";
        PreparedStatement insertStatement = preparedStatement(connection, personQuery);

        insertStatement.setString(1, person.getName());
        insertStatement.setString(2, person.getEmail());
        insertStatement.setLong(3, addressId);
        insertStatement.setDate(4, person.getBirthDate());

        int rowsAffected = insertStatement.executeUpdate();
//        connection.commit();
        return rowsAffected;
    }

    public int updatePersonRecord(Connection connection, Person person) throws Exception {

        String updateQuery = "UPDATE PERSON SET name = ? WHERE id = ?";

        PreparedStatement updateStatement = preparedStatement(connection, updateQuery);

        updateStatement.setString(1, person.getName());
        updateStatement.setLong(2, person.getId());

        int rowsAffected = updateStatement.executeUpdate();
        return rowsAffected;
    }

    public int deletePersonRecord(Connection connection, Address address) throws Exception {

        long addressId = address.getId();
        String query  = "Delete FROM PERSON WHERE address_id = ?";
        PreparedStatement deleteStatement = preparedStatement(connection, query);
        deleteStatement.setLong(1, addressId);
        deleteStatement.executeUpdate();

        int deleteRowsAffected = addressEntity.deleteRecord(connection, address);
//        connection.commit();
        return deleteRowsAffected;
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}
