package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class TransactionManager {

    public Connection connectionEstablish(String url, String username,String password) throws Exception {
        Connection conn = null;
        try {
//            String url = "jdbc:mysql://pc1620:3306/madhumitha_g?useSSL=false";
//            String username = "madhumitha_g";
//            String password = "demo";
            conn = DriverManager.getConnection(url, username, password);
            return conn;
        } catch(Exception e) {
            System.out.format(e.getMessage(),"connection not established");          
        }
        return conn;
    }   
}
