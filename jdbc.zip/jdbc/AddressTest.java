package com.objectfrontier.training.java.jdbc;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.sql.Connection;

public class AddressTest {

    AddressService service;
    TransactionManager transactionManager; 
    
//    ConnectionManager manager;
//    AddressService service;
    @BeforeClass
    private void initAddressTest() {         
        service = new AddressService();
        transactionManager = new TransactionManager();
 }

       
//    @Test(dataProvider = "testInsertCheck_positiveDP")
//    private void testInsertCheck_positiveOne(String street, String city, int postal_code, int expectedResult) {
//         
//        try {
//           
//            Connection connection = transactionManager.connectionEstablish("jdbc:mysql://pc1620:3306/balaji_sudhakar?useSSL=false", "balaji_sudhakar", "demo"); 
//            int actualResult = service.queryInsert(street, city, postal_code, connection);
//            Assert.assertEquals(actualResult, expectedResult);
//        } catch (Exception e) {
//            Assert.fail("Unexpected exception for input "
//                    + street
//                    + " , "
//                    + city
//                    + " , "
//                    + postal_code
//                    + " , "
//                    + "Expected result is "
//                    + expectedResult
//                    );
//        }
//    }
//
//    
//    @DataProvider
//    private Object[][] testInsertCheck_positiveDP() {
//        return new Object[][] {
//            {"gandhi", "Chennai", 605003, 1},
//            {"balaji", "Salem", 200976, 1},
//            {"ambedhkar", "Madurai", 110082, 1}
//        };
//    }
//
//    @Test
//    private void testInsertCheck_negative() {
//
//        try {
//            Connection connection = transactionManager.connectionEstablish("jdbc:mysql://pc1620:3306/balaji_sudhakar?useSSL=false", "balaji_sudhakar", "demo");
//            service.queryInsert("", "", 0, connection);
//            Assert.fail("Expected an exception");
//        } catch (Exception e) {
//            Assert.assertEquals(e.getMessage(), "postal code cannot be zero");
//        }
//    }


//    @Test(dataProvider = "testUpdateCheck_positiveDP")
//    private void testupdateCheck_positiveOne(String street, String city, int expectedResult) {
//
//        try {
//            Connection connection = transactionManager.connectionEstablish("jdbc:mysql://pc1620:3306/balaji_sudhakar?useSSL=false", "balaji_sudhakar", "demo");
//            int actualResult = service.queryUpdate(street, city, connection);
//            Assert.assertEquals(actualResult, expectedResult);
//        } catch (Exception e) {
//            Assert.fail("Unexpected exception for input "
//                    + street
//                    + " , "
//                    + city
//                    + " , "
//                    + "Expected result is "
//                    + expectedResult
//                    );
//        }
//    }
//
//    @DataProvider
//    private Object[][] testUpdateCheck_positiveDP() {
//
//        return new Object[][] {
//            { "Lokesh Gaaru", "Chennai", 1}
//        };
//    }
//
//
//    @Test
//    private void testUpdateCheck_negative() {
//
//        try {
//            Connection connection = transactionManager.connectionEstablish("jdbc:mysql://pc1620:3306/balaji_sudhakar?useSSL=false", "balaji_sudhakar", "demo");
//            service.queryUpdate(null , "", connection);
//            Assert.fail("Expected an exception.");
//        } catch (Exception e) {
//            Assert.assertEquals(e.getMessage(), "street cannot be null");
//        }
//    }

    
//    @Test(dataProvider = "testDeleteCheck_positiveDP")
//    private void testDeleteCheck_positiveOne(String street, int expectedResult) {
//
//        try {
//            Connection conncection = transactionManager.connectionEstablish("jdbc:mysql://pc1620:3306/balaji_sudhakar?useSSL=false", "balaji_sudhakar", "demo");
//            int actualResult = service.queryDelete(street, conncection);
//            Assert.assertEquals(actualResult, expectedResult);
//        } catch (Exception e) {
//            Assert.fail("Unexpected exception for input "
//                    + street
//                    + " , "
//                    + "Expected result is "
//                    + expectedResult
//                    );
//        }
//    }
//  
//   
//    @DataProvider
//    private Object[][] testDeleteCheck_positiveDP() {
//
//        return new Object[][] {
//            { "balaji", 1}
//        };
//    }
//
//    
//    @Test
//    private void testDeleteCheck_negative() {
//
//        try {
//            Connection conn = transactionManager.connectionEstablish("jdbc:mysql://pc1620:3306/balaji_sudhakar?useSSL=false", "balaji_sudhakar", "demo");
//            service.queryDelete(null, conn);
//            Assert.fail("Expected an exception.");
//        } catch (Exception e) {
//            Assert.assertEquals(e.getMessage(), "street cannot be null");
//        }
//    }

    
//  @Test(dataProvider = "testReadCheck_positiveDP")
//  private void testReadCheck_positiveOne(int id, String expectedResult) {
//
//      try {
//          Connection connection = transactionManager.connectionEstablish("jdbc:mysql://pc1620:3306/balaji_sudhakar?useSSL=false", "balaji_sudhakar", "demo");
//          String actualResult = service.queryRead(id, connection);
//          Assert.assertEquals(actualResult, expectedResult);
//      } catch (Exception e) {
//          Assert.fail("Unexpected exception for input "
//                  + id
//                  + " , "
//                  + "Expected result is "
//                  + expectedResult
//                  );
//      }
//  }   
//    
//    
//  @DataProvider
//  private Object[][] testReadCheck_positiveDP() {
//
//      return new Object[][] {
//          { 3, "Madurai"}
//      };
//  }
//
//  
//  @Test
//  private void testReadCheck_negative() {
//
//      try {
//          Connection connection = transactionManager.connectionEstablish("jdbc:mysql://pc1620:3306/balaji_sudhakar?useSSL=false", "balaji_sudhakar", "demo");
//          service.queryRead(0, connection);
//          Assert.fail("Expected an exception.");
//      } catch (Exception e) {
//          Assert.assertEquals(e.getMessage(), "id should not be empty");
//      }
//  }   
  
  
  @Test(dataProvider = "testReadAllCheck_positiveDP")
  private void testReadAllCheck_positive(String addressService, int expectedResult) {

      try {
          Connection connection = transactionManager.connectionEstablish("jdbc:mysql://pc1620:3306/balaji_sudhakar?useSSL=false", "balaji_sudhakar", "demo");
          int actualResult = service.queryReadAll(addressService, connection);
          Assert.assertEquals(actualResult, expectedResult);
      } catch (Exception e) {
          Assert.fail("Unexpected exception for input "          
                  + "Expected result is "
                  + expectedResult
                  );
      }
  }   
    
    
  @DataProvider
  private Object[][] testReadAllCheck_positiveDP() {

      return new Object[][] {
          {"", 15}
      };
  }

  
  @Test
  private void testReadAllCheck_negative() {

      try {
          Connection conn = transactionManager.connectionEstablish("jdbc:mysql://pc1620:3306/balaji_sudhakar?useSSL=false", "balaji_sudhakar", "demo");
          service.queryReadAll(null, conn);
          Assert.fail("Expected an exception.");
      } catch (Exception e) {
          Assert.assertEquals(e.getMessage(), "connection not established");
      }
  }   
  
  
    
    @AfterClass
    private void afterClass() {

    }
}
